import Vue from "vue";
import Vuex from "vuex";
import EvaLoginStore from "@/module/Eva/login/store";
import EvaAlumnosStore from "@/module/Eva/alumnos/store";
import EvaDocentesStore from "@/module/Eva/docentes/store";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    ...EvaLoginStore,
    ...EvaAlumnosStore,
    ...EvaDocentesStore
  },
});
