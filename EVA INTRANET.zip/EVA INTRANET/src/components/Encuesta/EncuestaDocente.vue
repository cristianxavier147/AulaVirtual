<template>
  <section class="mx-auto bg-gray-100 md:w-7/12 size-text-14">
    <div class="mt-24">
      <h1 class="flex mx-3 mb-5 text-3xl font-bold text-justify md:text-3xl">{{ lstFicha.Nombre }}</h1>
      <span class="flex mx-3 text-xs font-semibold text-justify md:text-base">¡Hola {{ store.user_name }}! Te invitamos a evaluar a los profesores de tus {{ lstFichaProgramacionDetalle.length }} cursos.</span>
      <br />
      <span class="flex mx-3 text-xs text-justify">Recuerda que esto nos ayudará a mejorar tu experiencia en la escuela.</span>
      <span class="flex mx-3 mt-4 text-xs font-bold text-justify text-gray-500">Responde las preguntas para pasar al siguiente profesor. Son máximo {{ lstFichaPregunta.length }} preguntas por curso, ¡será rápido!</span>
      <div class="flex mx-3 mt-4">
        <div class="items-center justify-center" style="display: flex; flex-direction: row;" v-for="(a, i) in lstFichaProgramacionDetalle" :key="i">
          <div class="items-center justify-center" style="display: flex; flex-direction: column;width: 25px; height:25px; border-radius: 25px;" :class="i == 0 ? 'bg-purple-700' : ''" :style="{ backgroundColor: i == 0 ? '' : 'gray', color: 'white' }">
            <span>{{ i + 1 }}</span>
          </div>
          <div class="items-center justify-center" style="display: flex; flex-direction: column;width: 15px; height:3px; background-color: gray;" v-if="i != lstFichaProgramacionDetalle.length - 1">
            <hr />
          </div>
        </div>
      </div>

      <!-- foto y nombre-->
      <div class="flex">
        <img class="w-1/12 mx-3 mt-5" src="@/assets/encuesta/photos.svg" />
        <div class="flex gap-40 mt-8 text-xs md:mt-11 md:gap-52">
          <span class="font-bold">{{ lstFichaProgramacionDetalle[0].NombreCompleto }}</span>
          <span class="font-bold text-gray-500">{{ lstFichaProgramacionDetalle[0].NombreProducto }}</span>
        </div>
      </div>

      <div class="p-5 mt-5 bg-white" v-for="l in lstFichaPregunta" :key="l.IdPregunta">
        <span class="flex text-xs font-bold md:text-base">
          <span v-html="l.Pregunta"></span>
        </span>
        <br />
        <div v-if="l.ControlNombre == 'OPTION BUTTON'">
          <div class="flex text-xs" v-for="a in l.lstPreguntaAlternativa" :key="a.IdAlternativa">
            <input type="checkbox" name="check" class="w-5" :value="a.Valor" />
            <span class="mt-4 ml-2">{{ a.Nombre }}</span>
          </div>
        </div>
        <div v-else-if="l.ControlNombre == 'TEXTBOX'">
          <div class="flex text-xs">
            <textarea style="width: 100%;height: 100px;border-radius: 10px;border: 1px solid;" />
          </div>
        </div>
        <img v-else class="w-9/12 py-2 mx-2 md:w-4/12" src="@/assets/encuesta/puntaje.svg" />
      </div>
      <div class="hidden my-6 md:flex md:justify-end md:pb-0">
        <!-- <button class="mr-5 font-bold text-purple-700 underline">Omitir Encuesta</button> -->
        <button class="px-10 py-3 text-white bg-purple-700">siguiente</button>
      </div>
      <!-- mobile -->
      <div class="flex flex-col-reverse mx-3 my-5 md:hidden md:justify-end md:pb-0">
        <!-- <button class="mt-8 mb-2 font-bold text-purple-700 underline ">Omitir Encuesta</button> -->
        <button class="px-10 py-4 text-white bg-purple-700 ">siguiente</button>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  data() {
    return {
      lstFichaPregunta: [],
      lstFicha: {},
      lstFichaProgramacionDetalle: [],
    };
  },
  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },
  },
  methods: {
    async getEncuestas() {
      try {
        let json = {
          IdActor: this.store.user_id_actor,
          IdTipoUsuario: this.store.user_type_usuario,
        };
        let res = await this.$store.dispatch("encuestasStore/getEncuesta", json);
        if (res.results) {
          this.lstFichaPregunta = res.results.lstFichaPregunta;
          if (res.results.lstFicha[0]) {
            this.lstFicha = res.results.lstFicha[0];
          }
          this.lstFichaProgramacionDetalle = res.results.lstFichaProgramacionDetalle;
        }
      } catch (error) {
        console.log("error", error);
      }
    },
  },
  async created() {
    await this.getEncuestas();
  },
};
</script>

<style></style>
