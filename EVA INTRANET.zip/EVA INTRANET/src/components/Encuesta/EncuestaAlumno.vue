<template>
  <section class="mx-auto bg-gray-100 md:w-7/12 size-text-14">
    <div class="mt-24">
      <h1 class="flex mx-3 mb-5 text-xl font-bold text-justify md:text-3xl">¡Cuéntanos sobre tu primera semana de clases!</h1>
      <span class="flex mx-3 text-xs font-semibold text-justify md:text-base">¡Hola Giancarlo! Queremos saber cómo te fue en esta primera semana de clases. </span>
      <br />
      <span class="flex mx-3 text-xs text-justify">Recuerda que esto nos ayudará a mejorar tu experiencia en la escuela.</span>
      <div class="p-5 mt-5 bg-white">
        <span class="flex text-xs font-bold md:text-base">¿Cómo te fue en esta primera semana?</span>
        <br />
        <select class="flex w-8/12 md:w-3/12">
          <option value="#">Mal</option>
        </select>
      </div>
      <div class="p-5 mt-4 bg-white">
        <span class="flex mx-2 text-xs font-bold text-justify">Pusiste que te fue mal. ¿Te gustaría contarnos por qué?</span>
        <br />
        <input class="flex w-full text-gray-700" type="text" placeholder="Escribe aquí..." />
      </div>
      <div class="hidden my-5 md:flex md:justify-end md:pb-0">
        <button class="mr-5 font-bold text-purple-700 underline">Omitir Encuesta</button>
        <button class="px-10 py-3 text-white bg-purple-700">Enviar</button>
      </div>
      <!-- mobile -->
      <div class="flex flex-col-reverse mx-3 my-5 md:hidden md:justify-end md:pb-0">
        <button class="mt-8 mb-2 font-bold text-purple-700 underline ">Omitir Encuesta</button>
        <button class="px-10 py-4 text-white bg-purple-700 ">Enviar</button>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },
  },
  methods: {
    async getEncuestas() {
      try {
        let json = {
          IdActor: this.store.user_id_actor,
          IdTipoUsuario: this.store.user_type_usuario,
        };
        let res = await this.$store.dispatch("encuestasStore/getEncuesta", json);
        console.log("res", res);
      } catch (error) {
        console.log("error", error);
      }
    },
  },
  async created() {
    await this.getEncuestas();
  },
};
</script>

<style></style>
