<template>
  <section class="mx-auto bg-gray-100 md:w-7/12 size-text-14">
    <div class="mt-24">
      <h1 class="flex mx-3 mb-5 text-3xl font-bold text-justify md:text-3xl">¡Cuéntanos sobre tu primer día de clases!</h1>
      <span class="flex mx-3 text-xs font-semibold text-justify md:text-base">¡Hola Giancarlo! Queremos saber cómo te fue en tu primer día de clases. </span>
      <br />
      <span class="flex mx-3 text-xs text-justify">Recuerda que esto nos ayudará a mejorar tu experiencia en la escuela.</span>
      <div class="p-5 mt-5 bg-white">
        <span class="flex text-xs font-bold md:text-base">¿Asististe a la bienvenida?</span>
        <br />
        <select class="flex w-8/12 md:w-3/12">
          <option value="#">No</option>
        </select>
      </div>
      <div class="p-5 mt-4 bg-white">
        <span class="flex mx-2 text-xs font-bold text-justify">¿Por qué no asististe?</span>
        <br />
        <input class="flex w-full text-gray-700" type="text" placeholder="Escribe aquí..." />
      </div>
      <div class="hidden my-5 md:flex md:justify-end md:pb-0">
        <button class="mr-5 font-bold text-purple-700 underline">Omitir Encuesta</button>
        <button class="px-10 py-3 text-white bg-purple-700">Enviar</button>
      </div>
      <!-- mobile -->
      <div class="flex flex-col-reverse mx-3 my-5 md:hidden md:justify-end md:pb-0">
        <button class="mt-8 mb-2 font-bold text-purple-700 underline ">Omitir Encuesta</button>
        <button class="px-10 py-4 text-white bg-purple-700 ">Enviar</button>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
