<template>
  <section class="mx-auto bg-gray-100 md:w-7/12 size-text-14">
    <div class="mt-24">
      <h1 class="flex mx-3 mb-5 text-3xl font-bold text-justify md:text-3xl">¡Queremos saber tu opinión!</h1>
      <span class="flex mx-3 text-xs font-semibold text-justify md:text-base">¡Hola Giancarlo! Cuéntanos, ¿recomendarías Idat?</span>
      <br />
      <span class="flex mx-3 text-xs text-justify">Recuerda que esto nos ayudará a mejorar tu experiencia en la escuela.</span>
      <div class="p-5 mt-5 bg-white">
        <span class="flex py-2 mx-2 text-xs font-bold text-justify md:text-base">Del 0 al 10 ¿Qué tan dispuesto estás a recomendar Idat a un amigo / familiar / compañero de trabajo como un lugar para estudiar? </span>
        <span class="flex mx-2 mt-3 text-xs text-justify">Donde 9-10 es totalmente dispuesto, 7-8 es algo dispuesto y 0-6 es no tan dispuesto. </span>
        <br />
        <img class="w-9/12 py-2 mx-2 md:w-4/12" src="@/assets/encuesta/puntaje.svg" />
      </div>
      <div class="p-5 mt-4 bg-white">
        <span class="flex py-2 mx-2 text-xs font-bold text-justify">¿Por qué has dado ese puntaje?</span>
        <br />
        <input class="flex w-full mx-2 text-gray-700" type="text" placeholder="Escribe aquí..." />
      </div>
      <div class="hidden my-5 md:flex md:justify-end md:pb-0">
        <button class="mr-5 font-bold text-purple-700 underline">Omitir Encuesta</button>
        <button class="px-10 py-3 text-white bg-purple-700">Enviar</button>
      </div>
      <!-- mobile -->
      <div class="flex flex-col-reverse mx-3 my-5 md:hidden md:justify-end md:pb-0">
        <button class="mt-8 mb-2 font-bold text-purple-700 underline ">Omitir Encuesta</button>
        <button class="px-10 py-4 text-white bg-purple-700 ">Enviar</button>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
