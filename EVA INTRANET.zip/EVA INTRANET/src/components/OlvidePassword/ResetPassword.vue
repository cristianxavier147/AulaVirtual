<template>
  <div :class="'fnd-' + classGeneral ">
    <div class="md:pt-24 lg:pt-20 pt-5 ml-4 mr-5 h-full">
      <div :class="'fnd-' + classGeneral " class="md:w-96 mx-auto md:p-10 rounded-md">
        <img src="@/assets/svg/logo-eva.svg" alt="logo-eva" class="w-1/5 md:w-2/5 md:mx-auto mb-32 md:mb-16" />
        <span class="font-bold text-xl md:text-lg text-white">¿Tienes problemas para iniciar sesión?</span>
        <p class="text-sm md:text-xs font-medium mt-3 text-white">
          Ingresa tu código de estudiante para enviar el enlace a su correo electrónico.
        </p>

        <!-- INPUT CORREO PERSONAL-->
        <div class="md:text-center md:my-14 mt-16 md:mb-24 mb-14 relative">
          <input type="texto" class="w-full h-10 font-bold text-center" placeholder="Código Estudiante" v-model="mail" />
          <span class="absolute left-0 -bottom-5 font-bold text-white size-text-12" v-if="errorEmail">*Campo Obligatorio</span>
        </div>

        <button @click="sendEmail" class="bg-black font-semibold w-full text-white h-12 rounded-md mb-5">
          <div class="flex items-center justify-center">
            <div class="lds-dual-ring" v-if="preloader"></div>
            <span class="size-text-16">Enviar enlace</span>
          </div>
        </button>


        <!-- Enviar enlace al correo para poder reeestablecer la contraseña -->
        <!-- <router-link to="/nuevoPassword">
          <button class="bg-black font-semibold w-full text-white h-12 rounded-md mb-5">
            Enviar enlace
          </button>
        </router-link> -->

        <!-- Volver al login -->
        <router-link to="/login">
          <span class="underline text-white">Volver al inicio de sesión</span>
        </router-link>
      </div>
    </div>
    <SolicitudCorrecta v-if="openModal" @closeModal="closeModal" />
  </div>
</template>

<script>
import SolicitudCorrecta from "@/components/Alertas/SolicitudCorrecta";
export default {
  name: "ResetPassword",
  data() {
    return {
      mail:'',
      errorEmail: false,
      openModal: false,
      preloader: false
    }
  },
  components: {
    SolicitudCorrecta
  },

  methods: {
    sendEmail(){
      let store = JSON.parse(localStorage.getItem('data'))
      if(this.mail == "") return this.errorEmail = true
      this.preloader = true
      var form = {
        username : store.codigouser,
        email : this.mail
      }

      this.$store.dispatch("loginStore/olvidePassword", form).then(
        (response) => {
          if(response.success == true){
            this.openModal =  true
            this.preloader = false
          }
        }
      )
    },
    closeModal(){
      this.openModal = false
      this.$router.push({ path: 'login' }).catch(()=>{})
    }
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>