<template>
  <div class="bg-white" :class="'md:bg-' + classGeneral + '-500'">
    <div class="md:pt-14 pt-4 ml-4 mr-5 pb-8 md:pb-10">
      <div class="bg-white lg:w-2/5 lg:pb-10 mx-auto text-left md:p-12 rounded-md">
        <img src="@/assets/svg/logo-eva-black.svg" alt="logo-eva" class="w-24 h-7 md:h-10 md:w-32 md:mx-auto mb-14" />
        <h1 class="font-bold md:text-xl text-center text-xl mb-5 md:mt-0 mt-28">
          Ingresa tu nueva contraseña
        </h1>
        <p class="text-sm text-center">
          Recuerda que debe tener 8 caracteres como mínimo, pero mientras más digitos tenga será más segura. Debe contar con al menos un mayúscula, una minúscula y un número.
        </p>
        <!-- inputs -->
        <div class="w-full my-16">
          <div class="relative">
            <input type="password" class="w-full mb-8 h-12 border p-2" @keyup="validateFormat" v-model="password" placeholder="· · · · · · ·" />
            <span class="absolute left-0 bottom-1 text-red-700 block pl-2 text-xs font-bold" v-if="passwordnotrules">* La contraseña no cumple con los criterios necesarios.</span>
            <span class="absolute left-0 bottom-2 text-red-700 block pl-2 text-xs font-bold" v-if="passworderror">* Campos obligatorios.</span>
          </div>
          <div class="relative">
            <input type="password" class="rosa w-full mb-8 mt-3 h-12 p-2 border font-bold text-sm" v-model="passwordRepeat" placeholder="Confirmar nueva contraseña" />
            <span class="absolute left-0 -bottom-1 text-red-700 text-left text-xs font-bold p-2" v-if="passwordnotisame">* Las contraseñas no coinciden.</span>
            <span class="absolute left-0 -bottom-1 text-red-700 text-left text-xs font-bold p-2" v-if="passworderror">* Campos obligatorios.</span>
          </div>
        </div>
        <button @click="changePaswword" class="block w-full text-white h-12 rounded-md font-medium" :class="'bt-' + classGeneral ">
          Cambiar
        </button>
      </div>
    </div>
    <CambioContrasena v-if="openModal" @closeModal="closeModal" />
  </div>
</template>

<script>
import CambioContrasena from "@/components/Alertas/CambioContrasena";
export default {
  name: "PasswordNuevo",

  components: {
    CambioContrasena
  },

  data() {
    return {
      openModal: false,
      password: '',
      passwordRepeat: '',

      passwordnotisame: false,
      passwordnotrules: false,
      passworderror: false
    }
  },

  methods: {
    changePaswword(){
      let store = JSON.parse(localStorage.getItem('data'))
      var valid = this.validatePaswoord()
      if(valid)  this.passworderror = false, this.passwordnotrules = false ,this.passwordnotisame = false
      var form = {
        username: store.user_codigo,
        password: this.password
      }
      this.$store.dispatch("loginStore/changePassword",form).then(
          (response) => {
            if(response.success == true){
                this.openModal = true
            }
          }
      )
    },

    validatePaswoord(){
      if(this.password == "" && this.passwordRepeat == ""){
        this.passworderror = true
        return false
      }else if(this.password === this.passwordRepeat){
        if(this.password !== "" || this.passwordRepeat !== ""){
          this.passworderror = false
        }
        return true
      }else if(this.password !== this.passwordRepeat){
        if(this.password !== "" || this.passwordRepeat !== ""){
          this.passworderror = false
        }
        this.passwordnotisame = true
        return false
      }
    },

    validateFormat(){
      var txt = this.password
      var cant = txt.length
      var min = /[a-z]/.test(txt)
      var may = /[A-Z]/.test(txt)
      var num = /[0-9]/.test(txt)

      if(txt < 8) return 

      if(!min) return this.passwordnotrules = true

      if(!may) return this.passwordnotrules = true

      if(!num) return this.passwordnotrules = true

      this.passwordnotrules = false

    },

    closeModal(){
      this.openModal = false
      this.$router.push({ path: 'login' }).catch(()=>{})
    }
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
