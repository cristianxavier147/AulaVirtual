<template>
  <div>
    <div class="p-6 bg-white rounded-md">
      <span class="mb-4">Se ha validad el teléfono celular correctamente</span>
      <button class="text-white rounded-sm" :class="'bt-'+classGeneral">Entendido</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "ValidarCelular",
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
