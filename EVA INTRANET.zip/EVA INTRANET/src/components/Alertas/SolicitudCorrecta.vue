<template>
  <div class="overlay">
    <div class="p-10 bg-white rounded-md" style="width:404px">
        <div class="mb-8 size-text-16 font-bold text-left">Se ha generado la solicitud correctamente</div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Entendido</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "SolicitudCorrecta",
  methods: {
    save(){
      this.$emit('closeModal',false)
    }
  },
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
