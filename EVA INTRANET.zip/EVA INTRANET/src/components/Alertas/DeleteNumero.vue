<template>
  <div>
    <div class="p-4 bg-white rounded-md">
      <span class="mb-4">¿Estás seguro que quieres eliminar tu xxxxxx?</span>
      <div class="flex">
        <button class="bg-gray-500 rounded-sm">Regresar</button>
        <button class="text-white rounded-sm" :class="'bt-'+classGeneral">Sí, seguro</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DeleteNumero",
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
