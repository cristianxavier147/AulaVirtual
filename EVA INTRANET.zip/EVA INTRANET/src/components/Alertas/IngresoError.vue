<template>
  <div>
    <div class="p-6 bg-white rounded-md">
      <span class="mb-4">Ha ocurrido un error al ingresar a este enlace</span>
      <button class="text-white rounded-md" :class="'bt-'+classGeneral">Regresar</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "IngresoError",
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
