<template>                                      
  <div id="btnFlotante" class="text-right fixed bottom-0 right-0 px-11 mb-14">

                <span v-if="FiltrosSemana">                  
                    <button class="py-3 px-10 text-white rounded-md" :class="'bg-'+classGeneral+'-600'" @click.stop="AbrirPopup">
                        Ingresa a tu clase            
                    </button>
                </span>
                <span v-else>

                </span>
                              
                             



        <div ref="1133" v-if="ModalAbierto" v-click-outside="CerrarPopup" id="hide" class="fixed z-10 inset-0" aria-labelledby="dialog-1-title" >
          <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0 -pxm-4 -pbm-20 -mhs-clase">

            <div class="fixed inset-0 bg-opacity-75 transition-opacity blr" aria-hidden="true"></div>


            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
            
            <div class="inline-block align-bottom bg-white rounded-sm text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full mrgntops -widthmanuals -sombra-xl">
              
              <div class="bg-white px-4 pt-5 pb-6 sm:p-6 sm:pb-6">
                <div class="sm:flex sm:items-start">
                  <div class="mt-3 text-center wd sm:mt-0 sm:ml-4 sm:text-left">
                    
                      <h4 class="text-sm leading-6 font-bold -mrgn-bttm-clase -txtmobilhclases" id="dialog-1-title">
                        Elige el curso que quieres marcar asistencia ahora
                      </h4>

                    <div class="mt-2">

                    </div>
                    

                    <div class="mt-8">

                      <div>


                        <div class="divTable">

                          <div class="divTableBody">
                            
                              

                                <div class="divTableRows" v-for="(f, indexb) in SemanaHorario" :key="indexb">
                                  <span v-for="(b, indexa) in HorarioClaseBoton" :key="indexa">
                                        
                                    <span v-if="f.Fecha === FechaA && b[0].IdSeccion === f.IdSeccion">

                                        <div class="divTableCells font-bold text-gray-400 size-text-11 size-text-res-10">
                                            {{f.CursoNombre | capitalize}}
                                            
                                        </div>
                                        <div class="divTableCells">
                                            
                                            <span>
                                            
                                            <span v-if="b[0].Valor === ' '" >
                                              
                                                
                                            <div v-if="loader" class="lds-dual-ring loaderCursos" :class="'loaderCursos-' + classGeneral">
                                            </div>
                                            <div v-else>
                                                <button class="py-2 px-5 text-white rounded-md text-sm -whitesp" :class="'bg-'+classGeneral+'-600'" v-on:click="EnviarAsistencia(f.IdSeccion); seen = !seen">
                                                Marcar Asistencia 
                                                </button>
                                            </div>
                                            </span>
                                            <span v-else>
                                                
                                                <span class="linea  -fmob font-bold text-sm -whitesp -smr1" :class="'text-' + classGeneral + '-600'">
                                                    <img :src="require('@/assets/global/check-'+classGeneral+'.svg')" class="linea" /> Asistencia marcada
                                                </span>
                                            </span>

                                            </span>


                                        </div>
                                        <div class="divTableCells">
                                            <span v-if="b[0].UrlClaseVirtual === ''">
                                                <a href="https://teams.microsoft.com/" target="_blank">
                                                <button class="py-2 px-5 text-white rounded-md text-sm -whitesp" :class="'bg-'+classGeneral+'-600'">
                                                    Ir a tu clase
                                                </button>
                                                </a>
                                            </span>
                                            <span v-else>
                                                <a :href="b[0].UrlClaseVirtual" target="_blank">
                                                <button class="py-2 px-5 text-white rounded-md text-sm -whitesp" :class="'bg-'+classGeneral+'-600'">
                                                    Ir a tu clase
                                                </button>
                                                </a>                                        
                                            </span>
                                        </div>

                                    </span>


                                  </span>
                                </div>

                            
                          </div>

                        </div>

                   



                      </div>

                    </div>



                  </div>
                </div>
              </div>

            </div>
         <span class="inline-block align-bottom rounded-lg text-left overflow-hidden transform transition-all sm:my-8 sm:align-top cerrarclase px-4 pt-5 pb-4 sm:p-6 sm:pb-4" @click="CerrarPopup()"></span>   
          </div>
        </div>
    
 </div>
</template>

<script>
import Vue from 'vue';
import { filtrosx } from "@/mixins/filtros";
import { nameCursoService } from "@/mixins/nameCurso";
import { eventBus } from "@/config/eventBus";
import { mapState } from "vuex";

Vue.directive('click-outside'   ,{
  bind: function (el, binding, vnode) {
      el.eventSetDrag = function () {
          el.setAttribute('data-dragging', 'yes');
      }
      el.eventClearDrag = function () {
          el.removeAttribute('data-dragging');
      }
      el.eventOnClick = function (event) {
          var dragging = el.getAttribute('data-dragging');
          if (!(el == event.target || el.contains(event.target)) && !dragging) {
              vnode.context[binding.expression](event);
          }
      };
      document.addEventListener('touchstart', el.eventClearDrag);
      document.addEventListener('touchmove', el.eventSetDrag);
      document.addEventListener('click', el.eventOnClick);
      document.addEventListener('touchend', el.eventOnClick);
  }, unbind: function (el) {
      document.removeEventListener('touchstart', el.eventClearDrag);
      document.removeEventListener('touchmove', el.eventSetDrag);
      document.removeEventListener('click', el.eventOnClick);
      document.removeEventListener('touchend', el.eventOnClick);
      el.removeAttribute('data-dragging');
  },
});


export default {

  data() {
    return {
        ModalAbierto: false,
        loader: false,
        seen: false,
        SemanaHorario: [],
        Seccion : '',
        Hora: '',
        FechaA: '',
        FechaActual: '',
        HoraInicio: '',
        SemanaHorarioSemana: [],
        tres:3,
        cuatro: 4,
        Cero: "00",
        abcs: [],
        count: 0,
        seens: '',
        seeeen: false,
        Test: '',
        IdActor: '',
        FechaAhoraI: '',
        IdSecccion: '',
        Orden: '',
        loading: true,
        Fechas: [],
        lstAlumnoCursoAsistencia: [],
        IdHorariox: '',
        IdSesionx: '',
        lstHorarioSesion: [],
        ConteoArrayFecha: '',
        lstAlumnoCursoAsistenciaMultiple: [],
        allCursos: [],
        IdHorarioA: '',
        IdSessionA: '',
        UrlTeam: '123',
        HorarioClaseBoton: [],
        id: [],
        ids: [],
        res: [],
        SemanaHorarioD: []
    }
  },

    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
        filtross(valor) {
            return filtrosx.Conteo(valor);
        },     
        sliceOne(valor) {
            return filtrosx.SepararUno(valor);
        },      
        sliceTwo(valor) {
            return filtrosx.SepararDos(valor);
        },
        Minimo(valor) {
            return filtrosx.minimo(valor);
        }             
    },    
   
    methods: {
        AbrirPopup() {
        this.ModalAbierto = true;
        },
        CerrarPopup() {
        this.ModalAbierto = false;
        },    
        selAc(){
            this.selectM()
        },
        Union() {
            var Fecha = new Date(this.FechaActual);
            var Year = Fecha.getFullYear();
            var MesR = Fecha.getMonth()+1;
            var Mes = (MesR<10?'0':'') + MesR;
            var Dia = (Fecha.getDate()<10?'0':'') + Fecha.getDate();
            var HoraR = Fecha.getHours();
            var Hora = (HoraR<10?'0':'') + HoraR;
            var MinutosR = Fecha.getMinutes();
            var Minutos = (MinutosR<10?'0':'') + MinutosR;
            this.FechaA = Dia + "/" + Mes + "/" + Year;
            this.Hora = Hora + Minutos         
        },        
        selectM(){
            setTimeout(() => {
                
                let horarios = JSON.parse(localStorage.getItem('horarios'))
                this.allCursos = horarios.LstFacilitadorSemanaHorario
            }, 1000);
        },        
        Verificar(s){
            
            this.SemanaHorario.forEach((empi, index) =>{
              if(empi.Fecha == this.FechaA){
                this.id.push(empi.IdSeccion);
                this.VerificarAsistencia(empi.IdSeccion);
              }
            });
        },
        show: function (I) {
        },
        CompararNumeroTres(respuesta){
            return this.$options.filters.filtross(respuesta) === this.tres;
        },   
        Minimo(respuesta){
            return this.$options.filters.Minimo(respuesta);
        },     
        CompararNumeroCuatro(respuesta){
            return this.$options.filters.filtross(respuesta) === this.cuatro;
        },                
        CompararCero(respuesta){
            return this.$options.filters.sliceOne(respuesta) === this.Cero;
        },
        CompararCeroL(respuesta){
            return this.$options.filters.sliceOne(respuesta) == 0;
        },          
        CompararCeros(respuesta){
            return this.$options.filters.sliceTwo(respuesta) === this.Cero;
        },      
        callFunction: function () {
            const today = new Date();
            const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            const dateTime = date +' '+ time;
            this.FechaActual = dateTime;

        },

        Matricula(){
            setTimeout(() => {
                let horarios = JSON.parse(localStorage.getItem('horarios'))
                this.SemanaHorario = horarios.LstFacilitadorSemanaHorario;
                this.SemanaHorarioD = horarios.LstFacilitadorSemanaHorario;
            }, 1000);
        },


        EnviarAsistencia(IdSE) {
            let store = JSON.parse(localStorage.getItem('data'))
            var IdSeccion = IdSE;
            var formdata = {
                'IdSeccions' : IdSeccion,
                'IdHorarios': this.IdHorarioA,
                'IdSesions': this.IdSessionA,
                'IdAlumnos': store.user_id_actor,
                'Valors': "A",
                'Observacions': "Marcado manual. Eva",
                'IdUsuarios': store.user_id_usuario,
            }   
            this.$store.dispatch('marcadorapidoStore/marcadorapido' , formdata).then(
                (response) => {
                    if(response.success){ 
                        //this.ModalAbierto = false;
                        //this.loader = true
                        console.log(IdSeccion)
                        console.log(this.IdHorarioA)
                        console.log(this.IdSessionA)
                        console.log(response)
                        //
                    }else{
                        console.log("fallo")
                        console.log(response)
                    }
                }
            )
            this.ModalAbierto = false;
            setTimeout(() => window.location.reload(), 3000);
            //this.VerificarAsistencia(IdSE)
        },
        EnviarAsistenciaMultiple(IdS) {
            let store = JSON.parse(localStorage.getItem('data'))
            var formdata = {
                'IdSeccions' : IdS,
                'IdHorarios': "1",
                'IdSesions': "1",
                'IdAlumnos': store.user_id_actor,
                'Valors': "A",
                'Observacions': "Marcado manual. Eva",
                'IdUsuarios': store.user_id_usuario,
            }   
            this.$store.dispatch('marcadorapidoStore/marcadorapido' , formdata).then(
                (response) => {
                    if(response.success){ 
                    }
                }
            )
        },             
        VerificarAsistencia(imp) {
            let store = JSON.parse(localStorage.getItem('data'))
            var formdata = {
                'IdSeccions' : imp,
                'IdAlumnos': store.user_id_actor,
            }   
            this.$store.dispatch('marcadorapidoStore/verificarmarcado' , formdata).then(
                (response) => {
                    if(response){
                      this.res = response;
                        this.loading = false;
                        this.HorarioClaseBoton.push(response.results.lstAlumnoCursoAsistencia);
                        this.IdHorarioA = response.results.lstAlumnoCursoAsistencia[0].IdHorario;
                        this.IdSessionA = response.results.lstAlumnoCursoAsistencia[0].IdSesion;
                        this.ids.push(response.results.lstAlumnoCursoAsistencia[0].IdSeccion);
                        this.UrlTeam = response.results.lstAlumnoCursoAsistencia[0].UrlClaseVirtual;                        
                        localStorage.setItem('UrlTeam', this.UrlTeam);
                        this.lstAlumnoCursoAsistencia = response.results.lstAlumnoCursoAsistencia;
                        this.lstAlumnoCursoAsistenciaMultiple = response.results.lstAlumnoCursoAsistencia;
                    }
                }
            )
        }



    },   

    computed: {  
        FiltrosConteoArraySemana() {
            var ret = {}
            for (let i in this.SemanaHorario) {
                if(this.SemanaHorario[i].Fecha == this.FechaA){
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1,
                    }
                }
            }
            return ret.prueba.count;
        },
        sortedArray() {
        var Horas = this.Hora;
        function compare(a, b) {
                if (a.Inicio > b.Inicio){
                    return -1 + "menor";
                }
                if (a.Inicio < b.Inicio){
                    return 1 + "mayor";
                }
                return 0;
        }

        return this.SemanaHorario.sort(compare);
        },        
        FiltrosSemana() {
            var ret = {}
            for (let i in this.SemanaHorarioD) {
                if(this.SemanaHorarioD[i].Fecha == this.FechaA){
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                    }
                }
            }
            return ret.prueba;
        },
        FiltrosSemanaMultiple(Id) {
            var Ids = Id;
            var ret = {}
            for (let i in this.lstAlumnoCursoAsistenciaMultiple) {
                let key="prueba"
                ret[key] = {
                    count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                }
            }
            return ret;
        },
        store(){
            return JSON.parse(localStorage.getItem('data'))
        },
        classGeneral(){
            return localStorage.getItem('classGeneral')
        }
          
    },
      
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
        filtross(valor) {
            return filtrosx.Conteo(valor);
        },     
        sliceOne(valor) {
            return filtrosx.SepararUno(valor);
        },      
        sliceTwo(valor) {
            return filtrosx.SepararDos(valor);
        },
        Minimo(valor) {
            return filtrosx.minimo(valor);
        }             
    },   

  created() {
    this.selAc()
    this.callFunction()
    this.Matricula()
    this.Union()
    this.interval = setTimeout(() => this.Verificar(), 1000);
    this.interval = setInterval(() => this.callFunction(), 1000);   
  },
}
</script>
<style>
.bg-purple-600 {
    --tw-bg-opacity: 1 !important;
    background-color: #805ad5 !important;
}
.bg-red-600 {
    --tw-bg-opacity: 1 !important;
    background-color: #C92033 !important;
}
.-whitesp{
  white-space: pre;
}
.-widthmanuals{
    width: auto !important;
    max-width: 100% !important;
}


.divTableCells, .divTableHead {
	border: 1px solid #fff;
	display: table-cell;
	padding: 3px 30px;
  white-space: nowrap;
  width: 75%;  
}

.mrgntops{
  margin-top: 5%;
}

.divTableRows{
  display: table-caption;
}

.-mrgn-bttm-clase{
  margin-bottom: -3%;
}

.cerrarclase{
    background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgdmlld0JveD0iMCAwIDMyIDMyIj4NCiAgPGcgaWQ9ImNsb3NlIj4NCiAgICA8cmVjdCBpZD0iUmVjdMOhbmd1bG9fNTE3MCIgZGF0YS1uYW1lPSJSZWN0w6FuZ3VsbyA1MTcwIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyIDMyKSByb3RhdGUoMTgwKSIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMCIvPg0KICAgIDxwYXRoIGlkPSJUcmF6YWRvXzE2OTM0IiBkYXRhLW5hbWU9IlRyYXphZG8gMTY5MzQiIGQ9Ik0xOC4zNDksMTZsNy4xNjQtNy4xNDhhMS42NzMsMS42NzMsMCwxLDAtMi4zNjYtMi4zNjZMMTYsMTMuNjUsOC44NTMsNi40ODZBMS42NzMsMS42NzMsMCwwLDAsNi40ODcsOC44NTJMMTMuNjUxLDE2LDYuNDg3LDIzLjE0N2ExLjY3MywxLjY3MywwLDEsMCwyLjM2NiwyLjM2NkwxNiwxOC4zNDlsNy4xNDcsNy4xNjRhMS42NzMsMS42NzMsMCwxLDAsMi4zNjYtMi4zNjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDApIiBmaWxsPSIjZmZmIi8+DQogIDwvZz4NCjwvc3ZnPg0K);
    background-repeat: no-repeat,repeat;
    margin-top: 15% !important;
    cursor: pointer;

}
@media only screen and (max-width: 768px) {
    .divTableCells, .divTableHead {
        border: 1px solid #fff;
        display: flex;
        padding: 3px 30px;
        white-space: nowrap;
        width: 100%;
        align-content: stretch;
        flex-wrap: nowrap;
        flex-direction: column;
        justify-content: flex-start;
        align-items: stretch;
    }
    .divTableRows {
        display: block;
    }
    .cerrarclase {
        background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgdmlld0JveD0iMCAwIDMyIDMyIj4NCiAgPGcgaWQ9ImNsb3NlIj4NCiAgICA8cmVjdCBpZD0iUmVjdMOhbmd1bG9fNTE3MCIgZGF0YS1uYW1lPSJSZWN0w6FuZ3VsbyA1MTcwIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyIDMyKSByb3RhdGUoMTgwKSIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMCIvPg0KICAgIDxwYXRoIGlkPSJUcmF6YWRvXzE2OTM0IiBkYXRhLW5hbWU9IlRyYXphZG8gMTY5MzQiIGQ9Ik0xOC4zNDksMTZsNy4xNjQtNy4xNDhhMS42NzMsMS42NzMsMCwxLDAtMi4zNjYtMi4zNjZMMTYsMTMuNjUsOC44NTMsNi40ODZBMS42NzMsMS42NzMsMCwwLDAsNi40ODcsOC44NTJMMTMuNjUxLDE2LDYuNDg3LDIzLjE0N2ExLjY3MywxLjY3MywwLDEsMCwyLjM2NiwyLjM2NkwxNiwxOC4zNDlsNy4xNDcsNy4xNjRhMS42NzMsMS42NzMsMCwxLDAsMi4zNjYtMi4zNjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDApIiBmaWxsPSIjZmZmIi8+DQogIDwvZz4NCjwvc3ZnPg0K);
        background-repeat: no-repeat,repeat;
        margin-top: 15% !important;
        cursor: pointer;
        display: none !important;
    }
    .-pxm-4{
        padding-left: 0rem !important;
        padding-right: 0rem !important;
    }
    .-pbm-20{
        padding-bottom: 0rem !important;
    }
    .-mhs-clase{
        min-height: 60vh !important;
    }
    .blr {
        -webkit-backdrop-filter: blur(8px) saturate(120%) contrast(50%)!important;
        backdrop-filter: blur(8px) saturate(120%) contrast(50%)!important;
        background: white !important;
    }
    .-sombra-xl{
        --tw-shadow: 0 !important;
    }
    .-txtmobilhclases{
        font-size: 22px;
        text-align: justify;
    }
}
.-smr1{
    margin-left: -25% !important;
}
</style>