<template>
  <div id="fullPage" class="login" :class="'fnd-' + this.classGeneral ">
    <div id="brandingWrapper" class="float-left">
      <div class="hidden md:fixed md:block">
        <img v-if="this.classGeneral === 'purple'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-idat.png" alt="logo-idat" class=" md:h-44 md:relative top-80 left-32" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'red'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-zegel.png" alt="logo-idat" class=" md:h-44 md:relative top-80 left-32" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'blue'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-corriente.png" alt="logo-idat" class=" md:h-44 md:relative top-80 left-32" rel="preload" width="100" height="100" />
      </div>
      <div id="branding">
        <img v-if="this.classGeneral === 'purple'" src="https://cdn.idat.edu.pe/eva/img/banner/banner-idat.jpg" alt="banner" class="object-cover w-full h-full" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'red'" src="https://cdn.idat.edu.pe/eva/img/banner/banner-zegel.jpg" alt="banner" class="object-cover w-full h-full" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'blue'" src="https://cdn.idat.edu.pe/eva/img/banner/banner-corriente.jpg" alt="banner" class="object-cover w-full h-full" rel="preload" width="100" height="100" />
      </div>
    </div>
    <div id="contentWrapper" class="float-right bg-pr" :class="'fnd-' + this.classGeneral ">
      <div id="content" class="h-auto">
        <img  src="https://cdn.idat.edu.pe/eva/img/svg/logo-eva.svg" alt="logo-eva" class="block w-3/12 mt-5 mb-40 ml-4 md:w-32 md:mx-auto md:mt-20 md:mb-14" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'purple'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-idat.png" alt="logo-idat" class=" h-32 mx-auto mb-12 md:w-2/12 -mt-28 md:hidden" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'red'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-zegel.png" alt="logo-idat" class=" h-32 mx-auto mb-12 md:w-2/12 -mt-28 md:hidden" rel="preload" width="100" height="100" />
        <img v-if="this.classGeneral === 'blue'" src="https://cdn.idat.edu.pe/eva/img/logos/logo-corriente.png" alt="logo-idat" class=" h-32 mx-auto mb-12 md:w-2/12 -mt-28 md:hidden" rel="preload" width="100" height="100" />
        <h1 class="mb-10 font-bold text-white md:mb-16 size-text-25">¡BIENVENID@!</h1>
        <!-- inputs -->
        <!-- input codigo alumno -->
        <div>
          <input @keyup="savetoStore" type="text" placeholder="Código de estudiante" class="w-5/6 h-12 py-2 pl-3 mt-2 font-bold border-2 border-transparent rounded size-text-16" name="codigo" v-model="form.codigo" :class="this.obligCod ? 'border-red-500 border-2' : ''" />
          <div class="text-left ml-14 pt-1" style="height: 25px;">
            <span class="font-bold text-white size-text-16" v-if="errorCod">*Código incorrecto</span>
            <span class="font-bold text-white size-text-16" v-if="obligCod">Campo obligatorio</span>
          </div>
        </div>
        <br />
        <!-- input contaseña -->
        <div>
          <input type="password" placeholder="Contraseña" autocomplete="on" class="w-5/6 h-12 py-2 pl-3 font-bold rounded size-text-16" name="password" v-model="form.password" :class="this.obligCod ? 'border-red-500 border-2' : ''" />
          <div class="text-left ml-14 pt-1" style="height: 25px;">
            <span class="font-bold text-white size-text-16" v-if="errorCon">*Contraseña incorrecta</span>
            <span class="font-bold text-white size-text-16" v-if="obligCod">Campo obligatorio</span>
          </div>
        </div>
        <br />
        <div class="relative flex items-center justify-center" style="height: 25px">
          <span class="font-bold text-white size-text-16" v-if="errorOther">{{ txtError }}</span>
        </div>
        <!-- button ingresar-->
        <!-- <button class="w-11/12 h-12 text-white bg-black rounded mt-14 md:mt-1 md:w-5/6" >
          <div class="flex items-center justify-center">
            <div class="lds-dual-ring" v-if="preloader"></div>
            <span class="size-text-16">Ingresar</span>
          </div>
        </button> -->

        <div class="h-12 px-10 font-bold rounded relative cursor-pointer" >
          <div id="preloder">
            <div id="submit" class="" @click="handleSubmit">
              <span id="nameSubmit">Ingresar</span>
              <div id="carga" class="relative" style="height: 50px">
                <div class="loader">Loading...</div>
              </div>
            </div>
            <div id="raya" class="w-full mr-3">
              <div :class="'fnd-'+this.classGeneral" class="rounded-md" :style="'width:' + valornumerico + '%'" style="height: 5px"></div>
            </div>
          </div>
        </div>

        <br />
        <!-- Olvidé mi contraseña -->
        <router-link to="/restablecerPassword" class="block mt-6 font-bold text-white underline size-text-16"> Olvidé mi contraseña </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { responseService } from "@/mixins/response";

export default {
  name: "Login",
  data() {
    return {
      codAlumno: "",
      password: "",
      error: false,
      errorMsg: "",
      form: {
        codigo: "",
        password: "",
      },
      preloader: false,
      errorCod: false,
      errorCon: false,
      errorOther: true,
      txtError: "",
      errorCod: false,
      errorCon: false,
      errorOther: true,
      txtError: "",
      obligCod: false,
      obligCon: false,

      submit: true,
      precarga: false,
      valornumerico: 0
    };
  },

  methods: {
    envio(type){
      if(type === 1){
        var name = document.getElementById('nameSubmit')
        name.classList.add('close')

        var content = document.getElementById('submit')
        content.classList.add('minimizar')

        var carga = document.getElementById('carga')
        carga.classList.add('mostrar')

        var raya = document.getElementById('raya')
        raya.classList.add('margen')

        var segundos = (3000 - 1) / 10;
        this.valornumerico = 1;
        this.valorCarga(segundos);
      }else{
        var name = document.getElementById('nameSubmit')
        name.classList.remove('close')

        var content = document.getElementById('submit')
        content.classList.remove('minimizar')

        var carga = document.getElementById('carga')
        carga.classList.remove('mostrar')

        var raya = document.getElementById('raya')
        raya.classList.remove('margen')

        this.valornumerico = 1;
      }
    },
    valorCarga(initial) {
      var id = setInterval(() => {
        var valinitial = initial;
        this.valornumerico = this.valornumerico + Math.ceil((100 * this.valornumerico) / valinitial);

        if (this.valornumerico > 100) {
          this.valornumerico = this.valornumerico * 100;
        }
        if (this.valornumerico >= valinitial) {
          this.valornumerico = 100;
          clearInterval(id);
        }
      }, 500);
    },
    savetoStore(){
      localStorage.setItem("codigouser", this.form.codigo);
    },
    handleSubmit() {
      this.envio(1)
      // this.preloader = true;
      this.$store.dispatch("loginStore/login", this.form)
      .then((response) => {
        if (!response.success) {
          this.envio(2)
          if (response.msg == "No ingreses solo espacios en blanco") {
            if (this.form.codigo == "") {
              this.obligCod = true;
            }

            if (this.form.password == "") {
              this.obligCod = true;
            }
          } else {
            this.obligCod = false;
          }

          if (response.msg == "1") {
            this.errorCod = true;
          } else {
            this.errorCod = false;
          }

          if (response.msg == "2") {
            this.errorCon = true;
          } else {
            this.errorCon = false;
          }

          if (response.msg == "3") {
            this.errorOther = true;
            this.txtError = "Usuario bloqueado";
          } else {
            this.errorOther = false;
            this.txtError = "";
          }

          if (response.msg == "4") {
            this.errorOther = true;
            this.txtError = "Usuario desabilitado";
          } else {
            this.errorOther = false;
            this.txtError = "";
          }

          this.preloader = false;

          if (response.code === undefined) {
            return responseService.handleError(429, response.errors);
          }
          return responseService.handleError(response.code, response.error);
        } else {
          let forceChange = String(localStorage.getItem("force_change"));
          this.valornumerico = 100

          let store = JSON.parse(localStorage.getItem('data'))

          let dataFormCursos = {
            IdTipoUsuario: store.user_type_usuario,
            IdActor: store.user_id_actor
          };

          let dataFormMenu = {
            IdTipoUsuario: store.user_type_usuario,
            IdActor: store.user_id_actor,
            IdUltimaMatricula: store.user_matricula,
            IdUsuario: store.user_id_usuario,
            Login: store.user_codigo,
            LoginEncriptado: store.user_codigo_encryp,
          };

          this.$store.dispatch("sidebarStore/cursos", dataFormCursos);
          this.$store.dispatch("sidebarStore/sidebar", dataFormMenu)

          setTimeout(() => {
            if(response.results.Sesion.CambiarContraseña){
              this.$router.push({ name: "newPassword" });
            }else{
              this.$router.push({ name: "dashboard" });
            }
          }, 500);
          // this.preloader = false;
        }
      });
    },
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  }
};
</script>
