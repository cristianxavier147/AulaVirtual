<template>
  <nav class="fixed z-20 w-full bg-black">
    <div class="px-2 sm:px-6 lg:px-8">
      <div class="relative flex items-center justify-between h-16">
        <div class="absolute inset-y-0 left-0 flex items-center sm:hidden"></div>
        <div class="sm:items-stretch sm:justify-start ml-1.5">
          <!-- LOGO ZOOM -->
            <router-link to="/dashboard" v-if="validate === true">
              <div class="flex items-center flex-shrink-0">
                <img class="block" src="https://cdn.idat.edu.pe/eva/img/svg/logo-eva.svg" alt="eva" />
              </div>
            </router-link>
            <div class="flex items-center flex-shrink-0" v-else>
              <img class="block" src="https://cdn.idat.edu.pe/eva/img/svg/logo-eva.svg" alt="eva" />
            </div>
        </div>

        <div class="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
          <!-- Icono mail -->
          <a href="https://outlook.office.com/mail/" target="_blank">
            <div class="md:mr-16 mr-7">
              <svg xmlns="http://www.w3.org/2000/svg" width="23.75" height="19" viewBox="0 0 23.75 19" class="cursor-pointer">
                <path id="Icon_material-mail-outline" data-name="Icon material-mail-outline" d="M24.375,6h-19A2.372,2.372,0,0,0,3.012,8.375L3,22.625A2.382,2.382,0,0,0,5.375,25h19a2.382,2.382,0,0,0,2.375-2.375V8.375A2.382,2.382,0,0,0,24.375,6Zm0,16.625h-19V10.75l9.5,5.938,9.5-5.937Zm-9.5-8.312-9.5-5.937h19Z" transform="translate(-3 -6)" fill="#fff" />
              </svg>
            </div>
          </a>

          <!-- Icono campana -->
          <div class="mr-7 md:mr-16">
            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="20" viewBox="0 0 17 20" class="cursor-pointer">
              <path
                id="Trazado_5258"
                data-name="Trazado 5258"
                d="M-54.022,651.691a2.005,2.005,0,0,0,2-1.988.011.011,0,0,0-.011-.012h-3.978a.011.011,0,0,0-.011.012A2.005,2.005,0,0,0-54.022,651.691Zm6.5-6,0-.008v-5.5a6.435,6.435,0,0,0-4.992-6.3.01.01,0,0,1-.008-.01v-.692a1.538,1.538,0,0,0-1.5-1.5,1.538,1.538,0,0,0-1.5,1.5v.692a.011.011,0,0,1-.008.01,6.435,6.435,0,0,0-4.992,6.3v5.5l0,.008-1.79,1.789a.707.707,0,0,0-.207.5h0a.706.706,0,0,0,.707.707h15.586a.707.707,0,0,0,.707-.707h0a.711.711,0,0,0-.207-.5Zm-2.014,1h-8.978a.01.01,0,0,1-.011-.011v-6.424a4.544,4.544,0,0,1,5.043-4.533,4.48,4.48,0,0,1,3.957,4.468v6.489A.01.01,0,0,1-49.533,646.691Z"
                transform="translate(62.522 -631.691)"
                fill="#fff"
              />
            </svg>
          </div>

          <!-- Icono user -->
          <div class="-mr-2 md:mr-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" class="cursor-pointer" @click.prevent="toggleModal">
              <path
                id="Trazado_4882"
                data-name="Trazado 4882"
                d="M704.646,501.441l0,0a9.985,9.985,0,0,0-7.069-2.907h-.045a10,10,0,1,0-.016,20h.045a10.03,10.03,0,0,0,7.088-17.09Zm-7.1,2.271a2.423,2.423,0,1,1-2.426,2.423A2.428,2.428,0,0,1,697.544,503.711Zm0,6.955a4.973,4.973,0,0,1,4.9,4.131,7.944,7.944,0,0,1-9.8,0A5,5,0,0,1,697.544,510.666Zm3.733-7.049a4.5,4.5,0,1,0-7.464,5.036,4.521,4.521,0,0,0,.57.687,7.038,7.038,0,0,0-3.4,3.705,7.961,7.961,0,1,1,13.111,0,7.047,7.047,0,0,0-3.393-3.7A4.5,4.5,0,0,0,701.277,503.617Z"
                transform="translate(-687.544 -498.531)"
                fill="#fff"
              />
            </svg>

            <!-- modal componente -->
            <perfil-component v-if="isVisibility" title="MI PERFIL" @toggle-modal="toggleModal">
              <!-- slot -->
              <div class="flex mt-4 text-sm font-bold md:mx-5 ">
                <div class="flex items-baseline justify-start text-gray-500 rounded-full md:p-3 lg:p-3 p-0 ">
                  <img :src="this.data.Foto" alt="" style="width: 100px;border-radius:50%">
                </div>
                <!-- nombres alumno -->
                <div class="text-left pt-2">
                  <h1 class="font-bold text-black size-text-16 pl-3 mb-2">
                    {{ this.data.Nombre}}
                    <br>
                    {{this.data.Apellidos}}
                  </h1>
                  <p class="size-text-12 font-bold text-gray-400 pl-3">{{ store.name_carrera }}</p>
                  <span class="size-text-12 font-bold text-gray-400 pl-3">{{ store.user_ciclo }}</span>
                </div>
              </div>
              <!-- Listas -->
              <div>
                <SeccionPerfil :data="this.data"/>
              </div>
            </perfil-component>
          </div>
          <!-- Nombre de alumno -->
          <div class="ml-1 md:mr-7" @click.prevent="toggleModal">
            <div>
              <span class="hidden text-white md:block cursor-pointer">{{ store.user_name }}</span>
            </div>
          </div>

          <!-- Icon triangulo abajo -->
          <div class="hidden md:block md:mr-3" @click.prevent="toggleModal">
            <svg xmlns="http://www.w3.org/2000/svg" width="9" height="8" viewBox="0 0 9 8" class="cursor-pointer">
              <path id="Polígono_6" data-name="Polígono 6" d="M4.5,0,9,8H0Z" transform="translate(9 8) rotate(180)" fill="#fff" />
            </svg>
          </div>
        </div>
      </div>
    </div>
    <!-- IraClases -->
    <span v-if="esBeneficios">
      
    </span>
    <span v-else>
      
      <IrClase />
    </span>
    <!-- IraClases -->
  </nav>
</template>

<script>
import PerfilComponent from "@/components/Alumnos/Perfil/PerfilComponent";
import SeccionPerfil from "@/components/Alumnos/Perfil/SeccionesPerfil/SeccionPerfil";
import IrClase from "@/components/Button/IrClase";
import { mapState } from "vuex";
import { eventBus } from "@/config/eventBus";
export default {
  name: "Navbar",
  components: {
    PerfilComponent,
    SeccionPerfil,
    IrClase
  },

  data() {
    return {
      isVisibility: false,
      data: [],
      validate: true
    };
  },
  
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },
    esBeneficios() {
      return this.$route.name === 'beneficios'
    }
  },

  methods: {
    toggleModal() {
      this.isVisibility = !this.isVisibility;
    },

    validateRoutes(){
      if(this.$route.name === "dashboard"){
        this.$store.dispatch("loginStore/rutas")
      }
    },
    allData(){
       this.$store.dispatch("perfilStore/perfil")
      .then((response) => {
        if(response.success == true){
          this.data = response.results.Perfil
          localStorage.setItem('photoPerfil',this.data.foto)
        }else{
          this.$router.push({ name: "login" });
          sessionService.removeSession();
        }
      })
    },
    validarContent(){
      let route = this.$route.path
      var arr = route.split('/')
      if(arr[1]  === 'onboarding'){
        this.validate = false
      }
    }
  },

  created() {
    this.validateRoutes()
    this.validarContent()
    this.allData()
    eventBus.$on("bloquearLink", this.validarContent);
  },
};
</script>

<style></style>
