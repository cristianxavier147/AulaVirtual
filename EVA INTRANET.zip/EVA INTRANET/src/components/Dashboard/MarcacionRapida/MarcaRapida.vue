<template>
 <div class="w-full">
    <!--<span v-for="(s, indexa) in SemanaHorario" :key="indexa">-->
       <span v-for="(f, indexb) in SemanaHorario" :key="indexb"> 
           <!-- <span v-for="(f, indexb) in allCursos" :key="indexb"> -->
               
            <span>
                
                <span v-if="f.Fecha == FechaA">

                       
                        <!-- menos a 3 digitos en hora -->
                        <span>
                            
                            <span>
                                 
                                <span >
                                

                                            <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion" />
                                      
                                            

                                </span>
                                <span>
                                    
                                    <span >
                                            
                                            <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />



                                    </span>                                    
                                </span>
                            </span>
                            <span>
                                
                                <span >
                                    
                                    <span>
                                        <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />

                                    </span>

                                </span>                            
                            </span>


                        </span>
                        <!-- menos a 3 digitos en hora -->
                        <!-- mayor a 4 digitos en hora -->
                        <span>
                            <span>
                               
                                
                                <span >
                                
                                        
                                        <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />


                                </span>
                                <span>
                                    <span >
                                    
                                            <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />


                                    </span>                                    
                                </span>
                            </span>
                            <span>
                                
                                <span>
                                
                                        <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />


                                </span>                            
                            </span>


                        </span>
                        <!-- mayor a 4 digitos en hora -->
                        <span>
                            <!-- si es distinto de una hora exacta -->
                            <span >
                            
                                    <input type="hidden" id="Seccion" name="Seccion" :value="f.IdSeccion" ref="IdSeccion"  />



                            </span>
                            <!-- si es distinto de una hora exacta -->
                        <span>
                        </span>



                </span>
                </span>
                <span v-else>
                </span>
            </span>



            </span>
                <!--<span v-else>
                </span>-->


    
    <!--</span>-->


    
 </div>
</template>
<script>
import { mapState } from "vuex";
import Vue from "vue";
import { nameCursoService } from "@/mixins/nameCurso";
import { filtrosx } from "@/mixins/filtros";
import { BIconChevronBarContract } from 'bootstrap-vue';
const moment = require('moment')
require('moment/locale/es')

Vue.use(require('vue-moment'), {
    moment
})
export default {
    name: "MarcaRapida",
    data() {
        return {
            abcs: [],
            count: 0,
            seen: '',
            seens: '',
            seeeen: false,
            seensx: true,
            Test: '',
            IdActor: '',
            FechaAhoraI: '',
            tres:3,
            cuatro: 4,
            FechaActual: '',
            IdSecccion: '',
            Cero: "00",
            SemanaHorario: [],
            Orden: '',
            loading: true,
            Fechas: [],
            FechaA: '',
            Hora: '',
            lstAlumnoCursoAsistencia: [],
            IdHorariox: '',
            IdSesionx: '',
            lstHorarioSesion: [],
            ConteoArrayFecha: '',
            lstAlumnoCursoAsistenciaMultiple: [],
            allCursos: [],
            IdHorarioA: '',
            IdSessionA: '',
            UrlTeam: '123'
        }
    },
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
        filtross(valor) {
            return filtrosx.Conteo(valor);
        },     
        sliceOne(valor) {
            return filtrosx.SepararUno(valor);
        },      
        sliceTwo(valor) {
            return filtrosx.SepararDos(valor);
        },
        Minimo(valor) {
            return filtrosx.minimo(valor);
        }             
    },    
    computed: {
        FiltrosConteoArraySemana() {
            var ret = {}
            for (let i in this.SemanaHorario) {
                if(this.SemanaHorario[i].Fecha == this.FechaA){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1,
                        
                    }

                }
            }
            return ret.prueba.count;
            //return this.FechaA
        },
        sortedArray() {
        var Horas = this.Hora;
        function compare(a, b) {
            //if(Horas >= a.Inicio && a.Fin <= Horas){
                if (a.Inicio > b.Inicio){
                    return -1 + "menor";
                }
                if (a.Inicio < b.Inicio){
                    return 1 + "mayor";
                }
                return 0;
            //}
        }

        return this.SemanaHorario.sort(compare);
        },        
        FiltrosSemana() {
            var ret = {}
            for (let i in this.SemanaHorario) {
                if(this.SemanaHorario[i].Fecha == this.FechaA){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                    }
                }
            }
            return ret.prueba.count;
            //return this.FechaA
        },
        FiltrosSemanaMultiple(Id) {
            var Ids = Id;
            var ret = {}
            for (let i in this.lstAlumnoCursoAsistenciaMultiple) {
                //if(this.lstAlumnoCursoAsistenciaMultiple[i].IdSeccion == Ids){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                    }
                //}
            }
            //return ret.prueba.count;
            //return this.FechaA
            return ret;
        }        
    },
   
    methods: {
        selAc(){
            this.selectM()
        },
        selectM(){
            setTimeout(() => {
                
                let horarios = JSON.parse(localStorage.getItem('horarios'))
                this.allCursos = horarios.LstFacilitadorSemanaHorario
            }, 1000);
        },        
        Verificar(s){
            const tokenEl = document.getElementById('Seccion');
            //console.log(tokenEl);
            //console.log(this.$refs.IdSeccion[0].value);
            //this.IdSecccion = this.$refs.IdSeccion[0].value;
            //console.log("S" + s);
            if(tokenEl === null){      
                //console.log("no paso");
            }else{
                this.IdSecccion = tokenEl.value;
                //console.log(this.IdSecccion); 
                //console.log("paso")
                this.interval = setTimeout(() => this.VerificarAsistencia(), 3000);                     
            }    
        },
        show: function (I) {
            //this.$bvModal.msgBoxOk(I)
        },
        CompararNumeroTres(respuesta){
            return this.$options.filters.filtross(respuesta) === this.tres;
        },   
        Minimo(respuesta){
            return this.$options.filters.Minimo(respuesta);
        },     
        CompararNumeroCuatro(respuesta){
            return this.$options.filters.filtross(respuesta) === this.cuatro;
        },                
        CompararCero(respuesta){
            return this.$options.filters.sliceOne(respuesta) === this.Cero;
        },
        CompararCeroL(respuesta){
            return this.$options.filters.sliceOne(respuesta) == 0;
        },          
        CompararCeros(respuesta){
            return this.$options.filters.sliceTwo(respuesta) === this.Cero;
        },      
        callFunction: function () {
            const today = new Date();
            const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            const dateTime = date +' '+ time;
            //const dateTime = date;
            this.FechaActual = dateTime;

        },

        Matricula(){
            setTimeout(() => {
                let horarios = JSON.parse(localStorage.getItem('horarios'))
                this.SemanaHorario = horarios.LstFacilitadorSemanaHorario
                this.ConteoArrayFecha = this.SemanaHorario.length;
            }, 1000);
        },

        Union() {
            var Fecha = new Date(this.FechaActual);
            var Year = Fecha.getFullYear();
            var MesR = Fecha.getMonth()+1;
            var Mes = (MesR<10?'0':'') + MesR;
            var Dia = (Fecha.getDate()<10?'0':'') + Fecha.getDate();
            var HoraR = Fecha.getHours();
            var Hora = (HoraR<10?'0':'') + HoraR;
            var MinutosR = Fecha.getMinutes();
            var Minutos = (MinutosR<10?'0':'') + MinutosR;
            this.FechaA = Dia + "/" + Mes + "/" + Year;
            this.Hora = Hora + Minutos         
        },
        EnviarAsistencia(IdSE) {
            let store = JSON.parse(localStorage.getItem('data'))
            var IdSeccion = IdSE;
            var formdata = {
                'IdSeccions' : IdSeccion,
                'IdHorarios': this.IdHorarioA,
                'IdSesions': this.IdSessionA,
                'IdAlumnos': store.user_id_actor,
                'Valors': "A",
                'Observacions': "Marcado manual. Eva",
                'IdUsuarios': store.user_id_usuario,
            }   
            this.$store.dispatch('marcadorapidoStore/marcadorapido' , formdata).then(
                (response) => {
                    if(response.success){ 
                        //console.log(response) 
                    }
                }
            )
            this.VerificarAsistencia()
        },
        EnviarAsistenciaMultiple(IdS) {
            let store = JSON.parse(localStorage.getItem('data'))
            var formdata = {
                'IdSeccions' : IdS,
                'IdHorarios': "1",
                'IdSesions': "1",
                'IdAlumnos': store.user_id_actor,
                'Valors': "A",
                'Observacions': "Marcado manual. Eva",
                'IdUsuarios': store.user_id_usuario,
            }   
            this.$store.dispatch('marcadorapidoStore/marcadorapido' , formdata).then(
                (response) => {
                    if(response.success){ 
                    }
                }
            )
        },             
        VerificarAsistencia() {
            let store = JSON.parse(localStorage.getItem('data'))
            var formdata = {
                'IdSeccions' : this.IdSecccion,
                'IdAlumnos': store.user_id_actor,
            }   
            this.$store.dispatch('marcadorapidoStore/verificarmarcado' , formdata).then(
                (response) => {
                    if(response){ 
                        this.loading = false;
                        //console.log(response)
                        //this.lstHorarioSesion = response.results.lstHorarioSesion;
                        this.IdHorarioA = response.results.lstAlumnoCursoAsistencia[0].IdHorario;
                        this.IdSessionA = response.results.lstAlumnoCursoAsistencia[0].IdSesion;
                        this.UrlTeam = response.results.lstAlumnoCursoAsistencia[0].UrlClaseVirtual;
                        localStorage.setItem('UrlTeam', this.UrlTeam);
                        //localStorage.setItem('URLTeam', "aqui 1");
                        this.lstAlumnoCursoAsistencia = response.results.lstAlumnoCursoAsistencia;
                        if (this.lstAlumnoCursoAsistencia[0].Valor === "A"){
                            this.seen = false;
                            this.seens = true;
                            //this.seen = true;
                            //this.seens = false;                            
                        }else{
                            this.seen = true;
                            this.seens = false;
                            //this.seen = false;
                            //this.seens = true;                            
                        }
                        this.lstAlumnoCursoAsistenciaMultiple = response.results.lstAlumnoCursoAsistencia;

                        //console.log("aqui" + this.lstAlumnoCursoAsistencia[0].Valor)
                     
                    }
                }
            )
        }



    },   

    // watch: {
    //     cursos(value){
    //         this.SemanaHorario = value.LstFacilitadorSemanaHorario
    //         this.ConteoArrayFecha = this.SemanaHorario.length;
    //     }
    // },


    computed: {
        // ...mapState("sidebarStore", ["horariosState", "preloaderState"]),
        // preloader() {
        // return this.preloaderState;
        // },        
        // cursos() {
        //     return this.horariosState;
        // },    
        FiltrosConteoArraySemana() {
            var ret = {}
            for (let i in this.SemanaHorario) {
                if(this.SemanaHorario[i].Fecha == this.FechaA){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1,
                        
                    }

                }
            }
            return ret.prueba.count;
            //return this.FechaA
        },
        sortedArray() {
        var Horas = this.Hora;
        function compare(a, b) {
            //if(Horas >= a.Inicio && a.Fin <= Horas){
                if (a.Inicio > b.Inicio){
                    return -1 + "menor";
                }
                if (a.Inicio < b.Inicio){
                    return 1 + "mayor";
                }
                return 0;
            //}
        }

        return this.SemanaHorario.sort(compare);
        },        
        FiltrosSemana() {
            var ret = {}
            for (let i in this.SemanaHorario) {
                if(this.SemanaHorario[i].Fecha == this.FechaA){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                    }
                }
            }
            return ret.prueba.count;
            //return this.FechaA
        },
        FiltrosSemanaMultiple(Id) {
            var Ids = Id;
            var ret = {}
            for (let i in this.lstAlumnoCursoAsistenciaMultiple) {
                //if(this.lstAlumnoCursoAsistenciaMultiple[i].IdSeccion == Ids){
                    //let key = this.SemanaHorario[i].Fecha
                    let key="prueba"
                    ret[key] = {
                        count: ret[key] && ret[key].count ? ret[key].count + 1 : 1
                    }
                //}
            }
            //return ret.prueba.count;
            //return this.FechaA
            return ret;
        }    ,
        store(){
            return JSON.parse(localStorage.getItem('data'))
        },
        classGeneral(){
            return localStorage.getItem('classGeneral')
        }
          
    },
      
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
        filtross(valor) {
            return filtrosx.Conteo(valor);
        },     
        sliceOne(valor) {
            return filtrosx.SepararUno(valor);
        },      
        sliceTwo(valor) {
            return filtrosx.SepararDos(valor);
        },
        Minimo(valor) {
            return filtrosx.minimo(valor);
        }             
    },    
  




}
</script>
<style>
.mglobalmarca {
    margin-top: 2% !important;
    margin-left: 7% !important;
    margin-right: 1%;
    margin-bottom: 7% !important;
}
.-colormrm{
    color: #7F8794;
}
.cerrarmarca {
    background-image: url('data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgdmlld0JveD0iMCAwIDMyIDMyIj4NCiAgPGcgaWQ9ImNsb3NlIj4NCiAgICA8cmVjdCBpZD0iUmVjdMOhbmd1bG9fNTE3MCIgZGF0YS1uYW1lPSJSZWN0w6FuZ3VsbyA1MTcwIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyIDMyKSByb3RhdGUoMTgwKSIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMCIvPg0KICAgIDxwYXRoIGlkPSJUcmF6YWRvXzE2OTM0IiBkYXRhLW5hbWU9IlRyYXphZG8gMTY5MzQiIGQ9Ik0xOC4zNDksMTZsNy4xNjQtNy4xNDhhMS42NzMsMS42NzMsMCwxLDAtMi4zNjYtMi4zNjZMMTYsMTMuNjUsOC44NTMsNi40ODZBMS42NzMsMS42NzMsMCwwLDAsNi40ODcsOC44NTJMMTMuNjUxLDE2LDYuNDg3LDIzLjE0N2ExLjY3MywxLjY3MywwLDEsMCwyLjM2NiwyLjM2NkwxNiwxOC4zNDlsNy4xNDcsNy4xNjRhMS42NzMsMS42NzMsMCwxLDAsMi4zNjYtMi4zNjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDApIiBmaWxsPSIjMDAwIi8+DQogIDwvZz4NCjwvc3ZnPg0K');
    background-repeat: no-repeat, repeat;
    margin-top: 13.5% !important;
}
.-mobil-mr{
    margin-top: 10%;
    margin-left: -50%;
}
.mrmr {
    margin-right: 50%;
}
.text-xlss {
    font-size: 1rem;
    line-height: 1.75rem;
}
.linea{
    display: inline;
}
.mr-l{
    margin-right: 1.5rem;
    font-weight: bold;
}
.-mlmr{
    margin-left: -12%;
    font-size: 13px;
}
.-mrtop{
    margin-left: -3% !important;
}

.-mlfa{
    margin-left: -12%;
    margin-top: 4%;
}
.-btnmr{
    margin-top: 4%;
    cursor: pointer;
}
.-mrbtmtitle{
    margin-bottom: -2%;
}

.grid-cols-33 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
} 
.gap-4444 {
    gap: 1rem;
}   
.grid1 {
    display: grid;
} 
.statico{
    height: 270px;
}    

@media screen and (min-width: 769px) and (max-width: 1080px) {
    .-mobil-mr{
        margin-top: -5%;
        margin-left: -30%;
        width: 200%;
    }
    .-fmob{
        font-size: 11px !important;
    }
    .grid-cols-33 {
        grid-template-columns: repeat(2, minmax(0, 1fr)); /*aqui esta el error de grid*/
    } 
    .gap-44 {
        gap: 0 !important; /*aqui esta el error de grid*/
    }   
    .grid1 {
        display: grid !important; /*aqui esta el error de grid*/
    }    

    .mr-l {
        margin-left: -20% !important;
        margin-right: 0px !important;
        font-size: 1rem !important;
        line-height: 2.5rem !important;
        font-weight: 900;
    }     
    /* BOTON MARCACION RAPIDA */    
    /* .-btnmr{
        width: 200%;
        margin-left: 5%;
        margin-top: -5%;
        cursor: pointer;
        padding: 10% 1% 10% 1% !important;
    } */

    .-mlfa {
        font-size: 0.8rem !important;
        line-height: 1.75rem !important;
    }
    .-mrtop {
        margin-left: -10% !important;
    }
    .-mrbtmtitle {
        margin-bottom: -2%;
        margin-left: 2%;
        margin-top: -5%;
    }    
    .-mlmr {
        margin-left: -12%;
        font-size: 10px !important;
    }    
    .mrmr {
        margin-right: 50%;
        font-size: 14px !important;
    }
}

@media only screen and (max-width: 768px) {
    .-mobil-mr{
        margin-top: -5%;
        margin-left: -30%;
        width: 200%;
    }
    .-fmob{
        font-size: 14px !important;
    }
    .grid-cols-33 {
        grid-template-columns: repeat(2, minmax(0, 1fr)); /*aqui esta el error de grid*/
    } 
    .gap-44 {
        gap: 0 !important; /*aqui esta el error de grid*/
    }   
    .grid1 {
        display: grid !important; /*aqui esta el error de grid*/
    }    

    .mr-l {
        margin-left: -20% !important;
        margin-right: 0px !important;
        font-size: 1.5rem !important;
        line-height: 2.5rem !important;
        font-weight: 900;
    }         
    .-btnmr{
        width: 200%;
        margin-left: 5%;
        margin-top: -5%;
        cursor: pointer;
    }

    .-mlfa {
        font-size: 0.8rem !important;
        line-height: 1.75rem !important;
    }
    .-mrtop {
        margin-left: -10% !important;
    }
    .-mrbtmtitle {
        margin-bottom: -2%;
        margin-left: 2%;
        margin-top: -5%;
    }    
    .-mlmr {
        margin-left: -12%;
        font-size: 10px !important;
    }    
}


/* */

.lds-dual-ring {
  display: inline-block;
  width: 30px;
  height: 30px;
}
.lds-dual-ring:after {
  content: " ";
  display: block;
  width: 20px;
  height: 20px;
  margin: 5px;
  border-radius: 50%;
  border: 3px solid #fff;
  border-color: #fff transparent #fff transparent;
  animation: lds-dual-ring 1.2s linear infinite;
  margin-left: -10px;
}
@keyframes lds-dual-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-dual-ring.loaderCursos {
  display: inline-block;
  width: 50px;
  height: 50px;
}
.lds-dual-ring.loaderCursos-purple:after {
  content: " ";
  display: block;
  width: 40px;
  height: 40px;
  margin: 5px;
  border-radius: 50%;
  border: 3px solid #7c3aed;
  border-color: #7c3aed transparent #7c3aed transparent;
  animation: lds-dual-ring 1.2s linear infinite;
  margin-left: -10px;
}
.lds-dual-ring.loaderCursos-red:after {
  content: " ";
  display: block;
  width: 40px;
  height: 40px;
  margin: 5px;
  border-radius: 50%;
  border: 3px solid #C92033;
  border-color: #C92033 transparent #C92033 transparent;
  animation: lds-dual-ring 1.2s linear infinite;
  margin-left: -10px;
}
@keyframes lds-dual-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* */

</style>