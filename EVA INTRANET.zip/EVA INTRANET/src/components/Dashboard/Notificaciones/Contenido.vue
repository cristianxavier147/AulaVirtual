<template>
  <div class="md:mx-5 lg:mx-5 my-0">
    <MarcaRapida />
    <div class="relative flex widthmobile">
      <input type="text" id="Search" name="" v-on:keyup="myFunction()" class="w-full bg-white  font-bold p-5 md:mx-0 lg:mx-0 mx-5 -searchkeyworkd" placeholder="Buscar palabra clave" />
      <img :src="require('@/assets/global/search-'+classGeneral+'.svg')" alt="accesso"   class="absolute right-0 md:mr-2 lg:mr-5 mr-7 top-3 -w-mobil -fcmobile" />
    </div>
    <Item />
  </div>
</template>

<script>
import Item from "@/components/Dashboard/Notificaciones/Item";
import MarcaRapida from "@/components/Dashboard/MarcacionRapida/MarcaRapida";
export default {
  components: {
    Item,
    MarcaRapida
  },
  methods:{
    myFunction() {
      var input = document.getElementById("Search");
      var filter = input.value.toLowerCase();
      var nodes = document.getElementsByClassName('target');
      var i = 0;
      for (i = 0; i < nodes.length; i++) {
        if (nodes[i].innerText.toLowerCase().includes(filter)) {
          nodes[i].style.display = "block";
        } else {
          nodes[i].style.display = "none";
        }
      }
    }
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>
<style>
.-searchkeyworkd {
    margin-left: 0.50rem !important;
    margin-right: 0.50rem !important;
}
</style>