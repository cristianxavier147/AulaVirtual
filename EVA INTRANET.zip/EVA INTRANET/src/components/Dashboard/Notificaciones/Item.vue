<template>
  <div class="md:my-5 lg:my-5 my-0 -mbmp">
<!--- PLANTILLA PUBLICACIONES FIJADAS --->    

    <div class="w-full p-5 my-5 bg-white rounded shadow-md widthmobile" v-for="(item, index) in Fijado" :key="index">
      <div class="-mnbta">
      <span class="font-bold size-text-11 Fijada size-text-res-10 py-3 text-left d-desktop-f -ilb" :class="'text-' + classGeneral + '-600'">Publicación fijada <img :src="require('@/assets/global/pin-' + classGeneral + '.svg')" alt="pin" class="ml-2 d-desktop-f -ilb" /></span>
      
      </div>
      <div class="flex py-3">
        <img src="@/assets/avatar/avatar.png" alt="accesso" class="mr-2 -img-fotoperfil" />
        <div class="text-left width-d">
          
          <div class="flex mobile-datos">
            <span class="mr-2 font-bold size-text-11 ">{{item.NombreUsuarioPublicador}}</span>
            <span class="font-bold size-text-11 Fijada size-text-res-10 d-mobile-f" :class="'text-' + classGeneral + '-600'">Publicación fijada </span><img :src="require('@/assets/global/pin-' + classGeneral + '.svg')" alt="pin" class="ml-2 d-mobile-f -ilb" />
          </div>
          <div class="font-bold text-gray-400 size-text-11 size-text-res-10"> 
            {{item.AreaPublicadora}} - <time-ago :datetime="item.FechaInicial"
            locale="es" 
            refresh 
            tooltip="tooltip"
            long
            class="timeago"
            />
        </div> 
        </div>
        <div class="text-right">
          <div class="flex">



            <span class="font-bold size-text-11 size-text-res-10 one-line underline Personalizado" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB004'"><a :href="item.RutaArchivo" target="_blank">{{item.DescPublicacion}}</a></span>
            <span v-else>
                  <span class="font-bold size-text-11 size-text-res-10 underline Info one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB003' && item.CorreoInfoTipoPublicacion != ''"><a :href="item.CorreoInfoTipoPublicacion" target="_blank">Quiero más información</a></span>
                  <span v-else>
                    <span class="font-bold size-text-11 size-text-res-10 underline one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB003' && item.LinkTextoTipoPublicacion != ''"><a :href="item.LinkTextoTipoPublicacion" target="_blank">Quiero más información</a></span>
                    <span v-else>
                      <span class="font-bold size-text-11 size-text-res-10 Postula underline one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB002' && item.LinkTextoTipoPublicacion != ''"><a :href="item.LinkTextoTipoPublicacion" target="_blank">Postular</a></span>
                      <span v-else>
                        <span class="font-bold size-text-11 size-text-res-10 underline Inscribirme one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB001' && item.LinkTextoTipoPublicacion != ''"><a v-bind:href="item.LinkTextoTipoPublicacion" target="_blank">Inscribirme</a></span>
                        <span v-else></span>
                      </span> 
                    </span> 
                  </span>                  
                </span> 




          </div>
        </div>
      </div>
      <div class="mt-3 mb-5 text-left size-text-16 size-text-res-12">
        {{item.Texto}}
        
      </div>
      <span v-if="item.RutaImagen != ''"><img :src="item.RutaImagen" class="img-width" /></span>
      <span v-else></span>      


      <!---  Conteo reacciones ---->
      
      <div class="reaccionessvg font-bold" :class="'text-' + classGeneral + '-600'" @click.prevent="show(item.IdPublicacion); ConteoReaccion(item.IdPublicacion, item.ConteoReacciones,item.MeEmociona, item.MeEnorgullece, item.MeInteresa); seen = !seen" ><span class="nrolikes">{{item.ConteoReacciones}}</span></div>

        <div :ref="item.IdPublicacion" v-if="seen" id="hide" class="fixed z-10 inset-0" aria-labelledby="dialog-1-title" role="dialog" aria-modal="true">
          <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">

            <div class="fixed inset-0 bg-opacity-75 transition-opacity blr" aria-hidden="true"></div>


            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
            
            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full mrgntop">
              
              <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 static">
                <div class="sm:flex sm:items-start">
                  <div class="mt-3 text-center wd sm:mt-0 sm:ml-4 sm:text-left mglobal">
                    
                      <h3 class="text-lg leading-6 font-bold" id="dialog-1-title">
                        Interacciones
                      </h3>

                    <div class="mt-2">
                      <ul >
                      <li class="py-2 cursor-pointer mb border-b-4 size-text-15 font-bold tm" :class="'border-'+classGeneral+'-600 text-' + classGeneral + '-600'" >
                        {{ConteoR}} en Totales
                        </li> 
                      <li><span class="linea cerebro">
                        <span class="mls fontstyle text-gray-400	">{{ConteoMeInteresa}}</span>
                      </span></li>
                      <li><span class="foco linea">
                        <span class="fontstyle text-gray-400	">{{ConteoMeEmociona}}</span>
                      </span></li>
                      <li><span class="estrella linea">
                        <span class="fontstyle text-gray-400	">{{ConteoMeEnorgullece}}</span>
                      </span></li>
                      </ul>
                    </div>
                    

                    <div class="mt-8 scrolleable">

                      <div>


                        <div class="divTable">
                          <div class="divTableBody">
                            <div class="divTableRow" v-for="(r,index) in ReaccionGet" :key="index">
                              <div class="divTableCell fotodiv"><img :src="r.UrlImagen + r.ActorImagen" class="img-widht" /></div>
                              
                              <div class="divTableCell nombret text-left">{{ r.NombreUsuario | capitalize }}</div>
                              <div class="divTableCell">
                                <span  v-if="r.IdReaccion === 28823">
                                  <img :src="require('@/assets/global/enorgulleseImg.svg')" class="reaccionClass" />
                                </span>
                                <span  v-if="r.IdReaccion === 28824">
                                  <img :src="require('@/assets/global/focoImg.svg')" class="reaccionClass" />
                                </span>      
                                <span  v-if="r.IdReaccion === 28825">
                                  <img :src="require('@/assets/global/estrellaImg.svg')" class="reaccionClass" />
                                </span>                                                                
                                <span v-else>
                                  
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>



                      </div>

                    </div>



                  </div>
                </div>
              </div>

            </div>
         <span class="inline-block align-bottom rounded-lg text-left overflow-hidden transform transition-all sm:my-8 sm:align-top cerrar px-4 pt-5 pb-4 sm:p-6 sm:pb-4" @click="seen = !seen"></span>   
          </div>
        </div>

      <!---  Conteo reacciones ---->

      <div class="border-t border-gray-300">
        <div class="grid grid-cols-3">
          <div class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaFinal || active_el == item.FechaCreacion }"  v-if="item.UsuarioReaccion == 28823" v-on:click="reaccion(item.IdPublicacion, '28823'); ActivarEmociona(); activate(item.FechaInicial);" >
            <div class="flex">
              <img 
                :src='require("@/assets/global/meInteresaActive.svg")'
                alt="accesso"
                contain         
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-1" />        
              <span class="size-text-14 size-text-res-10">Me interesa</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" v-on:click="reaccion(item.IdPublicacion, '28823'); activate(item.FechaInicial);"  :class="{ actived : active_el == item.FechaInicial}" >
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meInteresa.svg")'
                alt="accesso"
                contain         
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-1" />
              <span class="size-text-14 size-text-res-10">Me interesa</span>
            </div>
          </div>
          <div class="col-span-1 md:px-3 cursor lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaInicial || active_el == item.FechaCreacion }" v-if="item.UsuarioReaccion == 28824" v-on:click="reaccion(item.IdPublicacion, '28824'); ActivarEmociona(); activate(item.FechaFinal);">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEmocionaActive.svg")'
                alt="accesso"
                contain        
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-2" />
              <span class="size-text-14 size-text-res-10">Me emociona</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" @click="reaccion(item.IdPublicacion, '28824'); ActivarEmociona(); activate(item.FechaFinal);" :class="{ actived : active_el == item.FechaFinal }">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEmociona.svg")'
                alt="accesso" 
                contain     
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-2" />
              <span class="size-text-14 size-text-res-10">Me emociona</span>
            </div>
          </div>          
          <div class="col-span-1 md:px-3 cursor lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaInicial || active_el == item.FechaFinal }" v-if="item.UsuarioReaccion == 28825" @click="reaccion(item.IdPublicacion, '28825'); ActivarEnorgullese(); activate(item.FechaCreacion);">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEnorgulleseActive.svg")'
                alt="accesso" 
                contain         
                aspect-ratio="1"     
                class="mr-2 tm-icon-3" />                 
              <span class="size-text-14 size-text-res-10">Me enorgullece</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" @click="reaccion(item.IdPublicacion, '28825'); ActivarEnorgullese(); activate(item.FechaCreacion);" :class="{ actived : active_el == item.FechaCreacion }">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEnorgullese.svg")'
                alt="accesso"
                contain      
                aspect-ratio="1"     
                class="mr-2 tm-icon-3" />
              <span class="size-text-14 size-text-res-10">Me enorgullece</span>
            </div>
          </div>             
        </div>

      </div>
    </div>
 
<!--- PLANTILLA PUBLICACIONES FIJADAS --->

<!--- PLANTILLA PUBLICACIONES SIN FIJAR --->
    <div class="w-full p-5 my-5 bg-white rounded shadow-md widthmobile" v-for="(item, index) in SinFijar" :key="index">
      
      <div class="flex py-3" :ref="item.IdPublicacion">
        <img src="@/assets/avatar/avatar.png" alt="accesso" class="mr-2 -img-fotoperfil" />
        <div class="text-left width-d">
          <div class="flex">
            <span class="mr-2 font-bold size-text-11">{{item.NombreUsuarioPublicador}}</span>
          </div>
          <div class="font-bold text-gray-400 size-text-11 size-text-res-10"> 
            {{item.AreaPublicadora}} - <time-ago :datetime="item.FechaInicial"
            locale="es" 
            refresh 
            tooltip="tooltip"
            long
            class="timeago"
            />
        </div> 
        </div>
        <div class="text-right">
          <div class="flex">


            <span class="font-bold size-text-11 size-text-res-10 one-line underline Personalizado" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB004'"><a :href="item.RutaArchivo" target="_blank">{{item.DescPublicacion}}</a></span>
            <span v-else>
                  <span class="font-bold size-text-11 size-text-res-10 underline Info one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB003' && item.CorreoInfoTipoPublicacion != ''"><a :href="item.CorreoInfoTipoPublicacion" target="_blank">Quiero más información</a></span>
                  <span v-else>
                    <span class="font-bold size-text-11 size-text-res-10 underline one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB003' && item.LinkTextoTipoPublicacion != ''"><a :href="item.LinkTextoTipoPublicacion" target="_blank">Quiero más información</a></span>
                    <span v-else>
                      <span class="font-bold size-text-11 size-text-res-10 Postula underline one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB002' && item.LinkTextoTipoPublicacion != ''"><a :href="item.LinkTextoTipoPublicacion" target="_blank">Postular</a></span>
                      <span v-else>
                        <span class="font-bold size-text-11 size-text-res-10 underline Inscribirme one-line" :class="'text-' + classGeneral + '-600'" v-if="item.CodTipoPublicacion == 'EVAPUB001' && item.LinkTextoTipoPublicacion != ''"><a v-bind:href="item.LinkTextoTipoPublicacion" target="_blank">Inscribirme</a></span>
                        <span v-else></span>
                      </span> 
                    </span> 
                  </span>                  
                </span> 

                

          </div>
        </div>
      </div>
      <div class="mt-3 mb-5 text-left size-text-16 size-text-res-12">
        {{item.Texto}}
      </div>
      <span v-if="item.RutaImagen != ''"><img :src="item.RutaImagen" class="img-width" /></span>
      <span v-else></span> 


      <!---  Conteo reacciones ---->
      
      <div class="reaccionessvg font-bold" :class="'text-' + classGeneral + '-600'" @click.prevent="show(item.IdPublicacion); ConteoReaccion(item.IdPublicacion, item.ConteoReacciones,item.MeEmociona, item.MeEnorgullece, item.MeInteresa); seen = !seen" ><span class="nrolikes">{{item.ConteoReacciones}}</span></div>

        <div :ref="item.IdPublicacion" v-if="seen" id="hide" class="fixed z-10 inset-0" aria-labelledby="dialog-1-title" >
          <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">

            <div class="fixed inset-0 bg-opacity-75 transition-opacity blr" aria-hidden="true"></div>


            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
            
            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full mrgntop">
              
              <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 static">
                <div class="sm:flex sm:items-start">
                  <div class="mt-3 text-center wd sm:mt-0 sm:ml-4 sm:text-left mglobal">
                    
                      <h3 class="text-lg leading-6 font-bold" id="dialog-1-title">
                        Interacciones
                      </h3>

                    <div class="mt-2">
                      <ul >
                      <li class="py-2 cursor-pointer mb border-b-4 size-text-15 font-bold tm" :class="'border-'+classGeneral+'-600 text-' + classGeneral + '-600'" >
                        {{ConteoR}} en Totales
                        </li> 
                      <li><span class="linea cerebro">
                        <span class="mls fontstyle text-gray-400	">{{ConteoMeInteresa}}</span>
                      </span></li>
                      <li><span class="foco linea">
                        <span class="fontstyle text-gray-400	">{{ConteoMeEmociona}}</span>
                      </span></li>
                      <li><span class="estrella linea">
                        <span class="fontstyle text-gray-400	">{{ConteoMeEnorgullece}}</span>
                      </span></li>
                      </ul>
                    </div>
                    

                    <div class="mt-8">

                      <div>


                        <div class="divTable">
                          <div class="divTableBody">
                            <div class="divTableRow" v-for="(r,index) in ReaccionGet" :key="index">
                              <div class="divTableCell fotodiv"><img :src="r.UrlImagen + r.ActorImagen" class="img-widht" /></div>
                              
                              <div class="divTableCell nombret text-left" v-uppercase>{{ r.NombreUsuario | capitalize }}</div>
                              <div class="divTableCell">
                                <span  v-if="r.IdReaccion === 28823">
                                  <img :src="require('@/assets/global/enorgulleseImg.svg')" class="reaccionClass" />
                                </span>
                                <span  v-if="r.IdReaccion === 28824">
                                  <img :src="require('@/assets/global/focoImg.svg')" class="reaccionClass" />
                                </span>      
                                <span  v-if="r.IdReaccion === 28825">
                                  <img :src="require('@/assets/global/estrellaImg.svg')" class="reaccionClass" />
                                </span>                                                                
                                <span v-else>
                                  
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>



                      </div>

                    </div>



                  </div>
                </div>
              </div>

            </div>
         <span class="inline-block align-bottom rounded-lg text-left overflow-hidden transform transition-all sm:my-8 sm:align-top cerrar px-4 pt-5 pb-4 sm:p-6 sm:pb-4" @click="seen = !seen"></span>   
          </div>
        </div>

      

        

      

      <!---  Conteo reacciones ---->


      <div class="border-t border-gray-300">
        <div class="grid grid-cols-3">
          <div class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaFinal || active_el == item.FechaCreacion }"  v-if="item.UsuarioReaccion == 28823" @click="reaccion(item.IdPublicacion, '28823'); ActivarEmociona(); activate(item.FechaInicial);" >
            <div class="flex">
              <img 
                :src='require("@/assets/global/meInteresaActive.svg")'
                alt="accesso"
                contain         
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-1" />        
              <span class="size-text-14 size-text-res-10">Me interesa</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" @click="reaccion(item.IdPublicacion, '28823'); activate(item.FechaInicial);"  :class="{ actived : active_el == item.FechaInicial}" >
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meInteresa.svg")'
                alt="accesso"
                contain         
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-1" />
              <span class="size-text-14 size-text-res-10">Me interesa</span>
            </div>
          </div>
          <div class="col-span-1 md:px-3 cursor lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaInicial || active_el == item.FechaCreacion }" v-if="item.UsuarioReaccion == 28824" @click="reaccion(item.IdPublicacion, '28824'); ActivarEmociona(); activate(item.FechaFinal);">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEmocionaActive.svg")'
                alt="accesso"
                contain        
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-2" />
              <span class="size-text-14 size-text-res-10">Me emociona</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" @click="reaccion(item.IdPublicacion, '28824'); ActivarEmociona(); activate(item.FechaFinal);" :class="{ actived : active_el == item.FechaFinal }">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEmociona.svg")'
                alt="accesso" 
                contain     
                aspect-ratio="1"     
                class="mr-2 fill-current tm-icon-2" />
              <span class="size-text-14 size-text-res-10">Me emociona</span>
            </div>
          </div>          
          <div class="col-span-1 md:px-3 cursor lg:px-3 md:pt-3 activo lg:pt-3 pt-2 place-self-center" :class="{ actives : active_el == item.FechaInicial || active_el == item.FechaFinal }" v-if="item.UsuarioReaccion == 28825" @click="reaccion(item.IdPublicacion, '28825'); ActivarEnorgullese(); activate(item.FechaCreacion);">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEnorgulleseActive.svg")'
                alt="accesso" 
                contain         
                aspect-ratio="1"     
                class="mr-2 tm-icon-3" />                 
              <span class="size-text-14 size-text-res-10">Me enorgullece</span>
            </div>
          </div>
          <div v-else class="col-span-1 cursor md:px-3 lg:px-3 md:pt-3 lg:pt-3 pt-2 place-self-center" @click="reaccion(item.IdPublicacion, '28825'); ActivarEnorgullese(); activate(item.FechaCreacion);" :class="{ actived : active_el == item.FechaCreacion }">
            <div class="flex wkb">
              <img 
                :src='require("@/assets/global/meEnorgullese.svg")'
                alt="accesso"
                contain      
                aspect-ratio="1"     
                class="mr-2 tm-icon-3" />
              <span class="size-text-14 size-text-res-10">Me enorgullece</span>
            </div>
          </div>             
        </div>

      </div>


    </div>
<!--- PLANTILLA PUBLICACIONES SIN FIJAR --->

  </div>
</template>
<script>

  import Vue from 'vue';
  import TimeAgo from 'vue2-timeago'; //nuevo
  import Vuetify from 'vuetify';
  import { nameCursoService } from "@/mixins/nameCurso";
  import { json } from 'body-parser';
  import { responseService } from "@/mixins/response";
  import { BootstrapVue } from 'bootstrap-vue'
  Vue.use(BootstrapVue)
  Vue.use(Vuetify);

Vue.directive("uppercase", {
    update: function (el) {
        el.value = el.value.toLowerCase()
    }
})

export default {
  name: "Item",
  components: {
    TimeAgo
  },  

  data() {
    return {
      locale:"es_ES",
      Fijado: [],
      showModal:false,
      preloader: false,
      SinFijar: [],
      seen: false,
      ActivoMeInteresa: 0,
      ActivoMeInteresa1: 1,
      ActivoMeEmociona: 0,
      ActivoMeEmociona1: 1,
      ActivoMeEnorgullese: 0,
      ActivoMeEnorgullese1: 1,
      Totalreacciones: '',
      ConteoR: '',
      active_el:0,
      Reacciones:[],
      ReaccionGet: [],
      ConteoMeInteresa: '0',
      ConteoMeEmociona: '0',
      ConteoMeEnorgullece: '0',
      Emociona: '',
      Enorgullece: '',
      Interesa: '',
      ConteoTotalRe: '',
      form: {
        IdPub: "",
        IdUsu: "",
        IdRea: ""
      },      
      MeInteresa: [
        {
          name: "meInteresa",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meInteresa.svg")
        },
        {
          name: "meInteresaActive",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meInteresaActive.svg")
        }
      ],
      MeEmociona: [
        {
          name: "MeEmociona",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meEmociona.svg")
        },
        {
          name: "MeEmocionaActive",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meEmocionaActive.svg")
        }
      ],
      MeEnorgullese: [
        {
          name: "MeEnorgullese",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meEnorgullese.svg")
        },
        {
          name: "MeEnorgulleseActive",
          //url: "@/assets/global/meInteresaActive.svg"
          url: require("@/assets/global/meEnorgulleseActive.svg")
        }
      ]           
    }
  }, 
  computed: {
      meInteresaURL: function() {
          return this.MeInteresa[this.ActivoMeInteresa].url
      },
      meInteresaURLActivo: function(){
          return this.MeInteresa[this.ActivoMeInteresa1].url
      },      
      meEmocionaURL: function() {
          return this.MeEmociona[this.ActivoMeEmociona].url
      },
      meEmocionaURLActivo: function(){
          return this.MeEmociona[this.ActivoMeEmociona1].url
      },        
      MeEnorgulleseURL: function() {
          return this.MeEnorgullese[this.ActivoMeEnorgullese].url
      },
      MeEnorgulleseURLActivo: function(){
          return this.MeEnorgullese[this.ActivoMeEnorgullese1].url
      },
      classGeneral(){
        return localStorage.getItem('classGeneral')
      }
  }, 
  filters: {
      capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
      },
  },  
  methods: {
      handleOpen() {
          this.$refs.myModal.scrollTop = this.$refs.myModal.scrollHeight
      },    
      show: function (I) {
        //this.$bvModal.msgBoxOk(I)
      },
    showModal(I) {
      var Id = I;
      let element = this.$refs.I.$el
      $(element).modal('show')
    },    
    activate:function(el){
        this.active_el = el;
    },
    goto(refName) {
    	var element = this.$refs[refName];
      console.log(element);
      var top = element.offsetTop;
      
      window.scrollTo(0, top);
    },    
    ActivarInteresa() {
        this.ActivoMeInteresa = 1
        this.ActivoMeInteresa1 = 1
        this.ActivoMeEmociona = 0
        this.ActivoMeEnorgullese = 0
        this.ActivoMeEmociona1 = 0
        this.ActivoMeEnorgullese1 = 0
    },    
    ActivarEmociona() {
        this.ActivoMeInteresa = 0
        this.ActivoMeInteresa1 = 0
        this.ActivoMeEmociona = 1
        this.ActivoMeEmociona1 = 1
        this.ActivoMeEnorgullese = 0
        this.ActivoMeEnorgullese1 = 0
    },  
    ActivarEnorgullese() {
        this.ActivoMeInteresa = 0
        this.ActivoMeInteresa1 = 0
        this.ActivoMeEmociona = 0
        this.ActivoMeEmociona1 = 0
        this.ActivoMeEnorgullese = 1
        this.ActivoMeEnorgullese1 = 1
    },        
    MostrarNotificacion() {
      //this.Fijado.length = 0;
      //this.SinFijar.length = 0;
      this.$store.dispatch("notificacionesStore/notificaciones").then((response) => {
        if (response.success) {
          var myObj = response;
          var Lista = myObj.results.lisQuery;
          this.Publicaciones = Lista;
          this.Publicaciones.forEach((value, index) => {

            if(value.EsFijada > 0){
              this.Fijado.push(value);
            }else{
              this.SinFijar.push(value);
            }
            
            
          });
          
        }
      }); 
      
    },
    reaccion(PublicacionID, CodigoReaccion) {
      let store = JSON.parse(localStorage.getItem('data'))
      this.ConteoReaccion(PublicacionID)
      var Reaccion = CodigoReaccion;
      var IdUsuario = store.user_id_usuario;
      var Estado = '1';
      this.$store.dispatch("reaccionStore/reaccion", {IdPub: PublicacionID, IdUsu: IdUsuario, IdRea: Reaccion, Estad: Estado}).then((response) => {
        if(response.success){
          //setTimeout(this.MostrarNotificacion(), 10000);
          //this.goto(PublicacionID)
          //this.goto("30")
        }
      })


    },
    ConteoReaccion(PublicacionID, ConteoR, Emo, Eno, Inte) {
      this.ReaccionGet.length = 0;
      var ids = PublicacionID;
      var Conteorea = ConteoR;
      this.ConteoR = Conteorea;
      this.Enorgullece = Eno;
      this.Interesa = Inte;
      this.Emociona = Emo;
      this.$store.dispatch("conteoreaccionStore/conteoreaccion", {IdPublicacions: PublicacionID}).then((response) => {
        if(response.success){
         this.ReaccionGet = response.results.lisQuery;
         this.ConteoMeInteresa = response.results.lisQuery[0].MeInteresa;
         this.ConteoMeEmociona = response.results.lisQuery[0].MeEmociona;
         this.ConteoMeEnorgullece = response.results.lisQuery[0].MeEnorgullece;
        }
      })

    },    
    
  },  
  created() {
      this.MostrarNotificacion();
      console.log(localStorage.getItem('classGeneral'))

  },
};
</script>
<style>
.text-red-600 {
    --tw-text-opacity: 1;
    color: rgba(220, 38, 38, var(--tw-text-opacity));
}

.-img-fotoperfil{
  width: 6% !important;
}
.activo {
  color:red;
  filter: invert(39%) sepia(92%) saturate(7499%) hue-rotate(260deg) brightness(91%) contrast(101%);
}
  .cursor {
    cursor: pointer;
  }
  .size-text-11{
    font-size: 11px;
    line-height: 1rem;
  }
  .width-d{
    width: 75%;
  }
  .one-line{
    white-space: nowrap;
  }
  .width-l{
    width: 25%;
    margin-left: -10%;
  }
  .img-width{
    margin-left: -3%;
    margin-right: 0;
    max-width: 107.3%!important;
    margin-bottom: 5%;
    width: 106%;
  }

.actives {
  color:red;
  filter: invert(53%) sepia(64%) saturate(75%) hue-rotate(178deg) brightness(88%) contrast(86%) !important;
}

.actived {
  color:red;
  filter: invert(39%) sepia(92%) saturate(7499%) hue-rotate(260deg) brightness(91%) contrast(101%);
}


.timeago span {
  font-size: 11px !important;
  --tw-text-opacity: 1;
  color: rgba(156, 163, 175, var(--tw-text-opacity));
  font-family: "Montserrat";  
}

.reaccionessvg{
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5OCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDk4IDI0Ij4NCiAgPGcgaWQ9IkdydXBvXzIxNjc3IiBkYXRhLW5hbWU9IkdydXBvIDIxNjc3IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjQwIC0zMTMpIj4NCiAgICA8ZyBpZD0iR3J1cG9fMjE2NzIiIGRhdGEtbmFtZT0iR3J1cG8gMjE2NzIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC00MCAtNTM3KSI+DQogICAgICA8Y2lyY2xlIGlkPSJFbGlwc2VfNDE2IiBkYXRhLW5hbWU9IkVsaXBzZSA0MTYiIGN4PSIxMiIgY3k9IjEyIiByPSIxMiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjgwIDg1MCkiIGZpbGw9IiNlYWVhZWEiLz4NCiAgICAgIDxwYXRoIGlkPSJJY29uX2F3ZXNvbWUtYnJhaW4iIGRhdGEtbmFtZT0iSWNvbiBhd2Vzb21lLWJyYWluIiBkPSJNNS43NzgsMEExLjc2NywxLjc2NywwLDAsMCw0LjA2MSwxLjMxOGMtLjAyMiwwLS4wMzktLjAwNS0uMDYxLS4wMDVhMS43NjYsMS43NjYsMCwwLDAtMS43NzgsMS43NSwxLjU4OSwxLjU4OSwwLDAsMCwuMDQ3LjM4M0EyLjE4OCwyLjE4OCwwLDAsMCwuODg5LDUuNDY5YTIuMTYyLDIuMTYyLDAsMCwwLC4yMzEuOTU0LDIuMTY1LDIuMTY1LDAsMCwwLC4yNTMsMy45MSwxLjk2NiwxLjk2NiwwLDAsMCwxLjk2MSwyLjM1NCwxLjkxMiwxLjkxMiwwLDAsMCwuMzMzLS4wMzMsMiwyLDAsMCwwLDMuODg5LS42MjNWMS43NUExLjc2NiwxLjc2NiwwLDAsMCw1Ljc3OCwwWk0xNiw4LjMxM2EyLjE3MSwyLjE3MSwwLDAsMC0xLjExOS0xLjg4OSwyLjEyNSwyLjEyNSwwLDAsMCwuMjMxLS45NTQsMi4xODgsMi4xODgsMCwwLDAtMS4zODEtMi4wMjMsMS43NDEsMS43NDEsMCwwLDAsLjA0Ny0uMzgzQTEuNzY2LDEuNzY2LDAsMCwwLDEyLDEuMzEzYy0uMDIyLDAtLjA0Mi4wMDUtLjA2MS4wMDVhMS43NzgsMS43NzgsMCwwLDAtMy40OTQuNDMyVjEyLjAzMWEyLDIsMCwwLDAsMy44ODkuNjIzLDEuOTEyLDEuOTEyLDAsMCwwLC4zMzMuMDMzLDEuOTY2LDEuOTY2LDAsMCwwLDEuOTYxLTIuMzU0QTIuMTg4LDIuMTg4LDAsMCwwLDE2LDguMzEzWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjg0IDg1NSkiIGZpbGw9IiM3Zjg3OTQiLz4NCiAgICA8L2c+DQogICAgPGcgaWQ9IkdydXBvXzIxNjczIiBkYXRhLW5hbWU9IkdydXBvIDIxNjczIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNDQgLTUzNykiPg0KICAgICAgPGNpcmNsZSBpZD0iRWxpcHNlXzQxNyIgZGF0YS1uYW1lPSJFbGlwc2UgNDE3IiBjeD0iMTIiIGN5PSIxMiIgcj0iMTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMxMiA4NTApIiBmaWxsPSIjZWFlYWVhIi8+DQogICAgICA8cGF0aCBpZD0iSWNvbl9pb25pYy1tZC1idWxiIiBkYXRhLW5hbWU9Ikljb24gaW9uaWMtbWQtYnVsYiIgZD0iTTEwLjY1MywxNy43NzFhLjcxNS43MTUsMCwwLDAsLjY5NC43MjlIMTQuNGEuNzE1LjcxNSwwLDAsMCwuNjk0LS43Mjl2LS42NTZIMTAuNjUzWk0xMi44NzUsNC41YTQuOTM4LDQuOTM4LDAsMCwwLTUsNC44ODUsNC44ODEsNC44ODEsMCwwLDAsMi4xMzIsNC4wMzJWMTVhLjcxLjcxLDAsMCwwLC43MTUuN2g0LjNhLjcwNy43MDcsMCwwLDAsLjcxNS0uN1YxMy40MThhNC44NzUsNC44NzUsMCwwLDAsMi4xMzUtNC4wMzJBNC45MzgsNC45MzgsMCwwLDAsMTIuODc1LDQuNVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMxMS4xMjUgODUwLjUpIiBmaWxsPSIjN2Y4Nzk0Ii8+DQogICAgPC9nPg0KICAgIDxnIGlkPSJHcnVwb18yMTY3NCIgZGF0YS1uYW1lPSJHcnVwbyAyMTY3NCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQ4IC01MzcpIj4NCiAgICAgIDxjaXJjbGUgaWQ9IkVsaXBzZV80MTgiIGRhdGEtbmFtZT0iRWxpcHNlIDQxOCIgY3g9IjEyIiBjeT0iMTIiIHI9IjEyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzNDQgODUwKSIgZmlsbD0iI2VhZWFlYSIvPg0KICAgICAgPHBhdGggaWQ9Ikljb25fYXdlc29tZS1zdGFyIiBkYXRhLW5hbWU9Ikljb24gYXdlc29tZS1zdGFyIiBkPSJNNy42OS40ODYsNS45ODIsNC4xMDZsLTMuODIzLjU4MkEuODg2Ljg4NiwwLDAsMCwxLjcsNi4xODFMNC40NjEsOWwtLjY1NCwzLjk3OGEuODQ1Ljg0NSwwLDAsMCwxLjIxNC45MjFsMy40Mi0xLjg3OCwzLjQyLDEuODc4YS44NDYuODQ2LDAsMCwwLDEuMjE0LS45MjFMMTIuNDIyLDlsMi43NjYtMi44MTZhLjg4Ni44ODYsMCwwLDAtLjQ2My0xLjQ5M0wxMC45LDQuMTA2LDkuMTkyLjQ4NmEuODIzLjgyMywwLDAsMC0xLjUsMFoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDM0Ny41NTkgODU1LjAwMSkiIGZpbGw9IiM3Zjg3OTQiLz4NCiAgICA8L2c+DQogIDwvZz4NCjwvc3ZnPg0KDQo=');
    background-repeat: no-repeat, repeat;
    /*background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;*/
    margin-top: -2%;
    margin-bottom: 2%;    
}
.nrolikes{
  margin-right: 69%;
  color: #7f8794 !important;
}



.mt-2 p {
  display: inline-block;
}

.-ilb{
  display: inline-block;
}

.cerebro{
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MyIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDUzIDI0Ij4NCiAgPGcgaWQ9IkdydXBvXzIxODYxIiBkYXRhLW5hbWU9IkdydXBvIDIxODYxIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtODM2IC0yODYpIj4NCiAgICA8ZyBpZD0iR3J1cG9fMjE4NTYiIGRhdGEtbmFtZT0iR3J1cG8gMjE4NTYiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE1KSI+DQogICAgICAgIDxnIGlkPSJHcnVwb18yMTY4MiIgZGF0YS1uYW1lPSJHcnVwbyAyMTY4MiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNTQxIC01NjQpIj4NCiAgICAgICAgPGNpcmNsZSBpZD0iRWxpcHNlXzQxNiIgZGF0YS1uYW1lPSJFbGlwc2UgNDE2IiBjeD0iMTIiIGN5PSIxMiIgcj0iMTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDI4MCA4NTApIiBmaWxsPSIjN2Y4Nzk0IiBvcGFjaXR5PSIwLjEiLz4NCiAgICAgICAgPHBhdGggaWQ9Ikljb25fYXdlc29tZS1icmFpbiIgZGF0YS1uYW1lPSJJY29uIGF3ZXNvbWUtYnJhaW4iIGQ9Ik01Ljc3OCwwQTEuNzY3LDEuNzY3LDAsMCwwLDQuMDYxLDEuMzE4Yy0uMDIyLDAtLjAzOS0uMDA1LS4wNjEtLjAwNWExLjc2NiwxLjc2NiwwLDAsMC0xLjc3OCwxLjc1LDEuNTg5LDEuNTg5LDAsMCwwLC4wNDcuMzgzQTIuMTg4LDIuMTg4LDAsMCwwLC44ODksNS40NjlhMi4xNjIsMi4xNjIsMCwwLDAsLjIzMS45NTQsMi4xNjUsMi4xNjUsMCwwLDAsLjI1MywzLjkxLDEuOTY2LDEuOTY2LDAsMCwwLDEuOTYxLDIuMzU0LDEuOTEyLDEuOTEyLDAsMCwwLC4zMzMtLjAzMywyLDIsMCwwLDAsMy44ODktLjYyM1YxLjc1QTEuNzY2LDEuNzY2LDAsMCwwLDUuNzc4LDBaTTE2LDguMzEzYTIuMTcxLDIuMTcxLDAsMCwwLTEuMTE5LTEuODg5LDIuMTI1LDIuMTI1LDAsMCwwLC4yMzEtLjk1NCwyLjE4OCwyLjE4OCwwLDAsMC0xLjM4MS0yLjAyMywxLjc0MSwxLjc0MSwwLDAsMCwuMDQ3LS4zODNBMS43NjYsMS43NjYsMCwwLDAsMTIsMS4zMTNjLS4wMjIsMC0uMDQyLjAwNS0uMDYxLjAwNWExLjc3OCwxLjc3OCwwLDAsMC0zLjQ5NC40MzJWMTIuMDMxYTIsMiwwLDAsMCwzLjg4OS42MjMsMS45MTIsMS45MTIsMCwwLDAsLjMzMy4wMzMsMS45NjYsMS45NjYsMCwwLDAsMS45NjEtMi4zNTRBMi4xODgsMi4xODgsMCwwLDAsMTYsOC4zMTNaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyODQgODU1KSIgZmlsbD0iIzdmODc5NCIvPg0KICAgICAgPC9nPg0KICAgIDwvZz4NCiAgPC9nPg0KPC9zdmc+DQo=');
    background-repeat: no-repeat, repeat;
    padding-left: 10%;
}


.foco {
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1NCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDU0IDI0Ij4NCiAgPGcgaWQ9IkdydXBvXzIxODU5IiBkYXRhLW5hbWU9IkdydXBvIDIxODU5IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTk1IC0yODYpIj4NCiAgICA8ZyBpZD0iR3J1cG9fMjE4NTgiIGRhdGEtbmFtZT0iR3J1cG8gMjE4NTgiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zKSI+DQogICAgICA8ZyBpZD0iR3J1cG9fMjE2ODMiIGRhdGEtbmFtZT0iR3J1cG8gMjE2ODMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDI4NiAtNTY0KSI+DQogICAgICAgIDxjaXJjbGUgaWQ9IkVsaXBzZV80MTciIGRhdGEtbmFtZT0iRWxpcHNlIDQxNyIgY3g9IjEyIiBjeT0iMTIiIHI9IjEyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMTIgODUwKSIgZmlsbD0iIzdmODc5NCIgb3BhY2l0eT0iMC4xIi8+DQogICAgICAgIDxwYXRoIGlkPSJJY29uX2lvbmljLW1kLWJ1bGIiIGRhdGEtbmFtZT0iSWNvbiBpb25pYy1tZC1idWxiIiBkPSJNMTAuNjUzLDE3Ljc3MWEuNzE1LjcxNSwwLDAsMCwuNjk0LjcyOUgxNC40YS43MTUuNzE1LDAsMCwwLC42OTQtLjcyOXYtLjY1NkgxMC42NTNaTTEyLjg3NSw0LjVhNC45MzgsNC45MzgsMCwwLDAtNSw0Ljg4NSw0Ljg4MSw0Ljg4MSwwLDAsMCwyLjEzMiw0LjAzMlYxNWEuNzEuNzEsMCwwLDAsLjcxNS43aDQuM2EuNzA3LjcwNywwLDAsMCwuNzE1LS43VjEzLjQxOGE0Ljg3NSw0Ljg3NSwwLDAsMCwyLjEzNS00LjAzMkE0LjkzOCw0LjkzOCwwLDAsMCwxMi44NzUsNC41WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMzExLjEyNSA4NTAuNSkiIGZpbGw9IiM3Zjg3OTQiLz4NCiAgICAgIDwvZz4NCiAgICA8L2c+DQogIDwvZz4NCjwvc3ZnPg0K');
    background-repeat: no-repeat, repeat;
    padding-left: 10%;
}

.estrella {
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MyIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDUzIDI0Ij4NCiAgPGcgaWQ9IkdydXBvXzIxODYwIiBkYXRhLW5hbWU9IkdydXBvIDIxODYwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNzE2IC0yODYpIj4NCiAgICA8ZyBpZD0iR3J1cG9fMjE4NTciIGRhdGEtbmFtZT0iR3J1cG8gMjE4NTciIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE4KSI+DQogICAgICA8ZyBpZD0iR3J1cG9fMjE2ODQiIGRhdGEtbmFtZT0iR3J1cG8gMjE2ODQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDM1NCAtNTY0KSI+DQogICAgICAgIDxjaXJjbGUgaWQ9IkVsaXBzZV80MTgiIGRhdGEtbmFtZT0iRWxpcHNlIDQxOCIgY3g9IjEyIiBjeT0iMTIiIHI9IjEyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzNDQgODUwKSIgZmlsbD0iIzdmODc5NCIgb3BhY2l0eT0iMC4xIi8+DQogICAgICAgIDxwYXRoIGlkPSJJY29uX2F3ZXNvbWUtc3RhciIgZGF0YS1uYW1lPSJJY29uIGF3ZXNvbWUtc3RhciIgZD0iTTcuNjkuNDg2LDUuOTgyLDQuMTA2bC0zLjgyMy41ODJBLjg4Ni44ODYsMCwwLDAsMS43LDYuMTgxTDQuNDYxLDlsLS42NTQsMy45NzhhLjg0NS44NDUsMCwwLDAsMS4yMTQuOTIxbDMuNDItMS44NzgsMy40MiwxLjg3OGEuODQ2Ljg0NiwwLDAsMCwxLjIxNC0uOTIxTDEyLjQyMiw5bDIuNzY2LTIuODE2YS44ODYuODg2LDAsMCwwLS40NjMtMS40OTNMMTAuOSw0LjEwNiw5LjE5Mi40ODZhLjgyMy44MjMsMCwwLDAtMS41LDBaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzNDcuNTU5IDg1NS4wMDEpIiBmaWxsPSIjN2Y4Nzk0Ii8+DQogICAgICA8L2c+DQogICAgPC9nPg0KICA8L2c+DQo8L3N2Zz4NCg0K');
    background-repeat: no-repeat, repeat;
    padding-left: 10%;
}

.Personalizado{
  margin-right: 0%;
}
.Postula{
  margin-left: 130%;
}
.Inscribirme {
  margin-left: 70%;
}

.Fijada {
  font-size: 13px;
  margin-top: -0.2%;

}

.tm {
  margin-bottom: -10%;
}

.mb {
  width: 70%;
}

.linea{
  margin-left: 10%;
}

li {
  display: inline;
}

.wd {
  width: 100%;
}

.mls{
  margin-left: -2%;
}

.fontstyle{
  font-weight: 700;
}

.img-widht{
  width: 100%;
  margin-right: 1%;
}

.fotodiv {
   width: 13%;
}

.spc {
  margin-right: 10%;
}

.reaccionClass{
  width: 60%;
}

.nombret {
  padding-top: 8px !important;
  vertical-align: top;
}

.mglobal{
margin-top: 7% !important;
  margin-left: 7% !important;
  margin-right: 1%;
  margin-bottom: 7% !important;
}

.mrgntop{
  margin-top: -5%;
}

.blr {
  backdrop-filter: blur(8px) saturate(120%) contrast(50%) !important;
}

.divTable{
	display: table;
	width: 100%;
}
.divTableRow {
	display: table-row;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
}
.divTableCell, .divTableHead {
	border: 1px solid #fff;
	display: table-cell;
	padding: 3px 10px;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
	font-weight: bold;
}
.divTableFoot {
	background-color: #EEE;
	display: table-footer-group;
	font-weight: bold;
}
.divTableBody {
	display: table-row-group;
}


.cerrar {
    background-image: url('data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMiIgZGF0YS1uYW1lPSJMYXllciAyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgdmlld0JveD0iMCAwIDMyIDMyIj4NCiAgPGcgaWQ9ImNsb3NlIj4NCiAgICA8cmVjdCBpZD0iUmVjdMOhbmd1bG9fNTE3MCIgZGF0YS1uYW1lPSJSZWN0w6FuZ3VsbyA1MTcwIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMyIDMyKSByb3RhdGUoMTgwKSIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMCIvPg0KICAgIDxwYXRoIGlkPSJUcmF6YWRvXzE2OTM0IiBkYXRhLW5hbWU9IlRyYXphZG8gMTY5MzQiIGQ9Ik0xOC4zNDksMTZsNy4xNjQtNy4xNDhhMS42NzMsMS42NzMsMCwxLDAtMi4zNjYtMi4zNjZMMTYsMTMuNjUsOC44NTMsNi40ODZBMS42NzMsMS42NzMsMCwwLDAsNi40ODcsOC44NTJMMTMuNjUxLDE2LDYuNDg3LDIzLjE0N2ExLjY3MywxLjY3MywwLDEsMCwyLjM2NiwyLjM2NkwxNiwxOC4zNDlsNy4xNDcsNy4xNjRhMS42NzMsMS42NzMsMCwxLDAsMi4zNjYtMi4zNjZaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDApIiBmaWxsPSIjMDAwIi8+DQogIDwvZz4NCjwvc3ZnPg0K');
    background-repeat: no-repeat, repeat;
    margin-top: 10.5% !important;
}

.static {
  height: 400px;
}

.d-mobile-f{
  display: block;
}

.d-desktop-f{
  display: none;
}

.widthmobile{
  width: 100% !important;
}  

@media screen and (min-width: 331px) and (max-width: 600px){
  .mobile-datos{
    display: -webkit-box !important;
  }
  .Personalizado {
    white-space: pre-line;
  }
  .d-mobile-f{
    display: none;
  }
  .d-desktop-f{
    display: inline;
  }  
  .p-5 {
    padding: 0.4rem !important;
  }
  .timeago span {
    font-size: 8px !important;
  }
  .Inscribirme {
      margin-left: 0% !important;
  }
  .Postula{
    margin-left: 0%;
  }  
  .mr-2 {
    margin-right: 0.3rem !important;
  }
  .nrolikes {
      margin-right: 42% !important;
  }  
  .wkb {
      display: -webkit-box !important;
  }  
  .mt-3 {
      margin-top: 1px !important;
  }
  .tm-icon-1 {
      width: 20% !important;
  }  
  .tm-icon-2 {
      width: 15% !important;
  }    
  .-img-fotoperfil {
      width: 12% !important;
  }  
  .-mbmp{
    margin-bottom: 20% !important;
  }
  .-mnbta{
    margin-right: 45% !important;
    margin-bottom: -6% !important;
  }
  .mglobal {
      margin-left: 0% !important;
      margin-right: 0%;
      margin-bottom: 7% !important;
  }
}

/* SURFACE 540PX */


/* SURFACE 540PX */

/* TABLETS 769PX - 920 */
@media screen and (min-width: 769px) and (max-width: 920px){
  .d-mobile-f{
    display: none;
  }
  .-fcmobile{
    font-size: 12px !important;
    margin-right: 1rem !important;
  }
  .reaccionessvg {
    width: 130%;
  }
  .d-desktop-f{
    display: inline;
  }  
  .underline {
    white-space: break-spaces;
  }
  .-img-fotoperfil {
      width: 20% !important;
      height: 10%;
  }  
  .Inscribirme {
      margin-left: 0%;
  }
  .widthmobile{
    width: 115% !important;
  }
  .nrolikes {
      margin-right: 30%;
      color: #7f8794 !important;
  }  
}
/* TABLETS 769PX - 920 */

/* TABLETS 921px - 920 */
@media screen and (min-width: 921px) and (max-width: 1154px){
  .d-mobile-f{
    display: none;
  }
  .d-desktop-f{
    display: inline;
  }  
  .underline {
    white-space: break-spaces;
  }
  .-img-fotoperfil {
      width: 20% !important;
      height: 10%;
  }  
  .Inscribirme {
      margin-left: 0%;
  }
  .widthmobile{
    width: 100% !important;
  }
  .nrolikes {
      margin-right: 14%;
      color: #7f8794 !important;
  }  
}
/* TABLETS 769PX - 920 */

/* RESOLUCION MAS BAJA 320 O MENOR */

@media screen and (min-width: 100px) and (max-width: 330px){
  .mobile-datos{
    display: -webkit-box !important;
  }
  .Personalizado {
    white-space: pre-line;
  }
  .d-mobile-f{
    display: none;
  }
  .d-desktop-f{
    display: inline;
  }  
  .p-5 {
    padding: 0.4rem !important;
  }
  .timeago span {
    font-size: 8px !important;
  }
  .Inscribirme {
      margin-left: 0% !important;
  }
  .Postula{
    margin-left: 0%;
  }  
  .mr-2 {
    margin-right: 0.3rem !important;
  }
  .nrolikes {
      margin-right: 42% !important;
  }  
  .wkb {
      display: -webkit-box !important;
  }  
  .mt-3 {
      margin-top: 1px !important;
  }
  .tm-icon-1 {
      width: 20% !important;
  }  
  .tm-icon-2 {
      width: 15% !important;
  }    
  .-img-fotoperfil {
      width: 12% !important;
  }  
  .-mbmp{
    margin-bottom: 20% !important;
  }
  .-mnbta{
    margin-right: 35% !important;
    margin-bottom: -6% !important;
  }
  .mglobal {
      margin-left: 0% !important;
      margin-right: 0%;
      margin-bottom: 7% !important;
  }
  .widthmobile{
    width: 100% !important;
  }  
}

/* RESOLUCION MAS BAJA 320 O MENOR */
</style>
