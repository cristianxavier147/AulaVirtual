<template>
    <div id="contentCursos" class="py-2 mt-4 text-left -scrolleable">

        <form
        @submit.prevent
        >

        <div class="pl-1 mb-2">
            <div class="container">
                    <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" :class="'select-css-' + classGeneral" @change="onChangeAreaPublicadora($event)">
                        <option selected disabled>Area encargada</option>
                        <option v-for="(AreaPublicadora,index) in AreaPubliLista" :key="index" :value="AreaPublicadora.IdMaestroRegistro+'-'+AreaPublicadora.Nombre" >{{AreaPublicadora.Nombre}}</option>  
                    </select>
            </div>
        </div>

        <div class="pl-1 mb-2">
            <textarea  placeholder="Escribe aquí..." ref="Mensaje" class="rounded-md w-full bg-white  font-bold p-5 md:mx-0 lg:mx-0 mx-5 borderlinea"></textarea>
            <div id="twemoji-textarea"></div>
        </div>
        <div class="pl-1 mb-2">
            <div class="container">         
                <vue-base64-file-upload 
                    class="v1"
                    accept="image/png"
                    image-class="v1-image"
                    input-class="v1-image"
                    :disable-preview = "true"
                    placeholder="Adjunta aquí"
                    :max-size="customImageMaxSize"
                    @size-exceeded="onSizeExceeded"
                    @load="ImagenAdjuntaUno" />
            </div>
        </div>
        <div class="pl-1 mb-2">
            <div class="container">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" @change="onChangeAudienciaId($event)" :class="'select-css-' + classGeneral">
                            <option disabled selected>Audiencia</option>
                            <option v-for="(audiencia,index) in AudienciaLista" :key="index" :value="audiencia.Codigo">{{audiencia.Nombre}}</option>                            
                        </select>                        

                    </div>
                    <div>

                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" :class="'select-css-' + classGeneral" @change="onChangeSede($event)" >
                            <option disabled selected>Sede</option>
                            <option v-for="(sede,index) in SedeLista" :key="index" :value="sede.IdSede">{{sede.SedeNombre}}</option>
                        </select>


                    </div>
                </div>
            </div>
        </div>

        <div class="pl-1 mb-2">
            <div class="container">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" :class="'select-css-' + classGeneral" @change="onChangeUND($event)">
                            <option disabled selected>División</option>
                            <option v-for="(division,index) in UnidNegoDivi" :key="index" :value="division.IdUnidadNegocio">{{division.UnidadNegocioNombre}}</option>
                        </select>                        

                    </div>
                    <div>
                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" :class="'select-css-' + classGeneral" @change="onChangeEAP($event)">
                            <option disabled selected>Programa</option>
                            <option v-for="(programa,index) in EmpAcaPro" :key="index" :value="programa.IdUnidadAcademica">{{programa.UnidadAcademicaNombre}}</option>
                        </select>                        

                    </div>
                </div>
            </div>
        </div>

        <div class="pl-1 mb-2">
            <div class="container">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" :class="'select-css-' + classGeneral" @change="onChangeProcar($event)">
                            <option disabled selected>Carrera</option>
                            <option v-for="(carrera,index) in Procar" :key="index" :value="carrera.IdProducto">{{carrera.ProductoNombre}}</option>
                        </select>                        

                    </div>
                    <div>
                        <select  class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" @change="onChangeCiclo($event)" :class="'select-css-' + classGeneral">
                            <option disabled selected>Ciclo</option>
                            <option v-for="(ciclo, index) in Ciclo" :key="index" :value="ciclo.IdModulo">{{ciclo.NombreModulo}}</option>
                        </select>

                    </div>
                </div>
            </div>
        </div>



        <div class="pl-1 mb-2">
            <div class="container">
                    <select  v-model="Opciones" class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" @change="onChangeTipoId($event)" :class="'select-css-' + classGeneral">
                        <option value="-1" disabled selected>Tipo de Publicación</option>
                        <option v-for="publicaciontipo in TipoPublicacionLista" :key="publicaciontipo.Nombre" :value="publicaciontipo.Codigo +'-'+publicaciontipo.IdMaestroRegistro">{{publicaciontipo.Nombre}}</option>  
                    </select>
            </div>
        </div>

        <div class="pl-1 mb-2" v-if="publicaciontipoIdMaestro === 'EVAPUB001' || publicaciontipoIdMaestro === 'EVAPUB002' || publicaciontipoIdMaestro === 'EVAPUB003'">
            <div class="container">
                <input  type="text" id="Btnlink" class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea link" ref="linktxt" placeholder="Adjuntar link" >
            </div>
        </div>

        <div class="pl-1 mb-2" v-if="publicaciontipoIdMaestro === 'EVAPUB003'">
            <div class="container">
                <input  type="text" id="Btnemail" class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea link" ref="correo" placeholder="Adjuntar email" >
            </div>
        </div>

        <div class="pl-1 mb-2" v-if="publicaciontipoIdMaestro === 'EVAPUB004'">
            <div class="container">
                <input  type="text" id="BtnNombre" :maxlength="max" class="rounded-md w-full bg-white  font-bold pl-5 md:mx-0 lg:mx-0 mx-5 borderlinea" value="" ref="BtnNombre" placeholder="Nombre del botón" >
            </div>
        </div>

        <div class="pl-1 mb-2" v-if="publicaciontipoIdMaestro === 'EVAPUB004'">
            <div class="container">
                <vue-base64-file-upload 
                    accept="application/pdf"
                    :disable-preview = "true"
                    image-class="v1-image"
                    input-class="v1-image"                    
                    placeholder="Adjunta aquí"
                    :max-size="customImageMaxSize"
                    @size-exceeded="onSizeExceeded"
                    @load="ImagenAdjuntaDos" 
                />
            </div>
        </div>

        <div class="pl-1 mb-2">
            <div class="container">
                <VueCtkDateTimePicker 
                v-model="FechaInicio"
                id="FechaInicio"
                color="grey"
                label="Fecha de inicio"
                ref = "FechaInicio"
                class="fw"
                button-now-translation = "Ahora"
                :right = true
                />

            </div>
            
        </div>

        <span v-if="CmdFijar === 'NADA'">
        </span>
        <span v-else>
            <div class="pl-1 mb-2">
                <div class="container">
                    <div class="grid grid-cols-2 gap-4">
                            <label class="contenedor font-bold text-sm">Fijar esta publicación
                            <input  type="checkbox" v-on:click="samplefunction($event)">
                            <span class="checkmark"></span>
                            </label>
                        <div>
                            <VueCtkDateTimePicker 
                            v-model="FechaFinalFijado"
                            id="FechaFinalFijado"
                            color="grey"
                            label="Fijar hasta"
                            ref="FechaFinalFijado"
                            class="fw"
                            button-now-translation = "Ahora"
                            :no-button-now = true
                            :right = false
                            />

                        </div>
                    </div>
                </div>
            </div>            
        </span>



        <div class="pl-1 mb-2">
            <div class="container">
                <input type="submit"  value="Publicar" id="BtnEnviarPublicacion" class="w-full px-6 py-3 font-bold text-center text-white rounded-lg size-text-16" :class="'bg-' + classGeneral + '-600'" @click.prevent="getFormValues();" />
            </div>
        </div>        


        </form>


    </div>
</template>
<script>
import Vue from 'vue';
import VueBase64FileUpload from 'vue-base64-file-upload';
import VueCtkDateTimePicker from 'vue-ctk-date-time-picker';
import 'vue-ctk-date-time-picker/dist/vue-ctk-date-time-picker.css';
import {
TwemojiTextarea
} from '@kevinfaguiar/vue-twemoji-picker';
import EmojiAllData from '@kevinfaguiar/vue-twemoji-picker/emoji-data/es/emoji-all-groups.json';
import EmojiGroups from '@kevinfaguiar/vue-twemoji-picker/emoji-data/emoji-groups.json';

Vue.component('VueCtkDateTimePicker', VueCtkDateTimePicker);
export default {
    components: {
        VueBase64FileUpload,
        'twemoji-textarea': TwemojiTextarea
    },
    name: "Admin",
    data(){
        return {
        customImageMaxSize: 3, // megabytes
        FechaInicio: '',
        max: 23,
        AreaPublicadora: '',
        IdAreaPublicadora: '',
        IdTipoPublicacion: '',
        FechaFinalFijado: '',
        FechaFinalFijadoSubmit: '',
        FechaInicioSubmit: '',
        FechaCreacionSubmit: '',
        AudienciaId : '',
        correo: '',
        ExtImgUno : "image/png",
        ciclo: '',
        URLImagen: '', //incognita
        RutaImagen: '', //incognita
        URLArchivo: '', //incognita
        RutaArchivo: '',   //incognita      
        linktext: '',
        btnnombre: '1',
        AlertSelect: '0',
        MensajeSubmit: '',
        ImagenAdjuntaUnoI: '',
        ImagenAdjuntaDosII: '',
        SedeLista: [],
        AudienciaLista: [],
        TipoPublicacionLista: [],
        UnidNegoDivi: [],
        EmpAcaPro: [],
        Procar: [],
        Ciclo: [],
        AreaPubliLista: [],
        FechaActual: "",
        CmdFijar: '',
        ExtImgDos: 'application/pdf',
        Opciones: '-1',
        atr: "false",
        publicaciontipoCodigo: '',
        publicaciontipoIdMaestro:'-1',
        ExtImgUnos: ''

        };
    },
    computed: {
      emojiDataAll() {
          return EmojiAllData;
      },
      emojiGroups() {
          return EmojiGroups;
      },
        classGeneral(){
        return localStorage.getItem('classGeneral')
        },

        store(){
        return JSON.parse(localStorage.getItem('data'))
        }        
    },
    methods: {
        addItem: function() {
            disableButton = true; // Or result['disableButton'] = true;

        },        
        ValidaFijado(){
            this.$store.dispatch("sidebarStore/EsFijado").then((response) => {


                if (response.success) {
                    var RespuestaF = response.results.retorno;
                    if (RespuestaF.length === 0){
                        this.CmdFijar = 'NADA'
                    }else{
                        this.CmdFijar = 'OK'
                    }
                }


            });  
        },        
        onChangeCiclo(event){
            this.ciclo = event.target.value;
        },
        onChangeAudienciaId(event){
            this.AudienciaId = event.target.value;
        },
        onChangeTipoId (event) {
            var e = event.target.value;
            var b = e.split("-")[1]
            var c = e.split("-")[0]
            this.publicaciontipoCodigo =  b;
            this.publicaciontipoIdMaestro = c;            
        },
        onChangeAreaPublicadora(event) {
            var e = event.target.value;
            var b = e.split("-")[1]
            var c = e.split("-")[0]
            this.AreaPublicadora =  b;
            this.IdAreaPublicadora = c;
        },
        onFile(file) {
        },
        itemsContains(n) {
            return this.ExtImgUno.indexOf(n) > -1
        },     
        ImagenAdjuntaUno(dataUri,index) {
            localStorage.setItem("ImagenAdjuntaUno", dataUri);
            this.ImagenAdjuntaUnoI = dataUri.slice(22); //actual
            //this.ImagenAdjuntaUnoI = dataUri;
            var d = dataUri.split(":")[1];
            //this.ExtImgUno = d.slice(index, 10);
            this.ExtImgUno = "image/png";
            console.log(this.ImagenAdjuntaUnoI)
        },
        ImagenAdjuntaDos(dataUri,index) {
            this.ImagenAdjuntaDosII = dataUri.slice(28);
            var d = dataUri.split(":")[1];
            this.ExtImgDos = d.slice(index, 15);
        },        
        onLoad(dataUri) {
        },        
        FechaAhora: function() {
            const today = new Date();
            const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            const dateTime = date +' '+ time;
            this.FechaActual = dateTime;
        },
        samplefunction : function(event) {
            if (event.target.checked) {
                this.AlertSelect =  "1";
            }else{
                this.AlertSelect =  "0";
            }
        },        
        getFormValues () {
            let store = JSON.parse(localStorage.getItem('data'))
            /* CONDICIONES */
            var ciclos = this.ciclo;
            if (ciclos == '' || ciclos == null){
                var cicloA = "-1"
            } else {
                var cicloA = this.ciclo;
            }
            var Producto = localStorage.getItem('UniAcid');
            if (Producto == '' || Producto == null){
                var productoI = "-1";
            } else {
                var productoI = localStorage.getItem('UniAcid');
            }
                //this.ImagenAdjuntaUnoI;
            /* Obtenemos la primera caja de comentarios*/
                var Mensaje = this.$refs.Mensaje.value;
                this.MensajeSubmit = Mensaje;

        var TipoPubliVerif = this.publicaciontipoIdMaestro
        if (TipoPubliVerif == 'EVAPUB001' || TipoPubliVerif == 'EVAPUB002'){
                var linkk = this.$refs.linktxt.value;
                if(linkk == "" || linkk == null){
                    var link = "0";
                }else{
                    var link = this.$refs.linktxt.value;
                }
                this.linktext = link;
        }else if (TipoPubliVerif == 'EVAPUB003' ){

                var linkk = this.$refs.linktxt.value;
                if(linkk == "" || linkk == null){
                    var link = "0";
                }else{
                    var link = this.$refs.linktxt.value;
                }
                this.linktext = link;   

                var correoo = this.$refs.correo.value;
                if (correoo == "" || correoo == null){
                    var correo = "0";
                }else{
                    var correo = this.$refs.correo.value;
                }
                this.correo = correo;

        }else if (TipoPubliVerif ==  'EVAPUB004'){
                var Nombree = this.$refs.BtnNombre.value;
                if (Nombree == "" || Nombree == null) {
                    var BtnNombre = "0";
                }else{
                    var BtnNombre = this.$refs.BtnNombre.value;
                }

                this.btnnombre = BtnNombre;
        }
        var Fijado = this.CmdFijar
        if (Fijado === '' || Fijado === null || Fijado == "NADA"){
                    Fecha = new Date(this.FechaActual);
                    var YearFijado = Fecha.getFullYear();
                    var MesFijadoR = Fecha.getMonth()+1;
                    var MesFijado = (MesFijadoR<10?'0':'') + MesFijadoR;
                    var DiaFijado = (Fecha.getDate()<10?'0':'') + Fecha.getDate();
                    var HoraFijadoR = Fecha.getHours();
                    var HoraFijado= (HoraFijadoR<10?'0':'') + HoraFijadoR;
                    var MinutosFijadoR = Fecha.getMinutes() + 1;
                    var MinutosFijado = (MinutosFijadoR<10?'0':'') + MinutosFijadoR;
                    var SegundosFijado = Fecha.getSeconds()+11;
                    this.FechaFinalFijadoSubmit = YearFijado + "-" + MesFijado + "-" + DiaFijado + "T" + HoraFijado + ":" + MinutosFijado + ":" + SegundosFijado + ".333Z"; //Fecha Fijada 
        }else if (Fijado == "OK"){
                        /*Obtenemos FechaFijada*/
                var FechaFinalFijadoRAW = this.$refs.FechaFinalFijado.value;
                if (FechaFinalFijadoRAW == '' || FechaFinalFijadoRAW == null){
                    Fecha = new Date(this.FechaActual);
                    var YearFijado = Fecha.getFullYear();
                    var MesFijadoR = Fecha.getMonth()+1;
                    var MesFijado = (MesFijadoR<10?'0':'') + MesFijadoR;
                    var DiaFijado = (Fecha.getDate()<10?'0':'') + Fecha.getDate();
                    var HoraFijadoR = Fecha.getHours();
                    var HoraFijado= (HoraFijadoR<10?'0':'') + HoraFijadoR;
                    var MinutosFijadoR = Fecha.getMinutes() + 1;
                    var MinutosFijado = (MinutosFijadoR<10?'0':'') + MinutosFijadoR;
                    var SegundosFijado = Fecha.getSeconds()+11;
                    this.FechaFinalFijadoSubmit = YearFijado + "-" + MesFijado + "-" + DiaFijado + "T" + HoraFijado + ":" + MinutosFijado + ":" + SegundosFijado + ".333Z"; //Fecha Fijada Transformada                    
                }else{
                    var FechaRa = FechaFinalFijadoRAW.replace("T", " ");
                    var Fechas = FechaRa.replace("Z","");
                    var Fecha = new Date(Fechas);
                    var YearFijado = Fecha.getFullYear();
                    var MesFijadoR = Fecha.getMonth()+1;
                    var MesFijado = (MesFijadoR<10?'0':'') + MesFijadoR;
                    var DiaFijado = (Fecha.getDate()<10?'0':'') + Fecha.getDate();
                    var HoraFijadoR =  Fecha.getHours();
                    var HoraFijado= (HoraFijadoR<10?'0':'') + HoraFijadoR;
                    var MinutosFijadoR = Fecha.getMinutes() + 1;
                    var MinutosFijado = (MinutosFijadoR<10?'0':'') + MinutosFijadoR;
                    var SegundosFijado = Fecha.getSeconds()+11;
                    this.FechaFinalFijadoSubmit = YearFijado   + "-" + MesFijado + "-" + DiaFijado  + "T" + HoraFijado + ":" + MinutosFijado + ":" + SegundosFijado + ".333Z"; //Fecha Fijada Transformada
                }
            /*Obtenemos FechaFijada*/
        }

            /*Obtenemos FechaInicio*/
                var FechaIRAW = this.$refs.FechaInicio.value;
                var FechaRaI = FechaIRAW.replace("T", " ");
                var FechaI = FechaRaI.replace("Z","");
                var FechaI = new Date(FechaI);
                var YearI = FechaI.getFullYear();
                var MesIR = FechaI.getMonth()+1;
                var MesI = (MesIR<10?'0':'') + MesIR;
                var DiaI = (FechaI.getDate()<10?'0':'') + FechaI.getDate();
                var HoraIR = FechaI.getHours();
                var HoraI= (HoraIR<10?'0':'') + HoraIR;
                var MinutosIR = FechaI.getMinutes() + 3;
                var MinutosI = (MinutosIR<10?'0':'') + MinutosIR;
                var SegundosI = FechaI.getSeconds()+22;
                this.FechaInicioSubmit = YearI  + "-" + MesI + "-" + DiaI  + "T" + HoraI + ":" + MinutosI + ":" + SegundosI + ".111Z"; //Fecha Fijada Transformada
            /*Obtenemos FechaInicio*/  
            /*Obtenemos FechaCreacion*/
                var FechaC = new Date(this.FechaActual);
                var YearC = FechaC.getFullYear();
                var MesCR = FechaC.getMonth()+1;
                var MesC = (MesCR<10?'0':'') + MesCR;
                var DiaC = (FechaC.getDate()<10?'0':'') + FechaC.getDate();
                var HoraCR = FechaC.getHours();
                var HoraC= (HoraCR<10?'0':'') + HoraCR;
                var MinutosCR = FechaC.getMinutes();
                var MinutosC = (MinutosCR<10?'0':'') + MinutosCR;
                var SegundosC = FechaI.getSeconds()+33;
                this.FechaCreacionSubmit = YearC + "-" + MesC + "-" + DiaC + "T" + HoraC + ":" + MinutosC + ":" + SegundosC + ".222Z"; //Fecha Fijada Transformada
            /*Obtenemos FechaCreacion*/                      

            var IdPublicacion = '0';

            var IdUsuarioPublicador =  store.user_id_usuario;
            var NombreUsuarioPublicador = store.user_name + " " + store.user_pat_name;
            
            this.$store.dispatch("submitpubStore/submitPublicacion", {
                IdPublicacions: IdPublicacion,
                IdUsuarioPublicadors: IdUsuarioPublicador,
                NombreUsuarioPublicadors: NombreUsuarioPublicador,
                IdAreaPublicadoras: this.IdAreaPublicadora,
                AreaPublicadoras: this.AreaPublicadora,
                Textos:this.MensajeSubmit,
                IdTipoPublicacions: this.publicaciontipoIdMaestro,
                DescPublicacions: this.btnnombre,
                LinkTextoTipoPublicacions: this.linktext,
                CorreoInfoTipoPublicacions: this.correo,
                EsFijadas:this.AlertSelect,
                URLImagens: this.URLImagen,
                RutaImagens: this.RutaImagen,
                URLArchivos: this.URLArchivo,
                RutaArchivos: this.RutaArchivo,
                IdUsuarioAudiencias: this.AudienciaId,
                IdSedes: localStorage.getItem("SedeID"),
                IdFacultads: "1",
                IdUnidadNegocios: localStorage.getItem("undid"),
                IdUnidadAcademicas: localStorage.getItem("procarid"),
                IdProductos: productoI,
                IdModulos: cicloA,
                IdPromocions: '-1' ,
                IdGrupos: "-1",
                IdSeccions :"-1",
                FechaInicials: this.FechaInicioSubmit,
                FechaFinals: this.FechaFinalFijadoSubmit,
                Estados: "1",
                UsuarioCreacions:IdUsuarioPublicador,
                FechaCreacions: this.FechaCreacionSubmit,
                UsuarioModificacions: IdUsuarioPublicador,
                FechaModificacions: this.FechaInicioSubmit,
                MeInteresas: "",
                MeEmocionas: "",
                MeEnorgulleces: "",
                IdActorImg: "0",
                BytesFotoImg: this.ImagenAdjuntaUnoI, 
                LoginImg: '',
                ExtImg: this.ExtImgUno,
                IdActorArchivo: '0', 
                BytesFotoArchivo:  this.ImagenAdjuntaDosII , 
                LoginArchivo: "string", 
                ExtArchivo: "application/pdf"
                }).then((response) => {
                if(response.success){
                    setTimeout(this.$router.go(this.$router.currentRoute), 5000)
                }else{
                }
            })
        },
    
        onSizeExceeded(size) {
        alert(`La imagen actual excede el limite de tamaño : ${size}Mb, Max: ${this.customImageMaxSize}Mb`);
        },
        filtroSede() {
            var IDempresa = "1";
            var IdSede = "1";
            var IdFacultad = "1";
            var IdUnidadNegocio = "1";
            var IdUnidadAcademica = "1";
            var IdProducto = "1";            
            var opcion = "05";

            this.$store.dispatch("filtroStore/filtro", {IdEmpresas: IDempresa, IdSedes: IdSede, IdFacultads: IdFacultad, IdUnidadNegocios: IdUnidadNegocio, IdUnidadAcademicas: IdUnidadAcademica, IdProductos: IdProducto, opciones: opcion}).then((response) => {
                if(response.success){
                    var myObj = response;
                    var Sede = myObj.results.lisQuerySede;
                    var Audiencia = myObj.results.lisQueryAudicencia; 
                    var AreaPublicadora = myObj.results.lisQueryAreaPublicadora;
                    var TipoPublicacion = myObj.results.lisQueryTipoPublicacion;
                    var TipoCiclo = myObj.results.lisQueryCurrriculaModulo;
                    this.AudienciaArray = Audiencia;
                    this.TipoPublicacionArray = TipoPublicacion;
                    this.SedeArray = Sede;
                    this.AreaPublicadoraArray = AreaPublicadora; 
                    this.TippoCiclo = TipoCiclo;
                    this.SedeArray.forEach((value, index) => {
                        this.SedeLista.push(value);
                    });
                    this.AudienciaArray.forEach((value, index) => {
                        this.AudienciaLista.push(value);
                    });
                    this.AreaPublicadoraArray.forEach((value, index) => {
                        this.AreaPubliLista.push(value);
                    });
                    this.TipoPublicacionArray.forEach((value, index) => {
                        this.TipoPublicacionLista.push(value);
                    });  
                    this.TippoCiclo.forEach((value, index) => {
                        this.Ciclo.push(value);
                    });                              

                }                
            })
        },

        onChangeSede(event) {
            this.UnidNegoDivi.length = 0;
            this.filtroUnidadNegocioDivision(event.target.value);

        },

        filtroUnidadNegocioDivision(SedeID) {
            var IDempresa = "1";
            if (SedeID == '' || SedeID == null){
                var SedeIdD = '-1'
            }else{
                var SedeIdD = SedeID;
                localStorage.setItem("SedeID", SedeID);
            }
            var IdSede = SedeIdD;
            var IdFacultad = "1";
            var IdUnidadNegocio = "1";
            var IdUnidadAcademica = "1";
            var IdProducto = "-1";

            var opcion = "05";
            this.$store.dispatch("filtroStore/filtro", {IdEmpresas: IDempresa, IdSedes: IdSede, IdFacultads: IdFacultad, IdUnidadNegocios: IdUnidadNegocio, IdUnidadAcademicas: IdUnidadAcademica, IdProductos: IdProducto, opciones: opcion}).then((response) => {
                if(response.success){
                    var myObj = response;
                    var UniDiv = myObj.results.lisQueryEmpresaNegocio;
                    this.UniDivArray = UniDiv;
                    this.UniDivArray.forEach((value, index) => {
                        this.UnidNegoDivi.push(value);
                    })
                    
                }                
            })
        },

        onChangeUND(event) {
            this.EmpAcaPro.length = 0;
            this.filtroEmpresaAcademicaPrograma(event.target.value);

        },

        filtroEmpresaAcademicaPrograma(undid) {
            var IDempresa = "1";
            var IdSede = localStorage.getItem("SedeID"); //sede
            var IdFacultad = "1";
            var IdUnidadNegocio = undid;
            localStorage.setItem("undid", undid);
            var IdUnidadAcademica = "1";
            var IdProducto = "1";
            var opcion = "05";
            this.$store.dispatch("filtroStore/filtro", {IdEmpresas: IDempresa, IdSedes: IdSede, IdFacultads: IdFacultad, IdUnidadNegocios: IdUnidadNegocio, IdUnidadAcademicas: IdUnidadAcademica, IdProductos: IdProducto, opciones: opcion}).then((response) => {
                if(response.success){
                    var myObj = response;
                    var EmpPro = myObj.results.lisQueryEmpresaAcademica;
                    this.EmpAcaProArray = EmpPro;
                    this.EmpAcaProArray.forEach((value, index) => {
                        this.EmpAcaPro.push(value);
                    })
                }                
            })
        },

        onChangeEAP(event) {
            this.Procar.length = 0;
            this.filtroProductoCarrera(event.target.value);

        },

        filtroProductoCarrera(procarid) {
            var IDempresa = "1";
            var IdSede = localStorage.getItem("SedeID");
            var IdFacultad = "1";
            var IdUnidadNegocio = localStorage.getItem("undid");
            var IdUnidadAcademica = procarid;
            localStorage.setItem("procarid", procarid);
            var IdProducto = "1";
            
            var opcion = "05";
            this.$store.dispatch("filtroStore/filtro", {IdEmpresas: IDempresa, IdSedes: IdSede, IdFacultads: IdFacultad, IdUnidadNegocios: IdUnidadNegocio, IdUnidadAcademicas: IdUnidadAcademica, IdProductos: IdProducto, opciones: opcion}).then((response) => {
                if(response.success){
                    var myObj = response;
                    var ProPro = myObj.results.lisQueryProducto;
                    this.PropruArray = ProPro;
                    this.PropruArray.forEach((value, index) => {
                        this.Procar.push(value);
                    })
                }                
            })
        },

        onChangeProcar(event) {
            this.Ciclo.length = 0;
            this.filtroCiclo(event.target.value);

        },

        filtroCiclo(UniAcid) {
            var IDempresa = "1";
            var IdSede = localStorage.getItem("SedeID");
            var IdFacultad = "1";
            var IdUnidadNegocio = localStorage.getItem("undid");
            var IdUnidadAcademica = localStorage.getItem("procarid");
            var IdProductosUniAcid = UniAcid;
            if (IdProductosUniAcid == '' || IdProductosUniAcid == null){
                var IdProducto = '-1';
            }else{
                var IdProducto = UniAcid;
                localStorage.setItem("UniAcid", UniAcid);
            }

            
            var opcion = "00";
            this.$store.dispatch("filtroStore/filtro", {IdEmpresas: IDempresa, IdSedes: IdSede, IdFacultads: IdFacultad, IdUnidadNegocios: IdUnidadNegocio, IdUnidadAcademicas: IdUnidadAcademica, IdProductos: IdProducto, opciones: opcion}).then((response) => {
                if(response.success){
                    var myObj = response;
                    var CurrMod = myObj.results.lisQueryCurrriculaModulo;
                    this.CurrModArray = CurrMod;
                    this.CurrModArray.forEach((value, index) => {
                        this.Ciclo.push(value);
                    })
                }                
            })
        },

        /* SUBMIT */
        BtnSubmit() {
        }
        /* SUBMIT */



    },
    created() {
        this.filtroSede();
        this.ValidaFijado();
        setInterval(this.FechaAhora, 1000);
        this.filtroUnidadNegocioDivision();
        this.filtroCiclo();
        
    }
};
</script>
<style>
.fw .datetimepicker .datepicker{
    margin-left: -110%;
    min-width: 210%;
}
.borderlinea{
    border: #eaeaea 1px solid;
    resize: none;
}
textarea{
    resize: none !important;
}
.custom-file-upload {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
}
.select-css-purple {
    display: block;
    font-weight: 400;
    color: #7f8794;
    padding: .4em 1.4em .3em .8em;
    box-sizing: border-box;
    margin: 5px auto;
    border: 1px solid #eaeaea;
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMS41NjMiIGhlaWdodD0iNi44NDQiIHZpZXdCb3g9IjAgMCAxMS41NjMgNi44NDQiPg0KICA8cGF0aCBpZD0iVHJhemFkb180NzQ3IiBkYXRhLW5hbWU9IlRyYXphZG8gNDc0NyIgZD0iTTExLjMsNS4xODcsNi40NjcuMjkxQS45OTEuOTkxLDAsMCwwLDUuMDU2LjNMLjI2NCw1LjE1N0EuOTg2Ljk4NiwwLDAsMCwxLjY3MSw2LjUzOEw1Ljc2NCwyLjM5Miw5Ljg1NSw2LjUzQS45ODYuOTg2LDAsMSwwLDExLjMsNS4xODdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMS41NjMgNi44NDQpIHJvdGF0ZSgxODApIiBmaWxsPSIjNzIyYWU5Ii8+DQo8L3N2Zz4NCg==');
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}
.-scrolleable {
    overflow-y: scroll;
    height:400px;
}
.select-css-red {
    display: block;
    font-weight: 400;
    color: #7f8794;
    padding: .4em 1.4em .3em .8em;
    box-sizing: border-box;
    margin: 5px auto;
    border: 1px solid #eaeaea;
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMS41NjMiIGhlaWdodD0iNi44NDQiIHZpZXdCb3g9IjAgMCAxMS41NjMgNi44NDQiPg0KICA8cGF0aCBpZD0iVHJhemFkb180NzQ3IiBkYXRhLW5hbWU9IlRyYXphZG8gNDc0NyIgZD0iTTExLjMsNS4xODcsNi40NjcuMjkxQS45OTEuOTkxLDAsMCwwLDUuMDU2LjNMLjI2NCw1LjE1N0EuOTg2Ljk4NiwwLDAsMCwxLjY3MSw2LjUzOEw1Ljc2NCwyLjM5Miw5Ljg1NSw2LjUzQS45ODYuOTg2LDAsMSwwLDExLjMsNS4xODdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMS41NjMgNi44NDQpIHJvdGF0ZSgxODApIiBmaWxsPSIjYzkyMDMzIi8+DQo8L3N2Zz4NCg==');
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}
.select-css-blue {
    display: block;
    font-weight: 400;
    color: #7f8794;
    padding: .4em 1.4em .3em .8em;
    box-sizing: border-box;
    margin: 5px auto;
    border: 1px solid #eaeaea;
    background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMS41NjMiIGhlaWdodD0iNi44NDQiIHZpZXdCb3g9IjAgMCAxMS41NjMgNi44NDQiPg0KICA8cGF0aCBpZD0iVHJhemFkb180NzQ3IiBkYXRhLW5hbWU9IlRyYXphZG8gNDc0NyIgZD0iTTExLjMsNS4xODcsNi40NjcuMjkxQS45OTEuOTkxLDAsMCwwLDUuMDU2LjNMLjI2NCw1LjE1N0EuOTg2Ljk4NiwwLDAsMCwxLjY3MSw2LjUzOEw1Ljc2NCwyLjM5Miw5Ljg1NSw2LjUzQS45ODYuOTg2LDAsMSwwLDExLjMsNS4xODdaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMS41NjMgNi44NDQpIHJvdGF0ZSgxODApIiBmaWxsPSIjNzIyYWU5Ii8+DQo8L3N2Zz4NCg==');
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}

.v1-image{
    padding: 20px;
    color: #7f8794;
    background-color: #fff;
    font-weight: 700;
    background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0idXBsb2FkIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMy43MyIgaGVpZ2h0PSIxMy43MyIgdmlld0JveD0iMCAwIDEzLjczIDEzLjczIj4NCiAgPGcgaWQ9IkdydXBvXzE5MDc1IiBkYXRhLW5hbWU9IkdydXBvIDE5MDc1Ij4NCiAgICA8cGF0aCBpZD0iVHJhemFkb18xNjQ1MCIgZGF0YS1uYW1lPSJUcmF6YWRvIDE2NDUwIiBkPSJNNi41NDgsNy4xNyw5Ljk2OSwzLjc0OWEuNjQ1LjY0NSwwLDAsMSwuOTEyLDBMMTQuMyw3LjE3YS42NDUuNjQ1LDAsMSwxLS45MTIuOTEyTDExLjA3LDUuNzYzdjYuODgzYS42NDUuNjQ1LDAsMSwxLTEuMjksMFY1Ljc2M0w3LjQ2LDguMDgyYS42NDUuNjQ1LDAsMSwxLS45MTItLjkxMlptMTAuMSwxMC4xMkg0LjIwNWEuNjQ1LjY0NSwwLDEsMSwwLTEuMjloMTIuNDRhLjY0NS42NDUsMCwxLDEsMCwxLjI5WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTMuNTYgLTMuNTYpIiBmaWxsPSIjNzIyYWU5Ii8+DQogIDwvZz4NCjwvc3ZnPg0K);
    background-repeat: no-repeat, repeat;
    background-position: right 1em top 50%, 0 0;
    background-size: 0.95em auto, 100%; 
    padding: 20px 43px 20px 20px;
}

.link{
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNC44NzUiIGhlaWdodD0iMTQuODc1IiB2aWV3Qm94PSIwIDAgMTQuODc1IDE0Ljg3NSI+DQogIDxwYXRoIGlkPSJJY29uX2F3ZXNvbWUtY2hlY2stY2lyY2xlIiBkYXRhLW5hbWU9Ikljb24gYXdlc29tZS1jaGVjay1jaXJjbGUiIGQ9Ik0xNS40MzcsOEE3LjQzNyw3LjQzNywwLDEsMSw4LC41NjMsNy40MzcsNy40MzcsMCwwLDEsMTUuNDM3LDhabS04LjMsMy45MzhMMTIuNjU4LDYuNDJhLjQ4LjQ4LDAsMCwwLDAtLjY3OWwtLjY3OS0uNjc5YS40OC40OCwwLDAsMC0uNjc5LDBsLTQuNSw0LjUtMi4xLTIuMWEuNDguNDgsMCwwLDAtLjY3OSwwbC0uNjc5LjY3OWEuNDguNDgsMCwwLDAsMCwuNjc5bDMuMTE5LDMuMTE5QS40OC40OCwwLDAsMCw3LjE0LDExLjkzOFoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0wLjU2MyAtMC41NjMpIiBmaWxsPSIjNDlmODdmIi8+DQo8L3N2Zz4NCg==);
    background-repeat: no-repeat, repeat;
    background-position: right 1em top 50%, 0 0;
    background-size: 0.95em auto, 100%; 
}

.contenedor {
    display: block;
    padding: 15px 10px 10px 30px;
    position: relative;
    padding-left: 30px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.contenedor input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 15px;
  left: 0;
  height: 20px;
  width: 20px;
  border: 3px solid #722ae9;
  margin-left: 2px;
}

/* On mouse-over, add a grey background color */
.contenedor:hover input ~ .checkmark {
  background-color: #fff;
}

/* When the checkbox is checked, add a blue background */
.contenedor input:checked ~ .checkmark {
  background-color: #fff;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.contenedor input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.contenedor .checkmark:after {
  left: 5px;
  top: 0px;
  width: 5px;
  height: 10px;
  border: solid #000;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}

.fuente{
    color: #7f8794 !important;
}

.fw{
    font-weight: 700 !important; 
}

.bg-purple-600 { 
    --tw-bg-opacity: 1 !important;
    background-color: #805ad5 !important; 
    }

.bg-red-600 {
    --tw-bg-opacity: 1 !important;
    background-color: rgba(220, 38, 38, var(--tw-bg-opacity)) !important;
}

.bg-blue-600 {	
    --tw-bg-opacity: 1 !important;
    background-color: rgba(37, 99, 235, var(--tw-bg-opacity)) !important;
}
.datepicker {
    width: 15% !important;
    max-width: 14% !important;
    min-width: 327px !important;
}
</style>