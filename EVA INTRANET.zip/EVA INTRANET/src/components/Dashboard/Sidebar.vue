<template>
  <div class="text-left cont-sidebar">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <ul v-else>
      <li class="flex py-3">
        <object type="image/svg+xml" :data="require(`@/assets/sidebar/${this.$route.name == 'dashboard' ? 'home-' + classGeneral : 'home'}.svg`)" class="mr-2 tm-svg"> </object>
        <span class="my-auto font-bold">
          <router-link :to="{ name: 'dashboard' }" exact>
            <span class="block font-medium size-text-14 size-text-res-16" @click="closeSidebar(2)" :class="this.$route.name == 'dashboard' ? 'text-' + classGeneral : 'txt-gray'">Inicio</span>
          </router-link>
        </span>
      </li>
      <li v-if="store.user_type_usuario === '1'" class="relative flex py-3" @click="opDropdows('collapseCursos')">
        <object type="image/svg+xml" :data="require(`@/assets/sidebar/${this.$route.name == 'cursosAnvanceCurricular' || this.$route.name == 'cursosFinalizados' || this.$route.name == 'cursos' ? 'cursos-' + classGeneral : 'cursos'}.svg`)" class="mr-2 tm-svg"> </object>
        <span class="my-auto font-bold">
          <span class="block font-medium cursor-pointer size-text-14 size-text-res-16" :class="this.$route.name == 'cursosAnvanceCurricular' || this.$route.name == 'cursosFinalizados' || this.$route.name == 'cursos' ? 'text-' + classGeneral : 'txt-gray'">Mis cursos</span>
        </span>
        <img src="@/assets/sidebar/arrow-close.svg" alt="accesso" class="absolute right-0 mt-0 ml-5 mr-2 text-right cursor-pointer md:relative lg:relative" />
      </li>
      <li v-if="store.user_type_usuario === '1'" id="collapseCursos" class="ml-2">
        <ul>
          <li class="block pt-2 pb-1" v-for="(item, index) in cursos" :key="index">
            <div :id="'item-drop' + index" class="flex pt-0">
              <img src="@/assets/sidebar/carpeta.svg" alt="accesso" class="mr-4" />
              <span class="font-medium cursor-pointer size-text-14 size-text-res-16 txt-gray" @click="toogleCollapse(index, 1)">{{ item.NombreProducto | capitalize }}</span>
            </div>
            <ul :id="'collapse' + index" class="ml-3 notactive-drop-inte">
              <li class="flex py-2" v-for="(curso, i) in item.Cursos" :key="i">
                <div>
                  <div class="rounded-lg w-2.5 h-2.5 mr-4" :style="'background:' + curso.color"></div>
                </div>
                <router-link class="flex -mt-1" :to="{ path: '/alumnos/cursos/curso/' + curso.CursoNombre, query: { id_seccion: curso.IdSeccion, credito: curso.CursoCredito } }" exact>
                  <span class="font-medium size-text-14 size-text-res-16" :class="$route.params.slug === curso.CursoNombre ? 'text-' + classGeneral : 'txt-gray'" @click="refreshCursos(curso.MoodleURL)">{{ curso.CursoNombre | capitalize }}</span>
                </router-link>
              </li>
            </ul>
          </li>
          <!--<li class="block pt-2 pb-1">
            <div class="flex">
              <router-link class="flex" to="/alumnos/cursos/avance-curricular" exact>
                <div class="rounded-lg w-2.5 h-2.5 bg-gray"></div>
                <span class="ml-4 -mt-1 font-medium size-text-14 size-text-res-16 txt-gray" :class="$router.history.current.path === '/alumnos/cursos/avance-curricular' ? 'text-' + classGeneral : 'txt-gray'">Avance Curricular</span>
              </router-link>
            </div>
          </li>-->
          <li class="block pt-2 pb-1">
            <router-link class="flex" to="/alumnos/cursos/avance-curricular" exact>
              <div class="rounded-lg w-2.5 h-2.5 bg-gray"></div>
              <!-- <a :href="routeCurricula" target="_blanck" class="ml-4 -mt-1 font-medium size-text-14 size-text-res-16 txt-gray" @click="closeSidebar(2)">Avance Curricular</a> -->
              <span class="ml-4 -mt-1 font-medium size-text-14 size-text-res-16 txt-gray" @click="closeSidebar(2)">Avance Curricular</span>
            </router-link>
          </li>
          <li class="block pt-2 pb-1">
            <router-link class="flex" to="/alumnos/cursos/finalizados" exact>
              <div class="rounded-lg w-2.5 h-2.5 bg-gray"></div>
              <span class="ml-4 -mt-1 font-medium size-text-14 size-text-res-16 txt-gray" @click="closeSidebar(2)">Cursos Finalizados</span>
            </router-link>
          </li>
        </ul>
      </li>

      <li class="flex py-3 relative" v-if="store.user_type_usuario === '2'">
        <object type="image/svg+xml" :data="require(`@/assets/sidebar/${this.$route.name == 'cursosDocentes' || this.$route.name == 'cursosDocentesDetalle' ? 'cursos-' + classGeneral : 'cursos'}.svg`)" class="mr-2 tm-svg">
        </object>
        <router-link :to="{ name: 'cursosDocentes' }" class="my-auto font-bold">
          <span class="block size-text-14 size-text-res-16 cursor-pointer font-medium" :class="this.$route.name == 'cursosDocentes' || this.$route.name == 'cursosDocentesDetalle' ? 'text-' + classGeneral : 'txt-gray'">Mis cursos</span>
        </router-link>
      </li>


      <!-- menu -->

      <li class="block" v-for="(item, index) in list" :key="index" v-show="item.IdItemParametroPadre === null">
        <div class="relative flex py-3" @click="toogleCollapse(item.IdItemParametro, 2)">
          <object type="image/svg+xml" :data="require(`@/assets/sidebar/${item.Icono}-1.svg`)" class="mr-2 tm-svg"></object>
          <span class="my-auto font-bold">
            <a :href="item.Referencia" :target="item.Target" class="font-medium size-text-14 size-text-res-16 txt-gray" v-if="item.Referencia !== ''">{{ item.Titulo }}</a>
            <span class="font-medium cursor-pointer size-text-14 size-text-res-16 txt-gray" v-else>{{ item.Titulo }}</span>
          </span>
          <img v-if="item.hijos" src="@/assets/sidebar/arrow-close.svg" alt="accesso" class="absolute right-0 mt-0 ml-5 mr-2 text-right cursor-pointer md:relative lg:relative" />
        </div>

        <ul :id="'collapse' + item.IdItemParametro" class="ml-3 notactive-drop-inte">
          <li class="block pt-2 pb-1" v-for="hijo in item.hijos" :key="hijo.IdItemParametro">
            <div class="flex pt-0">
              <div>
                <div class="rounded-lg w-2.5 h-2.5 mr-4 bg-gray"></div>
              </div>
              <a :href="hijo.Referencia" :target="hijo.Target" class="-mt-1 font-medium size-text-14 size-text-res-16 txt-gray">{{ hijo.Titulo }}</a>
            </div>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { nameCursoService } from "@/mixins/nameCurso";
import { eventBus } from "@/config/eventBus";
export default {
  data() {
    return {
      list: [],
      routeCurricula: "",
      cursos: [],
      preloader: true,
    };
  },
  methods: {
    toogleCollapse(item, type) {
      var drops = document.getElementById("collapse" + item);
      drops.classList.toggle("active-drop-inte");

      if (type == 1) {
        var lis_pro = document.getElementById("item-drop" + item);
        lis_pro.classList.toggle("pb-3");
      }
    },
    opDropdows(item) {
      let drop = document.getElementById(item);
      drop.classList.toggle("show");
    },
    contSidebar() {
      this.preloader = true;
      setTimeout(() => {
        let menu = JSON.parse(localStorage.getItem("menu"));
        let items = [];
        menu.map((vl) => {
          if (vl.IdItemParametroPadre == null) {
            items.push(vl);
          }

          if (vl.Icono === "sae") {
            localStorage.setItem("linksae", vl.Referencia);
          }

          if (vl.Icono === "pagos") {
            let name = vl.Referencia;
            let newName = name.replace("_PAG", "_SIT");
            this.routeCurricula = newName;
            localStorage.setItem("linkac", newName);
          }
        });

        for (let i = 0; i < menu.length; i++) {
          for (let y = 0; y < menu.length; y++) {
            if (menu[y].IdItemParametroPadre === menu[i].IdItemParametro) {
              if (menu[i].hijos) {
                menu[i].hijos.push(menu[y]);
              } else {
                menu[i].hijos = [];
                menu[i].hijos.push(menu[y]);
              }
            }
          }
        }

        this.list = menu;
        this.cursos = JSON.parse(localStorage.getItem("cursos"));
        this.preloader = false;
      }, 1000);
    },
    refreshCursos(moodle) {
      eventBus.$emit("refreshCurso");
      this.$emit("closeSidebar", 2);
      this.$store.dispatch("sidebarStore/moodle", moodle);
    },
    closeSidebar(item) {
      var elemts = document.getElementById("collapseCursos");
      elemts.classList.remove("show");

      this.cursos.map((vl, i) => {
        var cont = document.getElementById("collapse" + i);
        cont.classList.remove("active-drop-inte");
      });

      this.list.map((vl, i) => {
        var cont = document.getElementById("collapse" + vl.IdItemParametro);
        cont.classList.remove("active-drop-inte");
      });

      this.$emit("closeSidebar", item);
    },
    rename(value){
        return nameCursoService.simbolos(value);
    }
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  computed: {
    ...mapState("sidebarStore", ["cursosState"]),
    // cursos() {
    //   return this.cursosState;
    // },
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },

  created() {
    this.contSidebar();
  },
};
</script>

<style>
#collapseCursos {
  height: 0;
  display: none;
  padding-bottom: 0;
}
#collapseCursos.show {
  height: auto;
  display: block;
  padding-bottom: 0.75rem;
}

#collapseList {
  height: 0;
  display: none;
  padding-bottom: 0;
}
#collapseList.show {
  height: auto;
  display: block;
  padding-bottom: 0.75rem;
}
</style>
