<template>
  <div id="contentHorarios" class="py-2 mt-4 text-left">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div v-for="(vl, index) in newArr" :key="index">
        <div class="flex">
          <div class="px-5">
            <span class="size-text-12">{{ vl.DiaNombre | nameDia }}</span>
            <br />
            <div :class="diaactual == vl.Dia ? 'bg-black text-white' : 'text-gray-900'" class="flex items-center justify-center  size-text-12 font-medium rounded-2xl" style="width: 25px;height: 25px;">{{ vl.Fecha | formatDia }}</div>
          </div>
          <div class="mb-3">
            <div v-for="(item, i) in vl.horarios" :key="i" :class="item.Inicio <= horaactual && horaactual <= item.Fin && diaactual == vl.Dia ? 'bg-gray-200' : '' " class="pb-1 pl-3 pr-1 mb-2 border-l-8 border-red-500">
              <span class="text-black size-text-16">{{ item.CursoNombre | capitalize }}</span>
              <br />
              <span class="text-black size-text-12" v-if="item.Inicio <= horaactual && horaactual <= item.Fin && diaactual == vl.Dia">Ahora .</span>
              <span class="text-black size-text-12">{{ item.Inicio | formatHorario }} - {{ item.Fin | formatHorario }} . {{ item.AmbienteNombre }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {

  data() {
    return {
      newArr: [],
      diaactual: '',
      horaactual: '',
      preloader: true,
      horarios: []
    };
  },

  methods: {
    orderHorarios(){
      setTimeout(() => {
        let horarios = JSON.parse(localStorage.getItem('horarios'))
        this.horarios = horarios

        var date = new Date()
        this.diaactual = date.getDate()
        this.horaactual = date.getHours()+''+date.getMinutes()
        let nuevoObjeto = {};
        this.horarios.forEach((vl) => {
          if (!nuevoObjeto.hasOwnProperty(vl.Fecha)) {
            nuevoObjeto[vl.Fecha] = {
              horarios: [],
              Fecha: vl.Fecha,
              DiaNombre: vl.DiaNombre,
              Dia: vl.Fecha.substr(0, 2),
            };
          }

          nuevoObjeto[vl.Fecha].horarios.push(vl);
        });

        this.newArr = nuevoObjeto;
        this.preloader = false
      }, 1000);
    }
  },
  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
    nameDia(value) {
      return value.substr(0, 3);
    },
    formatDia(value) {
      return value.substr(0, 2);
    },
    formatHorario(value) {
      value = value.toString();
      if(value.length > 3){
        return value.charAt(0) + value.charAt(1) + ":" + value.slice(2);  
      }else{
        return '0' + value.charAt(0) + ":" + value.slice(1);  
      }
    },
  },
  created() {
    this.orderHorarios()
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>
