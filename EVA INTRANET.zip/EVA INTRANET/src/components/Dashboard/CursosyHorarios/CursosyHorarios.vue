<template>
  <div class="w-full p-3 ml-5 bg-white content-hc rounded-md">
    <div v-for="(items, index) in ValoresAdmin" :key="index" class="positionF">
      <div v-if="items.results.retorno.length !== 0 || items.results.retorno.length !== null || items.results.retorno.length !== '' || items.results.retorno.length !== undefined">
        <div class="grid grid-cols-2">
          <div :class="active == 'cursos' ? 'border-b-4' : 'border-b'" class="py-2 border-purple-600 cursor-pointer">
          <span class="size-text-15" :class="active == 'cursos' ? 'text-' + classGeneral + 'font-bold' : 'text-gray-400 font-bold'">Crear Publicación<nav></nav></span>
          </div>
        </div>
        <PanelAdmin />
      </div>
    </div>
    <div v-if="store.user_type_usuario === '1'">
      <div class="grid grid-cols-2">
        <div @click="openTab('cursos')" :class="active == 'cursos' ? 'brdr-'+classGeneral+' border-b-4 ' : 'border-b'" class="px-3 py-2 cursor-pointer">
          <span class="size-text-16" :class="active == 'cursos' ? 'text-' + classGeneral + '-600 font-bold' : 'text-gray-400 font-bold'">Mis Cursos</span>
        </div>
        <div @click="openTab('horarios')" :class="active == 'horarios' ? 'brdr-'+classGeneral+' border-b-4 ' : 'border-b'" class="px-3 py-2 cursor-pointer">
          <span class="size-text-16" :class="active == 'horarios' ? 'text-' + classGeneral + '-600 font-bold' : 'text-gray-400 font-bold'">Mi Horario</span>
        </div>
      </div>
      <Cursos v-if="active == 'cursos'" />
      <Horarios v-if="active == 'horarios'" />
    </div>
    <div v-if="store.user_type_usuario === '2'">
      <div class="text-left py-3 mb-2">
        <span class="size-text-20 font-semibold">Mi programación</span>
      </div>
      <div class="grid grid-cols-2">
        <div @click="openTab('cursos')" :class="active == 'cursos' ? 'brdr-'+classGeneral+' border-b-4 ' : 'border-b'" class="px-3 py-2 cursor-pointer">
          <span class="size-text-16" :class="active == 'cursos' ? 'text-' + classGeneral + '-600 font-bold' : 'text-gray-400 font-bold'">Semana</span>
        </div>
        <div @click="openTab('horarios')" :class="active == 'horarios' ? 'brdr-'+classGeneral+' border-b-4 ' : 'border-b'" class="px-3 py-2 cursor-pointer">
          <span class="size-text-16" :class="active == 'horarios' ? 'text-' + classGeneral + '-600 font-bold' : 'text-gray-400 font-bold'">Día</span>
        </div>
      </div>
      <Semana v-if="active == 'cursos'" />
      <Dia v-if="active == 'horarios'" />
    </div>
    

  </div>


</template>

<script>
import Cursos from "@/components/Dashboard/CursosyHorarios/Alumnos/Cursos";
import Horarios from "@/components/Dashboard/CursosyHorarios/Alumnos/Horarios";
import Semana from "@/components/Dashboard/CursosyHorarios/Docentes/Semana";
import Dia from "@/components/Dashboard/CursosyHorarios/Docentes/Dia";
import PanelAdmin from "@/components/Dashboard/PanelAdmin/Admin";
export default {
  components: {
    Cursos,
    Horarios,
    PanelAdmin,
    Semana, Dia
  },

  data() {
    return {
      active: "cursos",
      ValoresAdmin: [],
      PanelActivo: ''
    };
  },

  methods: {
    openTab(item) {
      this.active = item;
    },
    ValidaAdmin(){
      this.$store.dispatch("sidebarStore/EsAdmin").then((response) => {


        if (response.success) {
          var myObj = response;
          var Lista = myObj;
          this.Publicaciones = Lista;
          this.ValoresAdmin.push(Lista);
        }


      });  
    },



  },
  created() {
    let store = JSON.parse(localStorage.getItem('data'))
    if ( store.user_type_usuario == '3' ){
      this.ValidaAdmin();
      this.PanelActivo = 'PanelAdmin';
    }else{
      //no se hace nada
    }
    
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>
<style>
#horarios.content-view .content-hc {
    position: fixed !important;
    height: auto !important;
}
.PanelAdmin {
  display: none;
}
/*
#horarios.content-view .content-hc {
    position: absolute !important;
    width: 480px;
    min-width: 480px;
    height: auto !important;
}*/
</style>