<template>
  <div id="contentCursos" class="py-2 mt-4 text-left">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div>
        <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12 rounded-md font-bold p-2.5 text-gray-400 border-gray-100" style="background-color: white"  @change="selectM" name="" id="" v-model="selectMatricula">
            <option selected disabled value="null"> Nombre de carrera </option>
            <option v-for="(item, index) in cursos" :key="index" :value="item.IdMatricula">{{ item.NombreProducto | capitalize }}</option>
        </select>
      </div>
      <div class="pl-3 mt-2">
        <div class="pl-3 mb-2 border-l-8" v-for="(curso, index) in allCursos" :key="index" :style="'border-color:' + curso.color">
          <router-link :to="{ path: '/alumnos/cursos/curso/'+rename(curso.CursoNombre), query : { id_seccion : curso.IdSeccion , credito: curso.CursoCredito} }" exact>
            <span class="text-black size-text-16" @click="refreshCursos(curso.MoodleURL)">{{ curso.CursoNombre | capitalize }}</span>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {
  data() {
    return {
      selectMatricula: null,
      allCursos: [],
      cursos: [],
      preloader: true
    }
  },
  methods: {
    selAc(){
      setTimeout(() => {
        let store = JSON.parse(localStorage.getItem('data'))
        this.selectMatricula = store.user_matricula
        this.selectM()
      }, 1000);
    },
    selectM(){
      let cursos = JSON.parse(localStorage.getItem('cursos'))
      this.cursos = cursos
        // console.log(cursos)
      this.cursos.map(vl => {
        if(vl.IdMatricula == this.selectMatricula){
          this.allCursos = vl.Cursos
        }
      })

      this.preloader = false

    },
    rename(value){
        return nameCursoService.simbolos(value);
    },
    refreshCursos(moodle){
      this.$store.dispatch("sidebarStore/moodle",moodle)
    },
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },
  created() {
    this.selAc()
  },
};
</script>
