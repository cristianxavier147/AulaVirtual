<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="15.334" height="13.35" viewBox="0 0 15.334 13.35">
    <g id="Grupo_18846" data-name="Grupo 18846" transform="translate(15.334 13.35) rotate(180)">
      <g id="Grupo_225" data-name="Grupo 225">
        <path id="Trazado_67" data-name="Trazado 67" d="M185.149,113.161l-5.8-5.722a.953.953,0,0,0-1.339,1.358l4.143,4.089h-11.1a.954.954,0,0,0,0,1.907h11.1l-4.143,4.089a.953.953,0,1,0,1.339,1.358l5.8-5.721a.953.953,0,0,0,0-1.358Z" transform="translate(-170.1 -107.165)" />
      </g>
    </g>
  </svg>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
