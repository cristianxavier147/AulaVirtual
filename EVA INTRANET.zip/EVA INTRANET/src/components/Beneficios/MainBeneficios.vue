<template>
  <div class="bg-gray-100 md:h-full">
    <div class="md:pt-20 pt-24 md:ml-4 md:mr-5 md:h-screen">
      <div class="md:bg-gray-100 lg:w-9/12 mx-auto text-justify md:p-8 ">
        <!-- Titulo -->
        <h1 class="font-bold md:text-2xl mb-10 mx-4 md:mx-0">
          Conoce los beneficios de EVA, tu Entorno Virtual de Aprendizaje
        </h1>
        <!-- contenedor principal -->
        <div class="md:grid grid-cols-3 gap-5">
          <!-- Card-1 -->
          <div class="bg-white mt-5 md:mt-0 rounded-xl">
            <img src="@/assets/png/clases.png" alt="clases" class="w-full" />
            <div class="flex mt-3 mx-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="mr-3 mt-1" width="23.118" height="23.118" viewBox="0 0 23.118 23.118">
                <path id="Icon_awesome-universal-access" data-name="Icon awesome-universal-access" d="M12.122,2.427a9.695,9.695,0,1,1-9.695,9.695,9.69,9.69,0,0,1,9.695-9.695m0-1.864A11.559,11.559,0,1,0,23.681,12.122,11.559,11.559,0,0,0,12.122.563Zm0,2.61a8.949,8.949,0,1,0,8.949,8.949A8.949,8.949,0,0,0,12.122,3.173Zm0,2.051A1.678,1.678,0,1,1,10.444,6.9,1.678,1.678,0,0,1,12.122,5.223Zm5.488,4.569a33.36,33.36,0,0,1-3.828.737c.04,4.709.574,5.735,1.167,7.253a.839.839,0,0,1-1.563.61,13.378,13.378,0,0,1-1.038-3.661H11.9a13.375,13.375,0,0,1-1.038,3.661.839.839,0,1,1-1.563-.61c.593-1.517,1.127-2.542,1.167-7.253a33.343,33.343,0,0,1-3.829-.737.746.746,0,0,1,.343-1.452c4.506,1.064,5.793,1.062,10.29,0a.746.746,0,1,1,.343,1.452Z" transform="translate(-0.563 -0.563)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
              </svg>
              <span class="text-xs font-bold my-2">Aquí podrás encontrar...</span>
            </div>
            <h2 class="p-2 mx-2 pb-12">
              Todo el material de tus clases, así como los accesos directos a éstas.
            </h2>
          </div>
          <!-- Card 2 -->
          <div class="bg-white mt-5 md:mt-0 rounded-xl">
            <img src="@/assets/png/ofertas.png" alt="clases" class="w-full" />
            <div class="flex mt-3 mx-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="mr-3" width="15.943" height="25.509" viewBox="0 0 15.943 25.509">
                <path id="Icon_awesome-mouse-pointer" data-name="Icon awesome-mouse-pointer" d="M15.056,16.4H9.771l2.782,6.776a.926.926,0,0,1-.471,1.2l-2.45,1.068a.881.881,0,0,1-1.162-.484L5.826,18.519,1.509,22.96A.882.882,0,0,1,0,22.32V.912A.882.882,0,0,1,1.508.271l14.17,14.575A.913.913,0,0,1,15.056,16.4Z" transform="translate(0 0)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
              </svg>
              <span class="text-xs font-bold my-2">Aquí podrás encontrar...</span>
            </div>
            <h2 class="p-2 mx-2 text-left">
              Nuestro club laboral, con distintas ofertas de las mejores empresas del mercado.
            </h2>
          </div>
          <!-- Card 3 -->
          <div class="bg-white mt-5 md:mt-0 rounded-xl">
            <img src="@/assets/png/charlas.png" alt="clases" class="w-full" />
            <div class="flex mt-3 mx-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="mr-3 mt-2" width="23.817" height="15.156" viewBox="0 0 23.817 15.156">
                <path id="Icon_material-group" data-name="Icon material-group" d="M17.739,14a3.248,3.248,0,1,0-3.248-3.248A3.234,3.234,0,0,0,17.739,14ZM9.078,14A3.248,3.248,0,1,0,5.83,10.748,3.234,3.234,0,0,0,9.078,14Zm0,2.165c-2.522,0-7.578,1.267-7.578,3.789v2.706H16.656V19.95C16.656,17.427,11.6,16.161,9.078,16.161Zm8.661,0c-.314,0-.671.022-1.05.054a4.568,4.568,0,0,1,2.133,3.735v2.706h6.5V19.95C25.317,17.427,20.261,16.161,17.739,16.161Z" transform="translate(-1.5 -7.5)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
              </svg>
              <span class="text-xs font-bold my-2">Aquí podrás encontrar...</span>
            </div>
            <h2 class="p-2 mx-2 text-left">
              Eventos, charlas, conferencias, voluntariados y actividades que organizamos para ti.
            </h2>
          </div>
        </div>

        <!-- BOTON COMENZAR -->
        <div class="md:flex justify-end items-end mt-7 pb-10 md:px-0 lg:px-0 px-3 ">
          <button class="md:mt-16 text-white h-12 rounded-md font-medium px-14 md:w-min lg:w-min w-full md:" :class="'bt-' + classGeneral " @click="send">
            Comenzar
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainBeneficios",

  methods: {
    allData(){

      let store = JSON.parse(localStorage.getItem('data'))

      let form = {
        IdAlumno: store.user_id_actor,
        IdMatricula: store.user_matricula,
        IdUsuario: store.user_id_usuario
      }
      this.$store.dispatch("beneficiosStore/traerBeneficios",form).then(
          (response) => {
            if(response.success == true){
                console.log(response.results.lisQuery)
            }
          }
      )
    },

    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      
      let form = {
        IdAlumno: store.user_id_actor,
        IdMatricula: store.user_matricula,
        UsuarioLectura: store.user_id_usuario
      }

      this.$store.dispatch("beneficiosStore/setBeneficios",form).then(
          (response) => {
            if(response.success == true){
              this.$store.dispatch("loginStore/rutas")
            }
          }
      )
    }
  },

  created() {
    this.allData()
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  }

};
</script>
