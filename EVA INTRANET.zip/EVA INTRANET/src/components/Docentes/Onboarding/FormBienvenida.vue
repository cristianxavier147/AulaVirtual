<template>
  <section class="bg-gray-100">
    <div class="bg-gray-100">
      <!-- Content-main -->
      <div class="md:w-3/5 mx-auto pt-24">
        <img v-if="classGeneral === 'purple'" src="@/assets/onboarding/docentes/circle-purple.svg" class="ml-2 md:ml-0" />
        <img v-if="classGeneral === 'red'" src="@/assets/onboarding/docentes/circle-red.svg" class="ml-2 md:ml-0" />
        <img v-if="classGeneral === 'blue'" src="@/assets/onboarding/docentes/circle-blue.svg" class="ml-2 md:ml-0" />
        <!-- Titulos - subtitulos -->
        <div class="mx-2 text-justify md:mx-0">
          <h1 class="pt-8 text-xl font-bold md:text-3xl">
            ¡Te damos la bienvenida a EVA!
          </h1>
          <p class="mt-3 size-text-16 font-bold">
            ¡Queremos conocerte!, cuéntanos sobre ti.
          </p>
          <span class="size-text-16 font-medium text-gray-500">
            Toda la información que nos proporciones servirá para poderte brindar un servicio más personalizado.
          </span>
        </div>

        <div class="mt-5">
          <!-- Form contraseña-->
          <div class="hcaja4 bg-white mb-3 flex items-start">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/dni.svg" alt="idat" />
            </div>

            <div class="tm-r-bl w-full">
              <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                Tenemos registrado el siguiente DNI
              </div>
              
              <div class="md:flex">
                <div class="mb-5 md:mb-0 flex ml-5 h-12 mt-1 md:w-2/5">
                  <input type="text" placeholder="123456789" disabled v-model="form.dni" class="border p-3 border-gray-200 font-bold text-xs w-11/12 md:w-full" />
                </div>
              </div>
            </div>
          </div>

          <div class="hcaja1 hcaja1-confirma bg-white mb-3 flex items-start">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/user.svg" alt="idat"/>
            </div>

            <div class="tm-r-bl w-full">
              <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                Confirma tus datos
              </div>
              <!-- inputs up -->
              <div class="md:flex">
                <div class="mb-5 md:mb-0 flex ml-5 h-12  md:w-5/12">
                  <input type="text" placeholder="-" disabled class="border p-3 border-gray-200 font-bold text-xs w-11/12 md:w-full" v-model="form.first_name" />
                </div>
                <div class="mb-5 md:mb-0 flex ml-5 h-12 md:w-2/5">
                  <input type="text" placeholder="-" disabled class="border p-3 border-gray-200 font-bold text-xs w-11/12 md:w-full" v-model="form.second_name"/>
                </div>
              </div>
              <!-- inputs down -->
              <div class="md:flex mt-5">
                <div class="mb-5 md:mb-0 flex ml-5 h-12  md:w-5/12">
                  <input type="text" placeholder="Torres" disabled class="border p-3 border-gray-200 capitalize font-bold text-xs w-11/12 md:w-full" v-model="form.pat_name"/>
                </div>
                <div class="mb-4 md:mb-5 flex ml-5 h-12 md:w-2/5">
                  <input type="text" placeholder="Córdova" disabled class="border p-3 border-gray-200 capitalize font-bold text-xs w-11/12 md:w-full" v-model="form.mat_name"/>
                </div>
              </div>
            </div>
          </div>

          <div class="size-text-14 flex mb-3" v-if="classGeneral === 'red'">
            <p class="md:size-text-14 text-left" >
              En caso no sea el correcto, escríbenos a
              <a href="mailto:servicioalestudiante@zegelipae.edu.pe" :class="'text-' + classGeneral " target="_blank" class="ml-1 mr-1 underline font-bold" v-if="classGeneral === 'red'">servicioalestudiante@zegelipae.edu.pe</a>
              <span v-if="classGeneral === 'red'"> adjuntando tu DNI </span>
            </p>
          </div>
          <div class="size-text-14 mb-3" v-if="classGeneral === 'purple'">
            <p class="md:size-text-14 font-bold text-left">En el caso que tus datos no sean correctos:</p>
            <ul class="text-left mt-1 list-disc list-inside">
              <li class="block">Comunícate a nuestra central telefónica al <a href="tel:013159669" :class="'text-' + classGeneral " class="ml-1 mr-1 underline font-bold">01 315 9669</a> </li>
              <li class="block">Escríbenos por Whatsapp al <a :class="'text-' + classGeneral " class="ml-1 mr-1 underline font-bold" href="https://api.whatsapp.com/send?phone=51936750961" target="_blank">936 750 961</a></li>
              <li class="block">Accede a SAE en línea entrando a <a href="https://saeidat.zendesk.com/" class="ml-1 mr-1 underline font-bold" target="_blank" :class="'text-' + classGeneral " v-if="classGeneral === 'purple'"> saeidat.zendesk.com</a></li>
            </ul>
          </div>

          <div class="hcaja4-r hcaja4 bg-white mb-3 flex items-start">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/user.svg" alt="idat" />
            </div>

            <div class="tm-r-bl w-full">
              <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                ¿Qué nombre quieres que usemos?
              </div>
              
              <div class="size-text-14">
                <div class="md:flex ml-2">
                  <div class=" font-medium my-auto">
                    <label class="flex ml-5 size-text-14">El nombre que uso es:</label>
                  </div>
                  <div>
                    <!-- select name -->
                    <div class="flex ml-5 mt-5 md:mt-0 ">
                      <select  class=" border mr-3  font-bold md:h-10 pl-5 pr-10 py-3" v-model="form.sobreNombre" :class="classGeneral">
                        <option selected disabled value="null"></option>
                        <option v-for="(item, index) in optionsname" :key="index" :value="item">{{item}}</option>
                      </select>
                      <label class="font-bold  my-3 md:my-auto">{{form.pat_name | capitalize }} {{ form.mat_name | capitalize}}</label>
                    </div>
                  </div>
                </div>
                <div class="mt-2 text-left" v-if="this.rules.sobreNombre== true">
                  <span class="ml-5 md:ml-6 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
                </div>
              </div>
            </div>
          </div>

          <div class="md:flex md:justify-end pb-5 md:pb-0">
            <!-- botton anterior -->
            <div class="md:pt-6">
              <router-link to="/alumnos/onboarding/bienvenido">
                <button class="bg-gray-300 text-black font-medium w-11/12 md:w-40 rounded-lg h-12 my-4">
                  Anterior
                </button>
              </router-link>
            </div>
            <!-- botton siguiente -->
            <div class="md:ml-5 pt-6">
              <button class="text-white w-11/12 md:w-60 rounded-lg h-12 md:my-4" :class="'bt-' + classGeneral " @click="send()">
                Guardar y continuar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {
  name: "FormValidar",

  data() {
    return {
      form: {
        first_name: '',
        second_name: '',
        mat_name: '',
        pat_name: '',
        dni: '',
        sobreNombre: null
      },
      rules:{
        sobreNombre: false
      },
      optionsname:[],
    }
  },

  methods: {
    allData(){
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = { 
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdTipoUsuario: store.user_type_usuario,
        Login: store.user_codigo,
        IdUltimaMatricula: store.user_matricula,
        IdUnidadNegocio: store.user_unidad_negocio,
        IdUnidadAcademica: store.user_unidad_academica,
        IdModulo: store.user_id_modulo,
        IdSede: store.user_id_sede
      }

      this.$store.dispatch("onboardingStore/paso1", formData)

      this.$store.dispatch('perfilStore/getSobrenombre').then(
        (response) => {
          if(response.success == true){
            var names = store.user_name
            var arr = names.split(' ')
            var namesseconds = ''
            
            for (let i = 1; i < arr.length; i++) {
              if(namesseconds === ''){
                namesseconds = arr[i];
              }else{
                namesseconds = namesseconds + ' ' +arr[i];
              }
            }

            this.form.first_name = arr[0]
            this.form.second_name = namesseconds
            this.form.mat_name = this.changeNames(store.user_mat_name)
            this.form.pat_name = this.changeNames(store.user_pat_name)
            this.form.dni = store.user_dni
            this.form.sobreNombre = response.results.Mensaje

            var names = store.user_name
            var arr = names.split(' ')
            
            if(arr.length > 1){
              for (let i = 0; i < arr.length; i++) {
                this.optionsname.push(arr[i])
              }
            }

            this.optionsname.push(arr.join(' '))
          }
        }
      )
    },

    changeNames(value){
      return nameCursoService.palabraFiltrada(value);
    },

    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validates = this.validarCampos()

      if(validates == true){
        let form = {
          IdActor: store.user_id_actor,
          IdUsuario: store.user_id_usuario,
          sobreNombre: this.form.sobreNombre
        }
        this.$store.dispatch('perfilStore/setSobreNombre',form).then(
          (response) => {
            if(response.success == true){
              this.$router.push({ name: 'docenteContinuar' })
            }
          }
        )
      }
    },

    validarCampos(){
      if(this.form.sobreNombre === null || this.form.sobreNombre === "") {
        this.rules.sobreNombre = true
      }else{
        this.rules.sobreNombre = false
      }

      if( this.rules.sobreNombre === false) {
        return true
      }else{
        return false
      }
    },
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },

};
</script>


