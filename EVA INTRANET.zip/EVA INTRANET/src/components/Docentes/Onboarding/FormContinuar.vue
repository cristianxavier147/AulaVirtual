<template>
  <section class="bg-gray-100 size-text-14">
    <!-- Content-main -->
    <div class="md:w-3/5 mx-auto pt-24">
      <img v-if="classGeneral === 'purple'" src="@/assets/onboarding/docentes/circle2-purple.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'red'" src="@/assets/onboarding/docentes/circle2-red.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'blue'" src="@/assets/onboarding/docentes/circle2-blue.svg" class="ml-2 md:ml-0" />
      <!-- Titulos - subtitulos -->
      <div class="text-justify mx-4 md:mx-0">
        <h1 class="pt-5 font-bold size-text-30" v-if="omitir !== 3">¡Continuemos!</h1>
        <h1 class="pt-5 font-bold size-text-30" v-else>¡Ahora sí!</h1>
        <p class="size-text-16  my-4 font-bold" v-if="omitir !== 3">
          Ahora, empezaremos a crear tu nuevo perfil.
        </p>
        <p class="size-text-16  my-4 font-bold" v-else>
          Ya que cuentas con la información que te pedimos.
        </p>
        <span class="size-text-16 text-gray-500 font-medium" v-if="omitir !== 3">
          Ayúdanos completando esta información, en caso no la tengas, puedes omitir este paso para completarlo luego. <span class="font-bold text-gray-400"> Solo podrás hacer esto 2 veces. </span>
        </span>
        <span class="size-text-16 text-gray-500 font-medium" v-else>
          Ayúdanos completando esta información.
        </span>
      </div>

      <div class="mt-5 pb-8">
        <!-- Form CELLPHONE -->
        <div class="hcaja2 hcaja2-r bg-white mb-3 flex items-start">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center">
            <img src="@/assets/svg/phone.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full">
            <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Cúal es tu número de celular y mail personal?
            </h1>
            <div class="text-left ml-5">
              <!-- numero -->
              <div class="mb-5">
                <input type="number" placeholder="926654987" v-model="phone" class="border h-12 border-gray-200 font-bold p-3 " :class="this.rules.email == true ? 'border-red-600' : ''"/>
              </div>
              <!-- correo -->
              <div class="mb-5">
                <input type="text" placeholder="ejemplo@gmail.com" v-model="email" class="border h-12 border-gray-200 font-bold  p-3" :class="this.rules.phone == true ? 'border-red-600' : ''"/>
              </div>
            </div>
          </div>
        </div>

        <!-- input aceptar correo y número celular -->
        <div class="md:flex">
          <div class="flex">
            <!-- check -->
            <div>
              <input type="checkbox" class="form-checkbox ml-3 h-5 w-5 text-indigo-600 focus:ring-0 border-indigo-700" v-model="aceptar" />
            </div>

            <!-- label aceptar -->
            <div class="ml-3">
              <span class="font-bold text-gray-400 text-justify" >Acepto que mi correo personal y mi número de celular sean mostrados a mis compañeros.</span>
            </div>
          </div>
        </div>
        <div class="mt-10 md:text-right lg:text-right">
          <!-- botton anterior -->
          <span @click="omision" v-if="omitir <= 2" class="text-right font-bold border-b cursor-pointer" :class="'text-' + classGeneral + ' ; brdr-' + classGeneral">
            Omitir este paso
          </span>
          <div class="md:flex md:justify-end pb-5 md:pb-0">
            <div class="md:block">
              <router-link to="/docentes/onboarding/bienvenido">
                <button class="bg-gray-300 text-black font-medium w-11/12 md:w-40 rounded-lg h-12 my-4">
                  Anterior
                </button>
              </router-link>
            </div>

            <!-- botton siguiente -->
            <div class="md:ml-5">
              <button  class="text-white w-11/12 md:w-60 rounded-lg h-12 my-4" :class="'bt-' + classGeneral " @click="send()">
                Guardar y continuar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <ModalOmitir v-if="modal" :omitir="this.omitir" @omitir="this.redirectOmitir" @closemodal="this.closeModal()" />
    <ModalCodigo v-if="openModal" :IdProgramacionDilo="this.IdProgramacionDilo" :phone="this.phone" @closeModal="closeModalCodigo"/>
  </section>
</template>

<script>
import ModalOmitir from "@/components/Alumnos/Onboarding/Modal/ModalOmitir";
import ModalCodigo from "@/components/Alumnos/Onboarding/Modal/ModalCodigo";
export default {
  name: "FormContinuar",
  data() {
    return {
      modal: false,
      email: '',
      phone: '',
      omitir: 0,
      aceptar: false,
      rules: {
        email: false,
        phone: false
      },
      sets:{
        primerset: false,
        segundoset: false,
        tercerset: false,
      },
      openModal: false,
      IdProgramacionDilo: ''
    }
  },

  components:{
    ModalOmitir,
    ModalCodigo
  },

  methods: {
    validarCampos(){
      if(this.email === '' || this.email === null){
        this.rules.email = true
      }else{
        this.rules.email = false
      }

      if(this.phone === '' || this.phone === null){
        this.rules.phone = true
      }else{
        this.rules.phone = false
      }

      if(this.rules.email === false && this.rules.phone === false){
        return true
      }else{
        return false
      }

    },
    allData(){      
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdTipoUsuario: store.user_type_usuario,
        Login: store.user_codigo,
        IdUltimaMatricula: store.user_matricula,
        IdUnidadNegocio: store.user_unidad_negocio,
        IdUnidadAcademica: store.user_unidad_academica,
        IdModulo: store.user_id_modulo,
        IdSede: store.user_id_sede
      }

      this.$store.dispatch("onboardingStore/paso1", formData).then(
        (response) => {
        if (response.success == true) {
          var data = response.results
          this.email = data.lstUsuarioPerfilZoom[0].Email
          this.phone = data.lstUsuarioPerfilZoom[0].Telefono
          this.omitir = data.lstUsuarioPerfilZoom[0].Disponible3 == null ? 0 : parseInt(data.lstUsuarioPerfilZoom[0].Disponible3)
          this.IdProgramacionDilo = data.IdProgramacionDilo
        }
      });

    },

    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validate = this.validarCampos()
      if(validate === true){
        let form = {
          IdActor: store.user_id_actor,
          IdUsuario: store.user_id_usuario,
          IdEmail: 1,
          Email: this.email,
          Celular: this.phone,
          Tabla: 'Email',
          IdDato: this.aceptar == false ? 0 : 1,
        }

        let formCelular = {
          IdActor: store.user_id_actor,
          IdUsuario: store.user_id_usuario,
          Celular: this.phone,
        }
         //primer set de envio si es privado
        this.$store.dispatch("perfilStore/setEmail",form).then(
          (response) => {
          if (response.success == true) {
            if(this.aceptar === true){
              this.$store.dispatch("perfilStore/setEsPrivado", form).then(
                (response) => {
                if (response.success == true) {
                  this.$store.dispatch("perfilStore/setCelular",formCelular).then(
                    (response) => {
                      if (response.success == true) {
                        let formValidar = {
                          IdUsuario : store.user_id_usuario,
                          Login : store.user_codigo,
                          IdProgramacionDilo : this.IdProgramacionDilo,
                          IdTipoUsuario : store.user_type_usuario,
                          Telefono: this.phone
                        }
                        this.$store.dispatch("onboardingStore/setTelefonoValidar",formValidar).then(
                          (response) => {
                          if (response.success == true) {
                            this.openModal = true
                          }
                        });
                      }
                  });
                }
              })
            }else{
              this.$store.dispatch("perfilStore/setCelular",formCelular).then(
                (response) => {
                  if (response.success == true) {
                    let formValidar = {
                      IdUsuario : store.user_id_usuario,
                      Login : store.user_codigo,
                      IdProgramacionDilo : this.IdProgramacionDilo,
                      IdTipoUsuario : store.user_type_usuario,
                      Telefono: this.phone
                    }
                    this.$store.dispatch("onboardingStore/setTelefonoValidar",formValidar).then(
                      (response) => {
                      if (response.success == true) {
                        this.openModal = true
                      }
                    });
                  }
              });
            }
          }
        });

      }
    },

    omision(){
      if(this.omitir == 0){
        this.redirectOmitir()
      }else{
        this.modal = true
      }
    },

    redirectOmitir(){
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        Omitir: this.omitir
      }
      this.$store.dispatch("onboardingStore/omitir", formData).then(
        (response) => {
        if (response.success == true) {
          this.$router.push({ name: 'docenteFotoUsuario' })
        }
      });
    },

    closeModal(){
      this.modal = false
      this.allData()
    },

    closeModalCodigo(){
      this.openModal = false
    }
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>


