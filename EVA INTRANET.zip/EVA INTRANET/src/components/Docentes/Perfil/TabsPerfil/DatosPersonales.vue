<template>
  <div>
    <div class="py-4 mt-5 bg-white">
      <div class="">
        <img src="@/assets/perfil/docente/perfilFoto.svg" alt="perfilfoto" class="w-16 mx-5" />
      </div>

      <div class="mx-6 -mt-11">
        <h2 class="flex ml-20 text-2xl font-bold">Leiva Rojas, Alejandra Cecilia</h2>
        <div class="grid grid-cols-2 my-6 ml-20 text-sm">
          <span class="flex mb-2">Codigo de profesor: AAAA44444</span>
          <span class="flex">Profesor desde: 15 octubre 2005</span>
          <span class="flex">pedro.eduardo@idat.edu.pe</span>
          <span class="flex">Última Actualización: 05 septiembre 2018</span>
        </div>
      </div>

      <div class="flex flex-row-reverse w-full">
        <button class="p-2 mr-10 text-sm text-white bg-purple-700 w-28">Guardar</button>
        <button class="p-2 mx-4 text-sm font-bold bg-gray-200 w-28">Cancelar</button>
      </div>
    </div>
    <!-- datos personales -->
    <div class="py-5 mt-5 bg-white">
      <h2 class="flex ml-6 font-bold">Datos personales</h2>
      <div class="grid grid-cols-3 my-5 ml-6 text-sm">
        <span class="flex mb-2 font-bold">Nombres: <span class="ml-1 font-normal">Alejandra Cecilia</span> </span>
        <span class="flex mb-2 font-bold">DNI: <span class="ml-1 font-normal">70435709</span> </span>
        <span class="flex mb-2 font-bold">Número de celular: <span class="ml-1 font-normal">+51950278684</span> </span>
        <span class="flex mb-2 font-bold">Primer apellido: <span class="ml-1 font-normal">Leiva</span> </span>
        <span class="flex mb-2 font-bold">Sexo: <span class="ml-1 font-normal">Femenino</span> </span>
        <span class="flex mb-2 font-bold">Edad: <span class="ml-1 font-normal">31 años</span> </span>
        <span class="flex mb-2 font-bold">Segundo apellido: <span class="ml-1 font-normal">Rojas</span> </span>
        <span class="flex mb-2 font-bold">Correo personal: <span class="ml-1 font-normal">correo@gmail.com</span> </span>
        <span class="flex mb-2 mr-64 font-bold">Sede de Origen: </span>
      </div>

      <div class="flex flex-row-reverse w-full">
        <select class="w-2/12 p-2 text-sm mx-52">
          <option value="#">Pueblo libre</option>
        </select>
      </div>
    </div>

    <!-- Datos adicionales -->
    <div class="py-5 mt-5 bg-white">
      <h2 class="flex ml-6 font-bold">Datos adicionales</h2>
      <div class="grid grid-cols-2 my-5 ml-6 text-sm">
        <!-- ciudad residencia -->
        <div>
          <span class="flex mb-2 font-bold">. Ciudad de residencia </span>
          <input type="text" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
        <!-- NUmero de hijos -->
        <div>
          <span class="flex mb-2 font-bold">. Número de hijos </span>
          <input type="text" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
        <!-- Distrito de residencia -->
        <div class="mt-5">
          <span class="flex mb-2 font-bold">. Distrito de residencia</span>
          <input type="text" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
        <!-- menores de  12 años -->
        <div class="mt-5">
          <span class="flex mb-2 font-bold">. ¿Cuántos de sus hijos son menores de 12 años?</span>
          <input type="text" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
        <!-- Estado civil -->
        <div class="mt-5">
          <span class="flex mb-2 font-bold">. Estado civil</span>
          <select class="flex w-8/12">
            <option value="#">Soltero</option>
            <option value="#">Casado</option>
            <option value="#">viudo</option>
          </select>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DatosPersonales",
};
</script>

<style></style>
