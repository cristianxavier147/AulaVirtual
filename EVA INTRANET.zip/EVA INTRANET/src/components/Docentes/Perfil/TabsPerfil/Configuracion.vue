<template>
  <div>
    <div class="py-4 mt-5 bg-white">
      <div class="flex justify-between">
        <div>
          <h2 class="flex ml-4 text-2xl font-bold">Cambiar Contraseña</h2>
        </div>
        <div class="cursor-pointer mr-11">
          <span class="text-purple-700 underline">Editar</span>
        </div>
      </div>

      <span class="flex mt-2 ml-4 text-sm">Te recomendamos usar una contraseña segura que no uses en ningún otro sitio.</span>

      <div class="grid grid-cols-2 my-5 ml-4 text-sm">
        <!-- Actual -->
        <div>
          <span class="flex mb-2 font-bold">. Actual </span>
          <input type="password" class="flex w-8/12" />
        </div>
        <!-- Nueva contraseña -->
        <div>
          <span class="flex mb-2 font-bold">. Nueva contraseña </span>
          <input type="password" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
        <!-- repite la contraseña -->
        <div class="mt-5">
          <span class="flex mb-2 font-bold">. Repite la contraseña </span>
          <input type="password" placeholder="Escriba aquí" class="flex w-8/12" />
        </div>
      </div>
      <!-- botones -->
      <div class="flex flex-row-reverse w-full">
        <button class="p-2 mr-10 text-sm text-white bg-purple-700 w-28">Guardar</button>
        <button class="p-2 mx-4 text-sm font-bold bg-gray-200 w-28">Cancelar</button>
      </div>
    </div>
    <!-- datos personales -->
    <div class="py-5 mt-5 bg-white mb-14">
      <h2 class="flex ml-4 font-bold">Notificaciones</h2>
      <span class="flex mt-2 ml-4 text-sm">Configura las notificaciones que quieras recibir</span>
      <div class="flex mt-6 ml-4 gap-96">
        <span class="text-sm font-bold">Trámites</span>
        <span class="ml-2 text-sm font-bold">Eventos</span>
      </div>
      <div class="flex ml-4 ">
        <input type="checkbox" />
        <span class="mx-2 mt-3.5 text-sm">Alertas</span>
        <input type="checkbox" class="ml-8" />
        <span class="mx-2 mt-3.5 mr-48 text-sm">Correo electrónico</span>
        <input type="checkbox" />
        <span class="mx-2 mt-3.5 text-sm">Alertas</span>
        <input type="checkbox" class="ml-8" />
        <span class="mx-2 mt-3.5 mr-40 text-sm">Correo electrónico</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "configuracion",
};
</script>

<style></style>
