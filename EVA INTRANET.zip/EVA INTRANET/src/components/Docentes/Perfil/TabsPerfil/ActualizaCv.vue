<template>
  <div>
    <h1>Actualiza tu cv</h1>
  </div>
</template>

<script>
export default {
  name: "actualizaCv",
};
</script>

<style></style>
