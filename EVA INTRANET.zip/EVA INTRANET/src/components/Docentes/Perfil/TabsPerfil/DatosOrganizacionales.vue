<template>
  <div>
    <h1>hola Datos Organizacionales</h1>
  </div>
</template>

<script>
export default {
  name: "DatosOrganizacionales",
};
</script>

<style></style>
