<template>
    <div class="mb-2">
        <span class="size-text-14 font-normal" style="color: #7F8794" v-for="(item , index) in data" :key="index">
            <span v-if="index === data.length - 1">{{item | capitalize}}</span>
            <span v-else>{{item + ' > '}}</span>
        </span>
    </div>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {
    props:['data'],
    
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
    },
    
}
</script>