<template>
    <div>
        Reporte
    </div>
</template>