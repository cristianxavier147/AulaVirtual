<template>
    <div>
        Materiales
    </div>
</template>