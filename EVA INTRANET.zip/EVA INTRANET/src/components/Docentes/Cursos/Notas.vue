<template>
    <div>
        <div class="flex p-4 rounded-md" style="background: #EAEAEA">
            <SvgComponent svg="danger" class="mr-2"/>
            <span class="size-text-16 font-normal"> Estimado profesor, tu plazo para completar las notas es el día Lunes 16 de Noviembre. La nota final solamente se puede editar hasta 1 semana después de finalizado el ciclo. Las evaluaciones continuas hasta 2 semanas después aplicada la evaluación. </span>
        </div>
        <div class="my-7">
            <div class="grid lg:grid-cols-5 md:grid-cols-5 grid-cols-6">
                <div class="lg:col-span-2 md:col-span-2 col-span-3 text-left flex lg:justify-start md:justify-start justify-center items-center mb-5">
                    <span :class="'text-'+classGeneral" class="underline size-text-16 font-bold">Información</span>
                </div>
                <div class="lg:col-span-1 md:col-span-1 col-span-3 text-right pr-4 flex lg:justify-end md:justify-end justify-center items-center mb-5">
                    <span :class="'text-'+classGeneral" class="underline size-text-16 font-bold mr-5">Descargar</span>
                </div>
                <div class="lg:col-span-1 md:col-span-1 col-span-6 text-center mb-5 mx-5 flex justify-center items-center">
                    <button class="size-text-16 rounded-md py-2  w-full" style="background: #EAEAEA;border: 1px solid #707070">Editar nota</button>
                </div>
                <div class="lg:col-span-1 md:col-span-1 col-span-6 text-center mb-5 mx-5 flex justify-center items-center">
                    <button :class="'bt-'+classGeneral" class="size-text-16 rounded-md py-2  w-full" >Agregar nueva nota</button>
                </div>
            </div>
        </div>
        <div class="scroll-horizontal">
            <table class="size-text-14 w-full">
                <thead class="bg-white rounded-md" style="border: 1px solid #EAEAEA;color: #7F8794">
                    <tr style="height: 56px">
                        <th style="width:8%" class="text-left pl-3 pr-5 font-bold">Código</th>
                        <th style="width:25%" class="text-left font-bold">Estudiantes</th>
                        <th style="width:10%" class="text-center font-bold">Evaluación Continua (20%)</th>
                        <th style="width:10%" class="text-center font-bold">Evaluación Parcial (20%)</th>
                        <th style="width:10%" class="text-center font-bold">Evaluación Actitudinal (10%)</th>
                        <th style="width:8%" class="text-center font-bold">Evaluación Final (50%)</th>
                        <th style="width:8%" class="text-center font-bold">Promedio Final</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="height: 35px;" v-for="(item , index) in 10" :key="index">
                        <td class="text-left pr-5 font-normal pl-3">A2233</td> 
                        <td class="text-left font-normal">Geanfranco Cárdenas</td>
                        <td class="text-center font-normal">20</td>
                        <td class="text-center font-normal">20</td>
                        <td class="text-center font-normal">18</td>
                        <td class="text-center font-normal">20</td>
                        <td class="text-center font-normal">--</td>
                    </tr>
                    <tr style="height: 50px;border-top: 1px solid #7F8794">
                        <td colspan="4"></td>
                        <td colspan="2" class="size-text-16 font-bold">Promedio general</td>
                        <td colspan="1" class="size-text-16 font-normal">16.74</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
import SvgComponent from "@/components/Docentes/Svg/Svg";
export default {
    components:{
        SvgComponent
    },
    computed: {
        classGeneral(){
            return localStorage.getItem('classGeneral')
        },
        store(){
            return JSON.parse(localStorage.getItem('data'))
        },
    },
}
</script>