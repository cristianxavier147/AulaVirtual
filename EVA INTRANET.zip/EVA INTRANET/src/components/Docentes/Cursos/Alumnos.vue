<template>
  <div>
    <div class="grid md:grid-cols-5 sm:grid-cols-5 lg:grid-cols-5 xl:grid-cols-5 grid-cols-6 mb-2">
      <div class="col-span-6 pr-1 md:col-span-2 sm:col-span-2 lg:col-span-2 xl:col-span-2 mb-2">
        <div class="relative flex">
          <input type="text" name="" class="w-full bg-white  font-bold p-2.5" placeholder="Buscar" />
          <SvgComponent svg="search" class="absolute right-0 mr-2 top-3"/>
        </div>
      </div>
      <div class="col-span-3 pl-1 md:col-span-1 sm:col-span-1 lg:col-span-1 xl:col-span-1">
        <div class="relative flex">
          <input type="text" name="" disabled placeholder="A - Z" class="w-full bg-white  font-bold p-2.5" />
          <SvgComponent svg="orden" class="absolute right-0 mr-2 cursor-pointer top-3"/>
        </div>
      </div>
      <div class="col-span-3 pl-1 md:col-span-2 sm:col-span-2 lg:col-span-2 xl:col-span-2 flex justify-end items-center">
        <span class="underline size-text-16 font-bold pr-3" :class="'text-'+classGeneral">Descargar lista</span>
      </div>
    </div>
    <div class="my-7">
      <div class="block md:flex lg:flex justify-start items-center text-center">
        <span class="size-text-20 font-semibold md:mr-10 lg:mr-110 ml-1">Número de participantes: 28</span>
        <button :class="'bt-'+classGeneral" class="py-3 px-4 w-full lg:w-auto md:w-auto mt-1">Enviar mensaje</button>
      </div>
    </div>
    <div class="grid grid-cols-3">
      <div class="md:col-span-1 lg:col-span-1 col-span-3 mb-5 md:mr-2 lg:mr-2 mr-0" v-for="(item, index) in 9" :key="index">
        <div class="rounded-md bg-white p-7 px-4" style="border: 1px solid #EAEAEA">
          <div class="relative">
            <div class="flex w-full justify-start items-center">
              <img src="@/assets/avatar/avatar.png" alt="" class="mr-3" style="width:80px ; height:80px">
              <span class="size-text-16 font-bold">Jackelyn <br> Gutierrez Haupaya</span>
            </div>
            <span class="size-text-14 font-normal absolute -top-3 right-0 bg-black text-white rounded-2xl px-3 py-1" v-if="index === 0">Delegado</span>
            <span class="size-text-14 font-normal absolute -top-3 right-0 bg-black text-white rounded-2xl px-3 py-1" v-if="index === 1">Monitor</span>
          </div>
          <div class="flex justify-center items-center my-4">
            <SvgComponent svg="email" class="mr-3"/>
            <span class="size-text-14 font-normal">jackelyngutierrez@pachaqtec.edu.pe</span>
          </div>
          <div class="text-center">
            <span :class="'text-'+classGeneral" class="size-text-16 font-bold underline">Ver historial de notas y asistencia</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SvgComponent from "@/components/Docentes/Svg/Svg";
export default {
  components: {
    SvgComponent
  },
  computed: {
    classGeneral(){
        return localStorage.getItem('classGeneral')
    },
  },
}
</script>