<template>
    <div>
      <div class="relative my-5 md:text-left lg:text-left text-center">
          <span class="size-text-20 font-semibold"> Historial de asistencia </span>
          <span :class="'text-'+classGeneral" class="underline size-text-16 font-bold md:absolute lg:absolute inline-block right-0">Descargar historial</span>
      </div>
      <div class="bg-white px-5 py-6 rounded-md" style="border: 1px solid #EAEAEA">
        <div class="relative mb-5 text-center">
          <div class="flex">
            <span class="flex size-text-16 font-normal mr-5">
              <div class="mr-2 a-p"></div>
              Presente
            </span>
            <span class="flex size-text-16 font-normal mr-5">
              <div class="mr-2 a-t"></div>
              Tarde
            </span>
            <span class="flex size-text-16 font-normal">
              <div class="mr-2 a-f"></div>
              Falta
            </span>
          </div>
          <div class="md:absolute lg:absolute inline-block right-0 top-0">
            <div class="flex">
              <div class="-mt-1.5 ml-8 md:flex lg:flex hidden">
                <SvgComponent svg="prevArrow" @scroll="this.scroll"/>
                <SvgComponent svg="nextArrow" @scroll="this.scroll"/>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div class="grid md:grid-cols-5 lg:grid-cols-5 grid-cols-6">
            <div class="md:col-span-1 lg:col-span-1 col-span-3">
              <div class="td-content">
                <span class="size-text-20 font-semibold">Profesor</span>
              </div>
              <div class="td-content">
                <span class="size-text-14 font-normal">Javier Rubio</span>
              </div>
              <div class="td-content">
                <span class="size-text-20 font-semibold">Estudiantes</span>
              </div>
              <div>
                <ul>
                  <li class="td-e size-text-14 font-normal" v-for="(item , index) in 30" :key="index">{{'Estudiante ' + item}}</li>
                </ul>
              </div>
            </div>
            <div class="md:col-span-4 lg:col-span-4 col-span-3 flex overflow-auto" id="con">
              <div :class="index === 0 ? classGeneral + ' active' : ''" class="cont-day" v-for="(item , index) in 30" :key="index">
                <div class="px-3">
                  <div class="td-content fc">
                    <span class="size-text-14 font-bold text-center">
                      Lunes
                      <br>
                      {{item+'/01/2021'}}
                    </span>
                  </div>
                  <div class="td-content fc">
                    <div class="a-p" v-if="item === 1"></div>
                    <div class="a-p" v-else-if="item === 2"></div>
                    <div class="a-p" v-else-if="item === 3"></div>
                    <div class="a-s" v-else></div>
                  </div>
                  <div class="td-content">
                  </div>
                  <div>
                    <ul v-if="item === 1">
                      <li class="td-e size-text-14 font-normal flex justify-center items-center" v-for="(item , i) in 30" :key="i*100">
                        <div class="a-p" ></div>
                      </li>
                    </ul>
                    <ul v-else-if="item === 2">
                      <li class="td-e size-text-14 font-normal flex justify-center items-center" v-for="(item , i) in 30" :key="i*100">
                        <div class="a-t" ></div>
                      </li>
                    </ul>
                    <ul v-else-if="item === 3">
                      <li class="td-e size-text-14 font-normal flex justify-center items-center" v-for="(item , i) in 30" :key="i*100">
                        <div class="a-f" ></div>
                      </li>
                    </ul>
                    <ul v-else>
                      <li class="td-e size-text-14 font-normal flex justify-center items-center" v-for="(item , i) in 30" :key="i*100">
                        <div class="a-s" ></div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
import SvgComponent from "@/components/Docentes/Svg/Svg";
export default {
  data() {
    return {
      scrollDiv : 0
    }
  },
  components:{
    SvgComponent
  },
  methods: {
    scroll(type){
      const tm = 96*(30 - 8)
      const el = document.getElementById('con')
      if(type === 2){
        if(this.scrollDiv < tm + 1){
          this.scrollDiv = 96 + this.scrollDiv
          el.scrollTo(this.scrollDiv,100)
        }
      }else{
        if(this.scrollDiv > 0){
          this.scrollDiv = this.scrollDiv - 96
          el.scrollTo(this.scrollDiv,100)
        }
      }
    }
  },
  computed: {
    classGeneral(){
        return localStorage.getItem('classGeneral')
    },
    store(){
        return JSON.parse(localStorage.getItem('data'))
    },
  },
}
</script>