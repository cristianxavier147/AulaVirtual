<template>
    <div>
        <svg v-if="svg === 'openTab'" width="24" height="24" viewBox="0 0 24 24">
            <g id="arrow-ios-downward">
                <rect id="Rectángulo_5123" data-name="Rectángulo 5123" width="24" height="24" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" opacity="0"/>
                <path id="Trazado_16854" data-name="Trazado 16854" d="M12,9a1,1,0,0,0-.64.23l-6,5a1,1,0,0,0,1.28,1.54L12,11.291l5.36,4.32A1.025,1.025,0,1,0,18.63,14l-6-4.83A1,1,0,0,0,12,9Z" transform="translate(0 -1.001)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
            </g>
        </svg>
        <svg v-if="svg === 'closeTab'" width="24" height="24" viewBox="0 0 24 24">
            <g id="arrow-ios-downward">
                <rect id="Rectángulo_5123" data-name="Rectángulo 5123" width="24" height="24" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" opacity="0"/>
                <path id="Trazado_16854" data-name="Trazado 16854" d="M12,16a1,1,0,0,1-.64-.23l-6-5A1,1,0,0,1,6.64,9.23L12,13.71l5.36-4.32A1.025,1.025,0,1,1,18.63,11l-6,4.83A1,1,0,0,1,12,16Z" transform="translate(0 0)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
            </g>
        </svg>
        <svg v-if="svg === 'retroBlack'" id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" >
            <g id="arrow-back">
                <rect id="Rectángulo_5114" data-name="Rectángulo 5114" width="32" height="32" transform="translate(32) rotate(90)" opacity="0"/>
                <path id="Trazado_16841" data-name="Trazado 16841" d="M26.5,14.429H8.71l5.445-6.851a1.625,1.625,0,0,0-.195-2.216,1.456,1.456,0,0,0-2.115.2l-7.5,9.428a1.89,1.89,0,0,0-.135.236.2.2,0,0,1-.105.2,1.576,1.576,0,0,0,0,1.131.2.2,0,0,0,.105.2,1.89,1.89,0,0,0,.135.236l7.5,9.428a1.459,1.459,0,0,0,2.115.2,1.6,1.6,0,0,0,.536-1.065,1.622,1.622,0,0,0-.341-1.15L8.71,17.572H26.5a1.573,1.573,0,0,0,0-3.143Z" transform="translate(0)"/>
            </g>
        </svg>
        <svg v-if="svg === 'prevArrow'" id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" @click="scroll(1)">
            <g id="arrow-ios-back">
            <rect id="Rectángulo_5122" data-name="Rectángulo 5122" width="32" height="32" transform="translate(32) rotate(90)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" opacity="0"/>
            <path id="Trazado_16853" data-name="Trazado 16853" d="M15.805,23.738a1.338,1.338,0,0,1-1.044-.5L8.3,15.213a1.338,1.338,0,0,1,0-1.7l6.692-8.03A1.34,1.34,0,0,1,17.05,7.2l-5.983,7.174,5.782,7.174a1.338,1.338,0,0,1-1.044,2.195Z" transform="translate(2.705 1.692)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
            </g>
        </svg>
        <svg v-if="svg === 'nextArrow'" id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" @click="scroll(2)">
            <g id="arrow-ios-forward">
            <rect id="Rectángulo_5124" data-name="Rectángulo 5124" width="32" height="32" transform="translate(0 32) rotate(-90)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" opacity="0"/>
            <path id="Trazado_16855" data-name="Trazado 16855" d="M10.334,23.676A1.333,1.333,0,0,1,9.307,21.49l5.973-7.147-5.76-7.16A1.363,1.363,0,1,1,11.667,5.5l6.44,8a1.333,1.333,0,0,1,0,1.693l-6.667,8A1.333,1.333,0,0,1,10.334,23.676Z" transform="translate(2.999 1.657)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
            </g>
        </svg>
        <svg v-if="svg === 'danger'" id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" width="60" height="24" viewBox="0 0 24 24">
            <g id="alert-triangle">
                <rect id="Rectángulo_5111" data-name="Rectángulo 5111" width="24" height="24" transform="translate(24) rotate(90)" opacity="0"/>
                <path id="Trazado_16838" data-name="Trazado 16838" d="M22.56,16.3,14.89,3.58a3.43,3.43,0,0,0-5.78,0L1.44,16.3a3,3,0,0,0-.05,3A3.37,3.37,0,0,0,4.33,21H19.67a3.37,3.37,0,0,0,2.94-1.66,3,3,0,0,0-.05-3.04Zm-1.7,2.05a1.31,1.31,0,0,1-1.19.65H4.33a1.31,1.31,0,0,1-1.19-.65,1,1,0,0,1,0-1L10.82,4.62a1.48,1.48,0,0,1,2.36,0l7.67,12.72a1,1,0,0,1,.01,1.01Z"/>
                <circle id="Elipse_2" data-name="Elipse 2" cx="1" cy="1" r="1" transform="translate(11 15)"/>
                <path id="Trazado_16839" data-name="Trazado 16839" d="M12,8a1,1,0,0,0-1,1v4a1,1,0,0,0,2,0V9A1,1,0,0,0,12,8Z"/>
            </g>
        </svg>
        <svg v-if="svg === 'search'" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" >
            <path id="Trazado_4792" data-name="Trazado 4792" d="M163.161,781.488,159,777.313a8.534,8.534,0,0,0,1.745-5.171c.163-4.6-3.7-8.473-8.648-8.642-4.9.167-8.764,4.043-8.6,8.6-.163,4.6,3.7,8.473,8.628,8.641a8.608,8.608,0,0,0,5.168-1.718l4.089,4.107a1.262,1.262,0,0,0,.891.37,1.238,1.238,0,0,0,.876-.365A1.168,1.168,0,0,0,163.161,781.488ZM145.945,772.1a6.247,6.247,0,1,1,0,.04v-.04Z" transform="translate(-143.496 -763.5)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
        </svg>
        <svg v-if="svg === 'orden'" xmlns="http://www.w3.org/2000/svg" width="18.432" height="20" viewBox="0 0 18.432 20" >
            <g id="Grupo_8195" data-name="Grupo 8195" transform="translate(-198.294 28.707)">
              <g id="Grupo_8194" data-name="Grupo 8194" transform="translate(216.726 -20.828) rotate(90)">
                <g id="Grupo_225" data-name="Grupo 225">
                  <path id="Trazado_67" data-name="Trazado 67" d="M11.9,4.74,7.313.217A.754.754,0,0,0,6.255,1.29L9.53,4.523H.754a.754.754,0,1,0,0,1.508H9.53L6.255,9.263a.754.754,0,1,0,1.058,1.073L11.9,5.813a.753.753,0,0,0,0-1.073Z" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                </g>
              </g>
              <g id="Grupo_8193" data-name="Grupo 8193" transform="translate(198.294 -16.586) rotate(-90)">
                <g id="Grupo_225-2" data-name="Grupo 225">
                  <path id="Trazado_67-2" data-name="Trazado 67" d="M11.9,4.74,7.313.217A.754.754,0,0,0,6.255,1.29L9.53,4.523H.754a.754.754,0,1,0,0,1.508H9.53L6.255,9.263a.754.754,0,1,0,1.058,1.073L11.9,5.813a.753.753,0,0,0,0-1.073Z" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                </g>
              </g>
            </g>
        </svg>
        <svg v-if="svg === 'email'" id="email" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <rect id="Rectángulo_5205" data-name="Rectángulo 5205" width="24" height="24" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" opacity="0"/>
            <path id="Trazado_16986" data-name="Trazado 16986" d="M19,4H5A3,3,0,0,0,2,7V17a3,3,0,0,0,3,3H19a3,3,0,0,0,3-3V7a3,3,0,0,0-3-3Zm-.67,2L12,10.75,5.67,6ZM19,18H5a1,1,0,0,1-1-1V7.25l7.4,5.55a1,1,0,0,0,1.2,0L20,7.25V17A1,1,0,0,1,19,18Z" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
        </svg>

    </div>
</template>

<script>
export default {
    props: {
        svg: String
    },

    computed: {
        classGeneral(){
            return localStorage.getItem('classGeneral')
        },
    },
    methods: {
        scroll(type){
            this.$emit('scroll', type)
        }
    },
}
</script>