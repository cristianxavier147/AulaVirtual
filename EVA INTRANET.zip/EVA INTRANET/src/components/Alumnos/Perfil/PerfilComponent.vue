<template>
  <div>
    <div class="overlay modal-perfil">
      <div class="h-full overflow-y-scroll bg-gray-100 modal-perfil-content modal md:relative md:mt-0 " style="width: 491px">
        <div class="flex items-center h-16 bg-white shadow-md md:bg-black">
          <div class="grid w-full grid-cols-2">
            <div class="flex col-span-1 pl-5 text-left md:pl-10 lg:pl-10">
              <!-- flecha izquierda blanco-->
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17.413" viewBox="0 0 20 17.413" @click="close" class="md:block hidden cursor-pointer my-1.5 mx-3">
                <g id="Grupo_3896" data-name="Grupo 3896" transform="translate(20 17.413) rotate(180)">
                  <g id="Grupo_225" data-name="Grupo 225">
                    <path id="Trazado_67" data-name="Trazado 67" d="M189.729,114.985l-7.562-7.463a1.244,1.244,0,0,0-1.746,1.771l5.4,5.333H171.344a1.244,1.244,0,1,0,0,2.488h14.481l-5.4,5.333a1.244,1.244,0,1,0,1.746,1.771l7.562-7.463a1.243,1.243,0,0,0,0-1.771Z" transform="translate(-170.1 -107.165)" fill="#fff" />
                  </g>
                </g>
              </svg>

              <!-- flecha izquierda morado -->
              <svg xmlns="http://www.w3.org/2000/svg" width="17.797" height="15.495" viewBox="0 0 17.797 15.495" @click="close" class="md:hidden block cursor-pointer my-1.5 mx-3">
                <g id="Grupo_21220" data-name="Grupo 21220" transform="translate(17.797 15.495) rotate(180)">
                  <path id="Trazado_67" data-name="Trazado 67" d="M187.567,114.124l-6.729-6.641a1.107,1.107,0,0,0-1.554,1.576l4.809,4.746H171.207a1.107,1.107,0,1,0,0,2.214h12.886l-4.809,4.746a1.107,1.107,0,1,0,1.554,1.576l6.729-6.641a1.106,1.106,0,0,0,0-1.576Z" transform="translate(-170.1 -107.165)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" />
                </g>
              </svg>

              <span class="mt-1 font-extrabold text-justify md:text-white md:text-left" @click="close">{{ title }}</span>
            </div>
            <div class="flex items-center justify-center col-span-1 pl-4">
              <img src="@/assets/svg/logout.svg" alt="accesso" class="hidden mr-2 md:block lg:block" />
              <svg class="block mr-2 md:hidden lg:hidden" xmlns="http://www.w3.org/2000/svg" width="20.845" height="19.939" viewBox="0 0 20.845 19.939">
                <g id="logout" transform="translate(0 -0.332)">
                  <path id="Trazado_17172" data-name="Trazado 17172" d="M163.153,220.359H150.012a.68.68,0,1,1,0-1.359h13.142a.68.68,0,0,1,0,1.359Zm0,0" transform="translate(-142.988 -209.378)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" />
                  <path id="Trazado_17173" data-name="Trazado 17173" d="M153.645,142.263a.674.674,0,0,1-.48-.2l-3.625-3.625a.68.68,0,0,1,0-.962l3.625-3.625a.68.68,0,0,1,.962.962l-3.145,3.145,3.145,3.145a.679.679,0,0,1-.481,1.16Zm0,0" transform="translate(-142.995 -127.656)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" />
                  <path id="Trazado_17174" data-name="Trazado 17174" d="M9.969,20.271A9.969,9.969,0,1,1,19.248,6.655a.68.68,0,1,1-1.265.5,8.61,8.61,0,1,0,0,6.3.68.68,0,1,1,1.265.5A9.919,9.919,0,0,1,9.969,20.271Zm0,0" transform="translate(0)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'" />
                </g>
              </svg>
              <span class="font-bold cursor-pointer size-text-12 md:text" :class="'text-' + classGeneral + ' md:text-white lg:text-white'" @click="logout">Cerrar sesión</span>
            </div>
          </div>
        </div>
        <div class="p-3" v-if="this.validate === true && parseInt(store.user_type_usuario) === 1">
          <div class="mb-4">
            <slot></slot>
          </div>
          <div class="px-5">
            <a v-if="classGeneral === 'purple'" href="http://smart.idat.edu.pe/Reglamentos/Reglamento_Institucional.pdf" target="_blank" class="block mb-1 text-sm font-bold underline" :class="'text-' + classGeneral">Descarga el reglamento académico aquí</a>
            <a v-if="classGeneral === 'red'" href="http://smart.zegelipae.edu.pe/Reglamentos/reglamento_ipae.pdf" target="_blank" class="block mb-1 text-sm font-bold underline" :class="'text-' + classGeneral">Descarga el reglamento académico de carreras aquí</a>
            <a v-if="classGeneral === 'red'" href="http://smart.zegelipae.edu.pe/Reglamentos/Reglamento_EE_2020_final.pdf" target="_blank" class="block mb-1 text-sm font-bold underline" :class="'text-' + classGeneral">Descarga el reglamento académico de educación ejecutiva aquí</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { sessionService } from "@/mixins/session";
export default {
  name: "PerfilComponent",
  props: {
    title: {
      type: String,
      required: true,
    },
  },

  data() {
    return {
      validate: true,
    };
  },

  methods: {
    close() {
      this.$emit("toggle-modal");
    },
    logout() {
      sessionService.removeSession();
      setTimeout(() => {
        this.$router.push({ name: "login" }).catch(() => {});
      }, 400);
    },
    validarContent() {
      let route = this.$route.path;
      var arr = route.split("/");
      if (arr[1] === "onboarding") {
        this.validate = false;
      }
    },
  },

  created() {
    this.validarContent();
  },

  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },
};
</script>
