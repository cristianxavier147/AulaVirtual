<template>
  <div class="my-2 md:px-7 md:py-3">
    <div class="overflow-auto size-text-12 font-bold md:gap-2 text-gray-400">
      <div class="w-max flex">
        <!-- <div @click="openTab('sobreMi')" :class="active == 'sobreMi' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="mx-2 cursor-pointer max-w-lg">
          <span class="block" :class="active == 'sobreMi' ? 'text-' + classGeneral + '-600' : ''">Acerca de mí</span>
        </div> -->
        <div @click="openTab('actualizarDatos')" :class="active == 'actualizarDatos' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="mx-2 cursor-pointer max-w-lg">
          <span class="block " :class="active == 'actualizarDatos' ? 'text-' + classGeneral + '-600' : ''">Actualizar datos</span>
        </div>
        <div @click="openTab('cambiarPassword')" :class="active == 'cambiarPassword' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="mx-2 cursor-pointer max-w-lg">
          <span class="block " :class="active == 'cambiarPassword' ? 'text-' + classGeneral + '-600' : ''">Cambiar contraseña</span>
        </div>
        <div id="avanceCurricular" @click="openTab('avanceCurricular')" :class="active == 'avanceCurricular' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="mx-2 cursor-pointer max-w-lg">
          <span class="block " :class="active == 'avanceCurricular' ? 'text-' + classGeneral + '-600' : ''">Avance curricular</span>
        </div>
      </div>
    </div>
    <SobreMi v-if="active == 'sobreMi'" />
    <ActualizarDatos v-if="active == 'actualizarDatos'"  :data="this.data"/>
    <CambiarPassword v-if="active == 'cambiarPassword'" />
    <AvanceCurricular v-if="active == 'avanceCurricular'" />
  </div>
</template>

<script>
import SobreMi from "@/components/Alumnos/Perfil/SeccionesPerfil/SobreMi";
import ActualizarDatos from "@/components/Alumnos/Perfil/SeccionesPerfil/ActualizarDatos";
import CambiarPassword from "@/components/Alumnos/Perfil/SeccionesPerfil/CambiarPassword";
import AvanceCurricular from "@/components/Alumnos/Perfil/SeccionesPerfil/AvanceCurricular";

export default {
  props: ['data'],

  components: {
    SobreMi,
    ActualizarDatos,
    CambiarPassword,
    AvanceCurricular,
  },

  data() {
    return {
      active: "actualizarDatos",
    };
  },

  methods: {
    openTab(item) {
      this.active = item
    },
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style type="text/scss"></style>
