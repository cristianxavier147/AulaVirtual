<template>
  <div>
    <div class="py-1 mt-5 text-xs bg-white rounded-md">
      <form>
        <div class="mx-5 my-5">
          <div class="text-left relative">
            <input type="password" placeholder="Contraseña Actual" class="w-full h-10 p-2 border mb-3" v-model="password"/>
            <span class="absolute left-0 -bottom-1 text-red-700 block size-text-10 font-bold" v-if="passwordIncorrecto">* Contraseña incorrecta</span>
            <span class="text-red size-text-10 font-bold absolute left-0 -bottom-1" v-if="this.rules.password == true">* Este campo es obligatorio </span>
          </div>
          <div class="text-left mb-3 mt-1 ml-1">
            <span class="size-text-12 font-bold">Por seguridad , asegúrate de incluir una mayúscula y un número</span>  
          </div>
          <div class="text-left relative">
            <input type="password" placeholder="Nueva Contraseña" v-model="passwordnew" @keyup="validateFormat" class="w-full h-10 p-2 mb-3 border" />
            <span class="absolute left-0 -bottom-4 text-red-700 block size-text-10 font-bold" v-if="passwordnotrules">* La contraseña no cumple con los criterios necesarios.</span>
            <span class="mt-1 text-red size-text-10 font-bold absolute left-0 -bottom-1" v-if="this.rules.passwordnew == true">* Este campo es obligatorio </span>
          </div>
          <br />
          <div class="text-left relative">
            <input type="password" placeholder="Confirmar nueva contraseña" v-model="passwordnewr" class="w-full h-10 p-2 border mb-3" />
            <span class="absolute left-0 -bottom-4 text-red-700 block size-text-10 font-bold"  v-if="passwordnotisame">* Las contraseñas no coinciden.</span>
            <span class="mt-1 text-red size-text-10 font-bold absolute left-0 -bottom-1" v-if="this.rules.passwordnewr == true">* Este campo es obligatorio </span>
          </div>
        </div>
      </form>
    </div>
    <button class="w-full h-12 mt-5 text-white" :class="'bt-' + classGeneral " @click="send">Cambiar</button>
    <CambioContrasena v-if="openModal" @closeModal="closeModal" />
  </div>
</template>

<script>
import CambioContrasena from "@/components/Alertas/CambioContrasena";
export default {
  name: "CambiarPassword",

  data() {
    return {
      password: '',
      passwordnew: '',
      passwordnewr: '',
      rules:{
        password: false,
        passwordnew: false,
        passwordnewr: false,
      },
      passwordnotisame: false,
      passwordnotrules: false,
      passworderror: false,
      passwordIncorrecto: false,
      openModal:false
    }
  },

  components: {
    CambioContrasena
  },

  methods: {
    validarCampos(){
      if(this.password === null || this.password === "") {
        this.rules.password = true
      }else{
        this.rules.password = false
      }

      if(this.passwordnew === null || this.passwordnew === "") {
        this.rules.passwordnew = true
      }else{
        this.rules.passwordnew = false
      }

      if(this.passwordnewr === null || this.passwordnewr === "") {
        this.rules.passwordnewr = true
      }else{
        this.rules.passwordnewr = false
      }

      if( this.rules.password === false && this.rules.passwordnew === false && this.rules.passwordnewr === false) {
        return true
      }else{
        return false
      }
    },
    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validate = this.validarCampos()
      if(validate === true){
        var valid = this.validatePaswoord()
        if(this.passworderror === false && this.passwordnotrules === false && this.passwordnotisame === false) {
          var formP = {
            username: store.user_codigo,
            password: this.password
          }
          this.$store.dispatch("loginStore/verificacontrasenia",formP).then(
            (response) => {
              if(response.success == true){
                this.passwordIncorrecto = false

                  var form = {
                    username: store.user_codigo,
                    password: this.passwordnew
                  }
                  this.$store.dispatch("loginStore/changePasswordMethod",form).then(
                      (response) => {
                        if(response.success == true){
                            this.openModal = true
                        }
                      }
                  )
              }else{
                this.passwordIncorrecto = true
              }
            }
          )
        }
      }
    },
    validatePaswoord(){
      if(this.passwordnew == "" && this.passwordnewr == ""){
        this.passworderror = true
      }else{
        this.passworderror = false
        if(this.passwordnew !== this.passwordnewr){
          this.passwordnotisame = true
        }else{
          this.passwordnotisame = false
        }
      }
    },
    validateFormat(){
      var txt = this.passwordnew
      var cant = txt.length
      var min = /[a-z]/.test(txt)
      var may = /[A-Z]/.test(txt)
      var num = /[0-9]/.test(txt)

      if(txt < 8) return 

      if(!min) return this.passwordnotrules = true

      if(!may) return this.passwordnotrules = true

      if(!num) return this.passwordnotrules = true

      this.passwordnotrules = false

    },
    closeModal(){
      this.openModal = false
    }
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
