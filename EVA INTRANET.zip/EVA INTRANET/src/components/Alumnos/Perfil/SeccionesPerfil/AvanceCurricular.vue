<template>
  <div style="height: 40px">
    <router-link class="flex" to="/alumnos/cursos/avance-curricular" exact>
      <a target="_blank" class="flex items-center justify-center w-full mt-3 text-white rounded-md" style="height: 40px" :class="'bt-' + classGeneral" @click="close">
        Ir a avance curricular
      </a>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "AvanceCurricular",
  methods: {
    close() {
      this.$emit("toggle-modal");
    },
  },
  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },

    linkac() {
      return localStorage.getItem("linkac");
    },
  },
};
</script>

<style lang="stylus" scoped></style>
