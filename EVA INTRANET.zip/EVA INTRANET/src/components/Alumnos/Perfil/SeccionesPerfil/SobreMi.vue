<template>
  <div class="mt-8">
    <div class="p-4 pt-6 text-sm bg-white">
      <textarea :placeholder="classGeneral === 'purple' ? 'Cuando acabe mis estudios en Idat' : 'Cuando acabe mis estudios en Zegel Ipae' + ', quisiera...'" class="w-11/12 p-2 border md:h-40 h-28" v-model="expectativas"></textarea>
    </div>
    <button class="w-full h-12 mt-5 text-white" :class="'bt-' + classGeneral " @click="save">Guardar</button>
    <SobreMiModal v-if="openModal" @closeModal="closeModal" />
  </div>
</template>

<script>
import SobreMiModal from "@/components/Alertas/SobreMiModal";
export default {
  name: "SobreMi",
  data() {
    return {
      expectativas: '',
      openModal: false
    }
  },

  components: {
    SobreMiModal
  },

  methods: {
    allData(){
      this.$store.dispatch("perfilStore/getExpectativa").then(
        (response) => {
        if (response.success == true) {
          if(response.results.Mensaje == ""){
            this.expectativas = ""
          }else{
            var data = response.results.Mensaje
            this.expectativas = data
          }
        }
      });
    },

    save(){
      let store = JSON.parse(localStorage.getItem('data'))
      let formExpectativa = {
        IdUsuario: store.user_id_usuario,
        IdActor: store.user_id_actor,
        Expectativas: this.expectativas
      }
        
      this.$store.dispatch("perfilStore/setExpectatica",formExpectativa).then(
        (response) => {
        if (response.success == true) {
          this.openModal = true
        }
      });
    },

    closeModal(){
      this.openModal = false
      this.allData()
    }
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style lang="stylus" scoped></style>
