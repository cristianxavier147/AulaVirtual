<template>
  <div>
    <div class="pb-2 mt-4 text-xs bg-white rounded-md">
      <form>
        <div class="flex justify-between py-3 ml-5 mr-5 border-b-2">
          <span class="font-bold">Datos personales</span>
        </div>
        <!-- inputs -->
        <div class="mx-5 mt-4">
          <div class="relative">
            <input type="numer" placeholder="123456789" disabled class="w-full h-10 p-2 text-gray-400 border" v-model="telefono" />
            <!-- <img src="@/assets/global/lapizperfil.svg" alt="accesso" class="absolute right-3 top-3" /> -->
          </div>
          <input type="text" placeholder="Correo Personal" class="w-full h-10 p-2 mt-3  border" v-model="email"/>
          <div class="grid grid-cols-2 grid-rows-2 gap-2 mt-4 mb-4">
            <input type="text" placeholder="Dirección" class="h-10 p-2 border" v-model="direccion" />
            <select :class="classGeneral" class=" h-10 p-2 border" v-model="region" @change="sendUbigeos(1)">
              <option v-for="(region , index) in regiones" :key="index" :value="region.IdDepartamento" >{{region.Nombre}}</option>
            </select>
            <select :class="classGeneral" class=" h-10 p-2 border" v-model="provincia" @change="sendUbigeos(2)">
              <option v-for="(region , index) in provincias" :key="index" :value="region.IdProvincia" >{{region.Nombre}}</option>
            </select>
            <select :class="classGeneral" class=" h-10 p-2 border" v-model="distrito">
              <option v-for="(region , index) in distritos" :key="index" :value="region.IdDistrito" >{{region.Nombre}}</option>
            </select>
          </div>
        </div>
      </form>
    </div>
    <button class="w-full h-12 mt-3 text-white" :class="'bt-' + classGeneral " @click="send">
      Actualizar
    </button>
    <CambioDireccionEmail v-if="openModal" @closeModal="closeModal" />
  </div>
</template>

<script>
import CambioDireccionEmail from "@/components/Alertas/CambioDireccionEmail";
export default {
  props: ['data'],

  data() {
    return {
      telefono: '',
      email: '',
      direccion: '',
      ubigeo: '',
      region: '',
      provincia: '',
      distrito: '',
      regiones: [],
      provincias: [],
      distritos: [],
      name: '',
      openModal:false
    }
  },

  components: {
    CambioDireccionEmail
  },

  name: "ActualizarDatos",

  mounted() {
    this.data.Contacto.map(vl => {
      if(vl.IdDato == 1 && vl.Tipo == 1){
        this.email = vl.Descripcion
      }else if(vl.IdDato == 1 && vl.Tipo == 2){
        this.telefono = vl.Descripcion
      }
    })
  },

  methods: {
    allData(){
      this.$store.dispatch("perfilStore/getDireccion").then(
        (response) => {
        if (response.success == true) {
          this.direccion = response.results.Direccion[0].NombreVia
          this.ubigeo = response.results.Direccion[0].UbigeoCodigo
          this.orderUbigeo(response.results.Direccion[0].UbigeoCodigo)
        }
      });
    },

    orderUbigeo(value){
      this.region = value.substr(0,2)
      this.provincia = value.substr(2,2)
      this.distrito = value.substr(4,2)

      let formData = {
        CodDepartamento : this.region,
        CodProvincia: this.provincia
      }

      this.$store.dispatch("perfilStore/getUbigeo",formData).then(
        (response) => {
        if (response.success == true) {
          this.regiones = response.results.lstDepartamento
          this.provincias = response.results.lstProvincia
          this.distritos = response.results.lstDistrito
        }
      });
    },

    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      let ubigeo = this.region+this.provincia+this.distrito

      this.distritos.map(vl => {
        if(vl.Codigo === ubigeo){
          this.name = vl.NombreUnido
        }
      })

      let form = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdEmail: 1,
        Email: this.email,
        Tabla: 'Email',
      }

      let formUbigeo = {
        IdActor : store.user_id_actor,
        NombreVia : this.direccion,
        Ubigeo : ubigeo,
        CiudadResidencia : this.name,
        Login : store.user_codigo
      }

      this.$store.dispatch("perfilStore/setEmail",form).then(
        (response) => {
        if (response.success == true) {
          this.$store.dispatch("perfilStore/setDireccion",formUbigeo).then(
            (response) => {
            if (response.success == true) {
              this.openModal = true
            }
          }); 
        }
      });
    },

    closeModal(){
      this.openModal = false
    },

    sendUbigeos(type){
      if(type === 1){
        this.provincia = ''
        this.provincias = []
        this.distrito = ''
        this.distritos = []

        let formData = {
          CodDepartamento : this.region,
          CodProvincia: this.provincia
        }

        this.$store.dispatch("perfilStore/getUbigeo",formData).then(
          (response) => {
          if (response.success == true) {
            this.regiones = response.results.lstDepartamento
            this.provincias = response.results.lstProvincia
            this.distritos = response.results.lstDistrito
          }
        });
      }else if(type === 2){
        this.distrito = ''
        this.distritos = []

        let formData = {
          CodDepartamento : this.region,
          CodProvincia: this.provincia
        }

        this.$store.dispatch("perfilStore/getUbigeo",formData).then(
          (response) => {
          if (response.success == true) {
            this.regiones = response.results.lstDepartamento
            this.provincias = response.results.lstProvincia
            this.distritos = response.results.lstDistrito
          }
        });
      }
    }
  },

  created() {
    this.allData()
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style lang="stylus" scoped></style>
