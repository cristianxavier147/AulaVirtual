<template>
<div>
    <section class="bg-gray-100">
      <div v-for="(texto,index) in Directivas" v-bind:key="index">
        <!-- Content-main -->
        <div class="md:w-3/5 mx-auto pt-20">
          <!-- Titulos - subtitulos -->
          <div class="text-justify mx-4">
              <h1 class="text-3xl pt-5 font-bold">Directivas 2021-I</h1>
              <p class="text-sm my-4 font-bold">
                {{store.user_name}}, {{texto.MensajePrincipal}}
              </p>
              <span class="text-xs text-gray-500 font-bold">
                Te aconsejamos revisarlas determinadamente antes de continuar:
              </span>
          </div>
          <!-- Directivas con su descripcion -->
          <div class="mt-5 pb-8">
          
            <!-- Directivas Financieras -->
            <b-button v-b-toggle.collapse-1 class="bg-white mb-3 h-14 flex items-center width-m hr">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" class="mx-4">
                <g id="Grupo_14141" data-name="Grupo 14141" transform="translate(-40 -160)">
                  <path id="Trazado_5197" data-name="Trazado 5197" d="M10,0A10,10,0,1,1,0,10,10,10,0,0,1,10,0Z" transform="translate(40 160)" fill="#722ae9" />
                  <path
                    id="Trazado_2847"
                    data-name="Trazado 2847"
                    d="M1102.9,526.453a.146.146,0,0,0-.12-.062h-1.767l0-1.765a.147.147,0,0,0-.146-.147h-5.549l-.36-1.069a.146.146,0,0,0-.138-.1h-3.745a.147.147,0,0,0-.146.147v8.505a.147.147,0,0,0,.146.147h9.829a.146.146,0,0,0,.138-.1l1.878-5.424A.148.148,0,0,0,1102.9,526.453Zm-10.869,4.8,1.208-4h8.544l-1.389,4Zm8.129-4.859h-7.442a.146.146,0,0,0-.14.1l-.8,2.635v-4.964h2.536l.361,1.07a.147.147,0,0,0,.138.1h5.343Z"
                    transform="translate(-1045.93 -357.309)"
                    fill="#fff"
                  />
                </g>
              </svg>
              <h1 class="font-bold">Directivas Financieras</h1>
              <div class="ml-auto mr-5">
                <svg xmlns="http://www.w3.org/2000/svg" width="11.563" height="6.844" viewBox="0 0 11.563 6.844" class="cursor-pointer">
                  <path id="Trazado_16422" data-name="Trazado 16422" d="M11.3,5.187,6.467.291A.991.991,0,0,0,5.056.3L.264,5.157A.986.986,0,0,0,1.671,6.538L5.764,2.392,9.855,6.53A.986.986,0,1,0,11.3,5.187Z" transform="translate(11.563 6.844) rotate(180)" fill="#722ae9" />
                </svg>
              </div>
            </b-button>
            <b-collapse id="collapse-1">
                <div class="bg-white -mt-4 mbt">
                  <p class="text-sm mx-4 text-justify my-4 pdb">
                    <div v-html="MensajePri" class="text-sm mx-4 text-justify">
                    </div>
                  <div class="flex items-center mx-4 py-8">
                    <!-- Input Aceptar directivas -->
                    <input type="checkbox" v-model="FinancierasCheck" class="form-checkbox h-5 w-5  focus:ring-0" :class="'text-' + classGeneral" />
                    <span class="ml-3 text-gray-500 text-sm font-bold ">Acepto las Directivas Legales</span>
                  </div>
                </div>
            </b-collapse>      
              <!-- Directivas académicas -->
              <b-button v-b-toggle.collapse-3 class="bg-white mb-3 h-14 flex items-center width-m hr">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" class="mx-4">
                  <g id="Grupo_14141" data-name="Grupo 14141" transform="translate(-40 -160)">
                    <path id="Trazado_5197" data-name="Trazado 5197" d="M10,0A10,10,0,1,1,0,10,10,10,0,0,1,10,0Z" transform="translate(40 160)" fill="#722ae9" />
                    <path
                      id="Trazado_2847"
                      data-name="Trazado 2847"
                      d="M1102.9,526.453a.146.146,0,0,0-.12-.062h-1.767l0-1.765a.147.147,0,0,0-.146-.147h-5.549l-.36-1.069a.146.146,0,0,0-.138-.1h-3.745a.147.147,0,0,0-.146.147v8.505a.147.147,0,0,0,.146.147h9.829a.146.146,0,0,0,.138-.1l1.878-5.424A.148.148,0,0,0,1102.9,526.453Zm-10.869,4.8,1.208-4h8.544l-1.389,4Zm8.129-4.859h-7.442a.146.146,0,0,0-.14.1l-.8,2.635v-4.964h2.536l.361,1.07a.147.147,0,0,0,.138.1h5.343Z"
                      transform="translate(-1045.93 -357.309)"
                      fill="#fff"
                    />
                  </g>
                </svg>
                <h1 class="font-bold">Directivas Académicas</h1>
                <div class="ml-auto mr-5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="11.563" height="6.844" viewBox="0 0 11.563 6.844" class="cursor-pointer">
                    <path id="Trazado_16422" data-name="Trazado 16422" d="M11.3,5.187,6.467.291A.991.991,0,0,0,5.056.3L.264,5.157A.986.986,0,0,0,1.671,6.538L5.764,2.392,9.855,6.53A.986.986,0,1,0,11.3,5.187Z" transform="translate(11.563 6.844) rotate(180)" fill="#722ae9" />
                  </svg>
                </div>
              </b-button>
            <b-collapse id="collapse-3" >
                <div class="bg-white -mt-4 mbt">
                    <div v-html="texto.Mensaje3" class="text-sm mx-4 text-justify pdb">
                    </div>
                  <div class="flex items-center mx-4 py-8">
                    <!-- Input Aceptar directivas -->
                    <input type="checkbox" v-model="AcademicasCheck" class="form-checkbox h-5 w-5  focus:ring-0" :class="'text-' + classGeneral" />
                    <span class="ml-3 text-gray-500 text-sm font-bold ">Acepto las Directivas Legales</span>
                  </div>
                </div>
            </b-collapse>    
            <!-- Directivas Legales -->
            <b-button v-b-toggle.collapse-2 class="bg-white mb-3 h-14 flex items-center width-m hr">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" class="mx-4">
                <g id="Grupo_14141" data-name="Grupo 14141" transform="translate(-40 -160)">
                  <path id="Trazado_5197" data-name="Trazado 5197" d="M10,0A10,10,0,1,1,0,10,10,10,0,0,1,10,0Z" transform="translate(40 160)" fill="#722ae9" />
                  <path
                    id="Trazado_2847"
                    data-name="Trazado 2847"
                    d="M1102.9,526.453a.146.146,0,0,0-.12-.062h-1.767l0-1.765a.147.147,0,0,0-.146-.147h-5.549l-.36-1.069a.146.146,0,0,0-.138-.1h-3.745a.147.147,0,0,0-.146.147v8.505a.147.147,0,0,0,.146.147h9.829a.146.146,0,0,0,.138-.1l1.878-5.424A.148.148,0,0,0,1102.9,526.453Zm-10.869,4.8,1.208-4h8.544l-1.389,4Zm8.129-4.859h-7.442a.146.146,0,0,0-.14.1l-.8,2.635v-4.964h2.536l.361,1.07a.147.147,0,0,0,.138.1h5.343Z"
                    transform="translate(-1045.93 -357.309)"
                    fill="#fff"
                  />
                </g>
              </svg>
              <h1 class="font-bold">Directivas Legales</h1>
              <div class="ml-auto mr-5">
                <svg xmlns="http://www.w3.org/2000/svg" width="11.563" height="6.844" viewBox="0 0 11.563 6.844" class="cursor-pointer">
                  <path id="Trazado_16422" data-name="Trazado 16422" d="M11.3,5.187,6.467.291A.991.991,0,0,0,5.056.3L.264,5.157A.986.986,0,0,0,1.671,6.538L5.764,2.392,9.855,6.53A.986.986,0,1,0,11.3,5.187Z" transform="translate(11.563 6.844) rotate(180)" fill="#722ae9" />
                </svg>
              </div>
            </b-button>
            <b-collapse id="collapse-2" visible>
              <div class="bg-white -mt-4 mbt">
                <div v-html="texto.Mensaje4" class="text-sm mx-4 text-justify pdb">
                </div>
                <div class="flex items-center mx-4 py-8">
                  <!-- Input Aceptar directivas -->
                  <input type="checkbox" v-model="LegalCheck" class="form-checkbox h-5 w-5  focus:ring-0" :class="'text-' + classGeneral " />
                  <span class="ml-3 text-gray-500 text-sm font-bold ">Acepto las Directivas Legales</span>
                  
                </div>
              </div>
            </b-collapse>
            <div class="my-5 mr-3 md:text-justify ml-4">
              <!-- Input directivas leídas -->
              <input type="checkbox" v-model="AllCheck" class="form-checkbox h-5 w-5 text-indigo-600 focus:ring-0" />
              <span class="ml-2 text-gray-500 text-sm font-bold">He leído las Directivas Financieras, Académicas y Legales vigentes para el ciclo 2021-I </span>
            </div>
            <!-- Button continuar -->
            <div class="md:flex justify-end">
                <!--<router-link to="/main/bienvenido">-->
                    <button class="text-white w-11/12 md:w-40 rounded-lg h-12 my-4" :class="'bt-' + classGeneral" @click.prevent="ValidarCamposDirectivas();" >
                        Continuar
                    </button>
                <!--</router-link>-->
            </div>
          </div> 
        </div> 
      </div>
    </section>
</div>
</template>
  
  <script>
  import Vue from 'vue'
  import { BootstrapVue } from 'bootstrap-vue'
  Vue.use(BootstrapVue)
  export default {
    name: "Directivas",
    data() {
      return {
        Directivas: [],
        Mensaje1: '',
        Mensaje2: '',
        MensajePri: '',
        IdDirectiva3: '',
        IdDirectiva4: '',
        FinancierasCheck: '',
        AcademicasCheck: '',
        LegalCheck: '',
        AllCheck: ''
      }
    },   
    methods: {
      DirectivasGET() {
        this.$store.dispatch("directivasStore/directivas").then((response) => {
          if (response.success) {
            var myObj = response;
            var Lista = myObj.results;
            this.Directivas.push(Lista);
            this.Mensaje1 = response.results.Mensaje1;
            this.Mensaje2 = response.results.Mensaje2;
            this.IdDirectiva3 = response.results.IdDirectiva3;
            this.IdDirectiva4 = response.results.IdDirectiva4;
            if (this.Mensaje1 === this.Mensaje2) {
              this.MensajePri = this.Mensaje1;
            }else{
              this.MensajePri = this.Mensaje1 + '<br />' + this.Mensaje2;
            }
          }
        });  
      },
      AceptarDirectivas() {
        let store = JSON.parse(localStorage.getItem('data'))
        var form = {
            'DatosGrabars' : 1,
            'IdActors': store.user_id_actor,
            'IdDirectiva3s': this.IdDirectiva3,
            'IdDirectiva4s': this.IdDirectiva4,
            'IdMatriculaDirectivas': store.user_matricula,
            'IdUsuarioDirectivas': store.user_id_usuario
        }   
        this.$store.dispatch("directivasStore/directivasPOST", form).then((response) => {
          if (response.success) {
            this.$router.push('/main/bienvenido');
          }
        }); 
      },
      ValidarCamposDirectivas() {
        if (this.FinancierasCheck === false){
          return false;
        }else if (this.AcademicasCheck === false){
          return false;
        }else if(this.LegalCheck === false){
          return false;
        }else if (this.AllCheck === false){
          return false;
        }else if(this.FinancierasCheck === true && this.AcademicasCheck ===  true && this.LegalCheck === true && this.AllCheck === true){
          AceptarDirectivas()
          //this.$router.push('/dashboard');
          return true;
        }
      }
    },
    created() {
      this.DirectivasGET();
    },  
    computed: {
      store(){
        return JSON.parse(localStorage.getItem('data'))
      },
      classGeneral(){
        return localStorage.getItem('classGeneral')
      }
    }
  };
  </script>
  
  <style>
  section {
    font-family: "Montserrat";
  }
  .width-m{
    width: 100%;
  }
  .hr{
    border-bottom: 0.05rem solid #eaeaea;
  }
  .mbt{
    margin-bottom: 2%;
  }
  .pdb{
    padding-top: 3%
  }
  </style>
  