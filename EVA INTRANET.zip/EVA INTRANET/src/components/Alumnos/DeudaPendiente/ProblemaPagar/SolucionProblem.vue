<template>
  <section class="bg-gray-100">
    <div class="bg-gray-100">
      <!-- Content-main -->
      <div class="pt-20 mx-auto md:w-3/5">
        <!-- Titulos --->
        <div class="mx-4 text-justify md:mx-0">
          <h1 class="pt-5 text-xl font-bold text-left md:text-3xl">
            Nos gustaría contactarte para encontrar una solución
          </h1>
        </div>

        <div class="pb-8 mt-5">
          <!-- Form contraseña-->
          <div class="flex items-start mb-3 bg-white">
            <div class="w-full md:h-36">
              <h1 class="flex my-4 ml-5 text-xs font-bold text-left md:text-sm">
                ¿En qué horario te puede llamar nuestro asesor?
              </h1>
              <div class="md:flex">
                <div class="flex h-12 my-4 mb-5 ml-5 md:mb-0 ">
                  <input type="time" class="p-2 text-xs font-bold border md:w-96 w-72" />
                </div>
              </div>
            </div>
          </div>

          <div class="flex items-start mb-3 bg-white">
            <div class="w-full md:h-36">
              <h1 class="flex my-4 ml-5 text-xs font-bold text-left md:text-sm">
                Tenemos este número registrado ¿Quieres usarlo?
              </h1>
              <!-- inputs up -->
              <div class="flex">
                <ModalEditar />
              </div>
            </div>
          </div>

          <div class="flex flex-col ml-5 text-xs font-bold md:flex-row md:ml-0 md:text-sm">
            <span class="flex mt-2 md:mr-2">¿Tienes duda sobre el Reglamento Académico?</span>
            <a href="" class="flex mt-2 underline " :class="'text-' + classGeneral ">Descárgalo aquí</a>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import ModalEditar from "@/components/Alumnos/DeudaPendiente/ProblemaPagar/ModalEditar";

export default {
  name: "SolucionProblem",
  components: {
    ModalEditar,
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
