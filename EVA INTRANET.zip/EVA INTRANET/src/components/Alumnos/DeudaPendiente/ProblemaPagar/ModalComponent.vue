<template>
  <div class="overlay mt-16">
    <div class="modal bg-white md:w-96 w-screen md:p-9 md:rounded-md h-full md:h-60">
      <div class="flex items-center justify-between p-3">
        <span class="md:text-left text-justify text-xl font-extrabold pt-8 md:pt-0 ">{{ title }}</span>
      </div>
      <div class="p-3">
        <div class="mb-4">
          <slot></slot>
        </div>
        <button class="text-white p-2 text-sm rounded md:w-1/2  w-full mt-72 md:mt-2 h-12" :class="'bt-' + classGeneral " @click.prevent="close">
          Listo
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ModalComponent",
  props: {
    title: {
      type: String,
      required: true,
    },
  },

  methods: {
    close() {
      this.$emit("toggle-modal");
    },
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style lang="postcss" scoped>
.overlay {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: rgba(78, 71, 71, 0.3);
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
  backdrop-filter: blur(5px);
}

.modal {
  animation: appear 0.15s cubic-bezier(0, 1.8, 1, 1.8);
}

@keyframes appear {
  from {
    opacity: 0;
    transform: translateX(-3rem);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
