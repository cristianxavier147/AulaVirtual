<template>
  <div>
    <section class="mt-5">
      <button onclick="document.getElementById('myModal2').showModal()" id="btn" class="px-10 py-3 text-white rounded shadow-xl text" :class="'bt-'+classGeneral">
        Cambiar
      </button>
    </section>
    <dialog id="myModal2" class="relative w-11/12 p-5 bg-white rounded-md md:h-3/5 h-1/2 md:w-4/12 top-14">
      <div class="flex flex-col w-full h-auto md:px-8 md:py-5">
        <!-- Header -->
        <div class="flex items-center justify-between w-full h-auto">
          <h1 class="text-2xl font-bold md:text-xl">Verificación</h1>
          <!--Header Fin-->
        </div>
        <div class="mt-2 text-left">
          <span class="text-xs font-bold">Hemos enviado un SMS al número que nos diste.</span>
          <p class="text-xs font-medium text-justify">
            Para confirmar que el número es correcto, indícanos el código de verificación que recibiste.
          </p>
          <h1 class="mt-3 text-xs text-gray-600">
            Si no recibiste el mensaje en 01:00, haz
            <a href="#" class="text-xs font-bold underline" :class="'text-' + classGeneral ">click aquí</a>
            para enviar de nuevo
          </h1>
          <div class="w-full my-8 text-center md:my-7">
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
            <input type="number" class="h-10 mx-1 text-center border-b border-gray-900 w-7" />
          </div>
        </div>
        <div>
          <ModalConfirmar />
        </div>
        <!-- fin del contenido modal-->
      </div>
    </dialog>
  </div>
</template>

<script>
import ModalConfirmar from "@/components/Alumnos/DeudaPendiente/ProblemaPagar/ModalConfirmar";
export default {
  name: "ModalVerificacion",
  components: {
    ModalConfirmar,
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style scoped>
dialog[open] {
  animation: appear 0.15s cubic-bezier(0, 1.8, 1, 1.8);
}

dialog::backdrop {
  background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
  backdrop-filter: blur(3px);
  margin-top: 4rem;
}

@keyframes appear {
  from {
    opacity: 0;
    transform: translateX(-3rem);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
