<template>
  <div>
    <section class="flex">
      <div class="flex h-12 mb-5 ml-5 md:mb-0 md:w-12/12">
        <input type="text" placeholder="995 678 904" class="p-2 text-xs font-bold border md:w-96 w-72" />
        <img src="@/assets/svg/lapiz2.svg" alt="lapiz2" class="relative w-5 cursor-pointer right-10 md:w-6" onclick="document.getElementById('myModal').showModal()" id="btn" />
      </div>
    </section>
    <!-- DIALOG -->
    <dialog id="myModal" class="relative w-8/12 p-5 bg-white rounded-md md:h-72 md:w-3/12 top-12">
      <div class="flex flex-col w-full h-auto px-8 py-5">
        <!-- Header -->
        <div class="flex items-center justify-center w-full h-auto">
          <div class="flex w-full h-auto py-3 font-bold text-left md:text-xl">
            Cambio de teléfono
          </div>
          <!--Header Fin-->
        </div>
        <!-- input teléfono/celular-->
        <input type="number" placeholder="Teléfono / Celular" class="h-12 p-2 text-xs font-bold text-gray-500 border rounded-sm md:w-56 w-52" />
        <div class="mt-5">
          <ModalVerificacion />
        </div>
        <!-- fin del contenido modal-->
      </div>
    </dialog>
  </div>
</template>

<script>
import ModalVerificacion from "@/components/Alumnos/DeudaPendiente/ProblemaPagar/ModalVerificacion";
export default {
  name: "ModalEditar",
  components: {
    ModalVerificacion,
  },
};
</script>

<style scoped>
dialog[open] {
  animation: appear 0.15s cubic-bezier(0, 1.8, 1, 1.8);
}

dialog::backdrop {
  background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
  margin-top: 4rem;
  backdrop-filter: blur(5px);
}

@keyframes appear {
  from {
    opacity: 0;
    transform: translateX(-3rem);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
