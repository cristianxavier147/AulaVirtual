<template>
  <div>
    <section class="mt-5">
      <button onclick="document.getElementById('myModal3').showModal()" id="btn" class="py-3 px-10 text-white rounded text shadow-xl w-9/12" :class="'bt-'+classGeneral">
        Validar
      </button>
    </section>
    <dialog id="myModal3" class="md:h-60 w-8/12 md:w-3/12 p-1 bg-white rounded-md relative top-20">
      <div class="flex flex-col w-full h-auto px-8 py-5">
        <!-- Header -->
        <div class="flex w-full h-auto justify-center items-center">
          <div class="flex w-full h-auto py-3 md:text-base text-left font-bold">
            Te estaremos contactando lo más pronto posible
          </div>
          <!--Header Fin-->
        </div>
        <div class="mt-10">
          <router-link to="/dashboard">
            <button class="w-8/12 md:mt-0 text-white h-12 rounded-md font-medium" :class="'bt-' + classGeneral ">
              Listo
            </button>
          </router-link>
        </div>
        <!-- fin del contenido modal-->
      </div>
    </dialog>
  </div>
</template>

<script>
export default {
  name: "ModalConfirmar",
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style scoped>
dialog[open] {
  animation: appear 0.15s cubic-bezier(0, 1.8, 1, 1.8);
}

dialog::backdrop {
  background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
  backdrop-filter: blur(5px);
  margin-top: 4rem;
}

@keyframes appear {
  from {
    opacity: 0;
    transform: translateX(-3rem);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}
</style>
