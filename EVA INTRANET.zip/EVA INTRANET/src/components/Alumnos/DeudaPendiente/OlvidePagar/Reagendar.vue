<template>
  <section class="bg-white">
    <div class="bg-white h-screen">
      <!-- Content-main -->
      <div class="md:w-3/5 mx-auto pt-24">
        <!-- Titulos - subtitulos -->
        <div class="text-justify mx-4 md:mx-0">
          <h1 class="text-xl pt-5 font-bold ml-2 md:ml-0 ">
            Se ha registrado la fecha de pago
          </h1>
          <p class="text-sm my-4 font-bold ml-2 md:ml-0">
            Recibirás un correo con la confirmación y podrás hacer el pago de la cuota en la sección Pagos.
          </p>
          <input type="text" class="w-80 md:w-96 mt-5 mb-5" placeholder="Fecha nueva de vencimiento: 10.03.21" />
        </div>
        <a href="" class="underline ml-5 md:ml-0 flex  font-bold text-sm" :class="'text-' + classGeneral ">Sincronizar con mi calendario</a>

        <div class="mt-36 md:mt-0 pb-8 md:flex">
          <div class="md:flex md:justify-end mt-5 md:mt-10">
            <!-- botton ir a pagos-->
            <div class="pt-6">
              <router-link to="/alumnos/pagoTarde/reagendarPago">
                <button class="text-white w-11/12 md:w-56 rounded-lg h-12" :class="'bt-' + classGeneral ">
                  Ir a pagos
                </button>
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "Reagendar",
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
