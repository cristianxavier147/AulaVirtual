<template>
  <section class="bg-white">
    <div class="bg-white h-screen">
      <!-- Content-main -->
      <div class="md:w-3/5 mx-auto pt-24">
        <!-- Titulos - subtitulos -->
        <div class="text-justify mx-4 md:mx-0">
          <h1 class="text-2xl md:text-3xl pt-5 font-bold ml-2 md:ml-0">
            Si te olvidaste de pagar
          </h1>
          <p class="text-sm my-4 font-bold ml-2 md:ml-0">
            Tenemos dos soluciones para ti.
          </p>
          <span class="md:text-sm text-xs">Cuéntanos cúal se te acomoda más. Si das click en pagar ahora te redireccionaremos a nuestra pasarela de pagos.</span>
        </div>

        <div class="mt-5 md:mt-0 pb-8 md:flex">
          <div class="md:flex md:justify-end mt-5 md:mt-10">
            <!-- botton me olvidé -->
            <div class="pt-6">
              <router-link to="/alumnos/pagoTarde/olvide">
                <button class="text-white w-11/12 md:w-64 rounded-lg h-12" :class="'bt-' + classGeneral ">
                  Pagar ahora
                </button>
              </router-link>
            </div>
            <!-- botton tuve un problema -->
            <div class="md:ml-5 md:pt-6 mt-8 md:mt-0">
              <router-link to="/alumnos/pagoTarde/olvideFinish">
                <button class="bg-gray-300 text-black font-medium w-11/12 md:w-64 rounded-lg h-12 ">
                  Reagendar fecha de pago
                </button>
              </router-link>
            </div>
          </div>
        </div>
        <span class="md:flex md:text-sm text-xs"
          >Si no tienes el calendario de pagos,
          <a href="" class="underline  font-bold" :class="'text-' + classGeneral ">descargalo aquí</a>
        </span>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "Olvido",
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
