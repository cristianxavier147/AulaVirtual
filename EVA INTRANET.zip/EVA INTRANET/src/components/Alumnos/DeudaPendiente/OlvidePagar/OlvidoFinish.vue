<template>
  <section class="bg-gray-100">
    <div class="bg-gray-100">
      <!-- Content-main -->
      <div class="md:w-3/5 mx-auto pt-24">
        <!-- Titulos -->
        <div class="text-justify mx-4 md:mx-0">
          <h1 class="text-3xl font-bold">Para terminar</h1>
          <p class="text-sm my-4 font-bold">
            Por favor confírmanos cuando estarías realizando el pago.
          </p>
        </div>
        <div class="mt-5 pb-8">
          <div class="bg-white mb-3 flex items-start">
            <div class="w-full">
              <!-- Compromiso de pago -->
              <h1 class="font-bold text-sm my-4 mr-14 text-justify ml-5">
                Yo, Giancarlo Guillen Cotrina, con código PL43721083 me comprometo a pagar mis cuotas pendientes por el total de: S/. 760.00, como máximo el día:
              </h1>
              <div class="md:flex mb-5">
                <div class="mb-5 md:mb-0 flex ml-5 h-12  md:w-5/12">
                  <input type="date" placeholder="Escribe tu nueva contraseña" class="border-gray-200 font-bold text-xs w-11/12 md:w-full" />
                </div>
              </div>
            </div>
          </div>
          <div class="mt-5  text-left ml-5 md:w-auto">
            <div>
              <span class="text-xs font-medium text-gray-500">Si te excediste de los 17 días desde que venció tu cuota, se aplicará un recargo administrativo. </span>
            </div>
            <a href="" class="text-xs  font-bold underline" :class="'text-' + classGeneral ">Descarga el reglamento académico aquí</a>
          </div>

          <div class="mt-5 md:mt-0 pb-8 md:flex">
            <div class="md:flex md:justify-end mt-5 md:mt-10">
              <!-- botton me olvidé -->
              <div class="pt-6">
                <router-link to="/alumnos/pagoTarde/olvide">
                  <button class=" bg-gray-300 text-black w-11/12 md:w-64 rounded-lg h-12">
                    Regresar
                  </button>
                </router-link>
              </div>
              <!-- botton tuve un problema -->
              <div class="md:ml-5 md:pt-6 mt-8 md:mt-0">
                <router-link to="/alumnos/pagoTarde/reagendarPago">
                  <button class="text-white font-medium w-11/12 md:w-64 rounded-lg h-12 " :class="'bt-' + classGeneral ">
                    Confirmar
                  </button>
                </router-link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "OlvidoFinish",
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
