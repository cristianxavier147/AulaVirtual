<template>
  <section class="bg-gray-100">
    <div class="bg-gray-100">
      <!-- Content-main -->
      <div class="md:w-3/5 mx-auto pt-24">
        <img v-if="classGeneral === 'purple'" src="@/assets/onboarding/alumnos/circle5-purple.svg" class="ml-2 md:ml-0" />
        <img v-if="classGeneral === 'red'" src="@/assets/onboarding/alumnos/circle5-red.svg" class="ml-2 md:ml-0" />
        <img v-if="classGeneral === 'blue'" src="@/assets/onboarding/alumnos/circle5-blue.svg" class="ml-2 md:ml-0" />
        <!-- Titulos - subtitulos -->
        <div class="text-justify mx-4 md:mx-0">
          <h1 class="text-3xl pt-5 font-bold">Para terminar</h1>
          <p class="text-sm md:text-base my-4 font-bold">
            ¡Actualiza tu contraseña para mantener tu información a salvo!
          </p>
        </div>

        <div class="mt-5 pb-8">
          <!-- Form contraseña-->
          <div class="hcaja4 bg-white mb-3 flex items-start">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/seguridad.svg" alt="idat"/>
            </div>

            <div class="tm-r-bl w-full">
              <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                ¿Cúal es tu contraseña actual?
              </h1>
              <div class="md:flex">
                <div class="mb-5 md:mb-0 flex ml-5 h-12 my-1 md:w-5/6 relative">
                  <input type="password" placeholder="Escribe tu contraseña" class="border p-3 border-gray-200 font-bold text-xs w-11/12 md:w-full" v-model="password" />
                  <span class="absolute left-0 -bottom-5 text-red block pl-2 size-text-10 font-bold" v-if="passwordIncorrecto">* Contraseña incorrecta</span>
                </div>
              </div>
              <div class="text-left" v-if="this.rules.password == true">
                <span class="ml-5 md:ml-8 text-red size-text-10 font-bold">* Este campo es obligatorio </span>
              </div>
            </div>
          </div>

          <div class="hcaja3 hcaja3-2-r bg-white mb-3 flex items-start">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/seguridad.svg" alt="idat" />
            </div>

            <div class="tm-r-bl w-full">
              <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                ¿Cuál es tu nueva contraseña?
              </h1>
              <div class="md:flex">
                <div class="mb-5 md:mb-0 flex ml-5 h-12  md:w-5/12 relative">
                  <input type="password" placeholder="Escribe tu nueva contraseña" v-model="passwordnew" @keyup="validateFormat"  class="border p-3 border-gray-200 font-bold size-text-12 w-11/12 md:w-full" />
                  <span class="absolute left-0 -bottom-5 text-red block pl-2 size-text-10 font-bold" v-if="passwordnotrules">* La contraseña no cumple con los criterios necesarios.</span>
                  <span class="absolute left-0 -bottom-5 text-red block pl-2 size-text-10 font-bold" v-if="this.rules.passwordnew == true">* Este campo es obligatorio.</span>
                </div>
                <div class="mb-5 md:mb-0 flex ml-5 h-12 md:w-2/5 relative">
                  <input type="password" placeholder="Repite tu nueva contraseña" v-model="passwordnewr" class="border p-3 border-gray-200 font-bold size-text-12 w-11/12 md:w-full" />
                  <span class="absolute left-0 -bottom-5 text-red block pl-2 size-text-10 font-bold"  v-if="passwordnotisame">* Las contraseñas no coinciden.</span>
                  <span class="absolute left-0 -bottom-5 text-red block pl-2 size-text-10 font-bold" v-if="this.rules.passwordnewr == true">* Este campo es obligatorio.</span>
                </div>
              </div>
              <div class="mt-6 w-9/12 flex text-left ml-5 md:w-auto">
                <span class="text-xs font-medium text-gray-500">Por seguridad, asegúrate de incluir una mayúscula y un número. </span>
              </div>
            </div>
          </div>

          <div class="mt-10 md:text-right lg:text-right">
            <!-- <span @click="omision" class="text-right font-bold border-b cursor-pointer" :class="'text-' + classGeneral + '-600 ; border-' + classGeneral + '-600'">
              Omitir este paso
            </span> -->
            <!-- botton anterior -->
            <div class="md:flex md:justify-end pb-5 md:pb-0">
              <div class="md:block">
                <router-link to="/alumnos/onboarding/photo">
                  <button class="bg-gray-300 text-black font-medium w-11/12 md:w-40 rounded-lg h-12 my-4">
                    Anterior
                  </button>
                </router-link>
              </div>

              <!-- botton siguiente -->
              <div class="md:ml-5">
                <button class="text-white w-11/12 md:w-60 rounded-lg h-12 md:my-4" :class="'bt-' + classGeneral" @click="send">
                  Guardar y continuar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <ModalFinalizado v-if="openModal" />
  </section>
</template>

<script>
import ModalFinalizado from "@/components/Alumnos/Onboarding/Modal/ModalFinalizado";
export default {
  
  name: "FormFinalizar",
  data() {
    return {
      password: '',
      passwordnew: '',
      passwordnewr: '',
      rules:{
        password: false,
        passwordnew: false,
        passwordnewr: false,
      },
      passwordnotisame: false,
      passwordnotrules: false,
      passworderror: false,
      passwordIncorrecto: false,
      openModal: false,
      IdProgramacionDilo: ''
    }
  },

  components: {
    ModalFinalizado
  },

  methods: {
    validarCampos(){
      if(this.password === null || this.password === "") {
        this.rules.password = true
      }else{
        this.rules.password = false
      }

      if(this.passwordnew === null || this.passwordnew === "") {
        this.rules.passwordnew = true
        this.passwordnotrules = false
      }else{
        this.rules.passwordnew = false
      }

      if(this.passwordnewr === null || this.passwordnewr === "") {
        this.rules.passwordnewr = true
        this.passwordnotrules = false
      }else{
        this.rules.passwordnewr = false
      }

      if( this.rules.password === false && this.rules.passwordnew === false && this.rules.passwordnewr === false) {
        return true
      }else{
        return false
      }
    },
    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validate = this.validarCampos()
      if(validate === true){
        var formP = {
          username: store.user_codigo,
          password: this.password
        }

        var valid = this.validatePaswoord()
        if(this.passworderror === false && this.passwordnotrules === false && this.passwordnotisame === false) {
          this.$store.dispatch("loginStore/verificacontrasenia",formP).then(
            (response) => {
              if(response.success == true){
                this.passwordIncorrecto = false
                  var form = {
                    username: store.user_codigo,
                    password: this.passwordnew
                  }
                  this.$store.dispatch("loginStore/changePasswordMethod",form).then(
                      (response) => {
                        if(response.success == true){
                          let formData = {
                            IdUsuario: store.user_id_usuario,
                            Login: store.user_codigo,
                            IdProgramacionDilo : this.IdProgramacionDilo,
                          }
                            this.$store.dispatch("onboardingStore/finalizarOnboarding",formData).then(
                                (response) => {
                                  if(response.success == true){
                                      this.openModal = true
                                  }
                                }
                            )
                        }
                      }
                  )
              }else{
                this.passwordIncorrecto = true
              }
            }
          )
        }
      }
    },
    allData(){      
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdTipoUsuario: store.user_type_usuario,
        Login: store.user_codigo,
        IdUltimaMatricula: store.user_matricula,
        IdUnidadNegocio: store.user_unidad_negocio,
        IdUnidadAcademica: store.user_unidad_academica,
        IdModulo: store.user_id_modulo,
        IdSede: store.user_id_sede
      }

      this.$store.dispatch("onboardingStore/paso1", formData).then(
        (response) => {
        if (response.success == true) {
          var data = response.results
          this.IdProgramacionDilo = data.IdProgramacionDilo
        }
      });

    },
    validatePaswoord(){
      if(this.passwordnew == "" && this.passwordnewr == ""){
        this.passworderror = true
      }else{
        this.passworderror = false
        if(this.passwordnew !== this.passwordnewr){
          this.passwordnotisame = true
        }else{
          this.passwordnotisame = false
        }
      }
    },
    validateFormat(){
      this.rules.passwordnew = false
      var txt = this.passwordnew
      var cant = txt.length
      var may = /[A-Z]/.test(txt)
      var num = /[0-9]/.test(txt)

      if(txt < 8) return 


      if(!may) return this.passwordnotrules = true

      if(!num) return this.passwordnotrules = true

      this.passwordnotrules = false

    },

    omision(){
      // this.$store.dispatch("loginStore/changePassword",form).then(
      //     (response) => {
      //       if(response.success == true){
      //           this.$router.push({ name: 'dashboard' }).catch(()=>{})
      //       }
      //     }
      // )

    this.$router.push({ name: 'dashboard' }).catch(()=>{})
    }
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },

};
</script>

<style></style>
