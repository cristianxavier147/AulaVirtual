<template>
  <section class="bg-gray-100">
    <!-- Content-main -->
    <div class="pt-24 mx-auto md:w-3/5">
      <img v-if="classGeneral === 'purple'" src="@/assets/onboarding/alumnos/circle-purple.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'red'" src="@/assets/onboarding/alumnos/circle-red.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'blue'" src="@/assets/onboarding/alumnos/circle-blue.svg" class="ml-2 md:ml-0" />
      <!-- Titulos - subtitulos -->
      <div class="mx-2 text-justify md:mx-0">
        <h1 class="pt-8 text-xl font-bold md:text-3xl">
          ¡Te damos la bienvenida a EVA!
        </h1>
        <p class="mt-3 size-text-16 font-bold">
          ¡Queremos conocerte!, cuéntanos sobre ti.
        </p>
        <span class="size-text-16 font-medium text-gray-500">
          Toda la información que nos proporciones servirá para poderte brindar un servicio más personalizado.
        </span>
      </div>

      <div class="pb-8 mt-5 size-text-14 size-text-res-12">
        <!-- Form USER -->
        <div class="hcaja1 flex items-start mb-3 bg-white">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center " >
            <img src="@/assets/svg/maletin.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Actualmente estas trabajando?
            </div>

            <div class="md:ml-8 lg:ml-8 ml-5 xl:flex lg:flex block mr-3">
              <div class="flex my-3">
                <select @change="secltTrabjao" class=" border form-control pl-3 pr-6 py-3 bg-white font-bold mr-2" id="-" v-model="data.sntrabajando" :class="this.rules.sntrabajando === true ? 'brdr-red '+classGeneral : classGeneral" >
                  <option value="null" selected="selected" disabled></option>
                  <option value="1">Sí</option>
                  <option value="2">No</option>
                </select>
                <label class="my-auto mr-3 font-medium"> , estoy trabajando como</label>
              </div>
              <div class="my-3 lg:mr-2 md:mr-2">
                <select class=" border font-bold pl-5 pr-6 py-3 w-full bg-white" v-model="data.tipotrabajo" :class="this.rules.tipotrabajo === true ? 'brdr-red '+classGeneral : classGeneral" :disabled="this.data.sntrabajando == '1' ? false : true ">
                  <option value="null" selected="selected" disabled></option>
                  <option value="0">Independiente</option>
                  <option value="1">Dependiente</option>
                </select>
              </div>
              <div class="flex my-3">
                <label class="my-auto mr-3  font-medium">en</label>
                <input type="text" placeholder="¿Cúal es la empresa?" class="border w-full font-bold md:my-auto px-5 py-3 ip-empresa" v-model="data.nombreemepresa" :class="this.rules.nombreemepresa== true ? 'brdr-red' : ''"  :disabled="this.data.sntrabajando == '1' ? false : true ">
              </div>
            </div>
            <div class="md:ml-8 lg:ml-8 ml-5 xl:flex lg:flex block mr-3">
              <div class="flex my-3">
                <label class="my-auto mr-1 font-medium md:ml-4 md:mr-3">desde</label>
                <select  class=" mr-1 w-full font-bold md:mr-3 pl-3 pr-6 py-3 border sl-mes" v-model="data.mes" :class="this.rules.mes === true ? 'brdr-red '+classGeneral : classGeneral" :disabled="this.data.sntrabajando == '1' ? false : true ">
                  <option value="null" selected="selected" disabled></option>
                  <option value="ene" >Enero</option>
                  <option value="feb" >Febrero</option>
                  <option value="mar" >Marzo</option>
                  <option value="abr" >Abril</option>
                  <option value="may" >Mayo</option>
                  <option value="jun" >Junio</option>
                  <option value="jul" >Julio</option>
                  <option value="ago" >Agosto</option>
                  <option value="sep" >Septiembre</option>
                  <option value="oct" >Octubre</option>
                  <option value="nov" >Noviembre</option>
                  <option value="dic" >Diciembre</option>
                </select>
                <label class="my-auto mr-1  md:mr-3">del</label>
                <select class=" font-bold w-full pl-3 pr-6 border sl-anio" v-model="data.anio" :class="this.rules.anio === true ? 'brdr-red '+classGeneral : classGeneral" :disabled="this.data.sntrabajando == '1' ? false : true ">
                  <option value="null" selected="selected" disabled></option>
                  <option value="2021">2021</option>
                  <option value="2020">2020</option>
                  <option value="2019">2019</option>
                  <option value="2018">2018</option>
                </select>
              </div>
              <div class="flex my-3">
                <label class="my-auto mr-3  font-medium "> . Mi cargo es:</label>
                <input type="text" name="cargo" placeholder="¿Cúal es tu cargo?" class="font-bold border px-5 py-3" vstyle="width: 259px; height: 42px" v-model="data.cargotrabajo" :class="this.rules.cargotrabajo === true ? 'brdr-red' : ''" :disabled="this.data.sntrabajando == '1' ? false : true " />
              </div>
            </div>
          </div>
        </div>

        <!-- Form al acabar los estudios -->
        <div class="hcaja2 flex items-start mb-3 bg-white" v-if="parseInt(store.user_unidad_negocio) === 1">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/comillas.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Qué quieres hacer cuando acabes tu estudios?
            </div>
            <h1 class="flex my-3 ml-5  font-medium md:ml-8 md:my-3 mt-2">
              Cuando acabe mis estudios en {{ classGeneral === 'purple' ? 'Idat' : 'Zegel Ipae'}} quisiera...
            </h1>
            <!-- texto -->
            <textarea class="block w-11/12 p-2 mx-auto mt-1  font-bold border form-textarea rounded-md" rows="3" placeholder="Escribe aquí..." v-model="data.expectativas" ></textarea>
            <div class="mt-2" v-if="this.rules.expectativas == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>
        <!-- Form con quien vives -->
        <div class="hcaja3 flex items-start mb-3 bg-white" v-if="parseInt(store.user_unidad_negocio) === 1">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/home.svg" alt="idat"/>
          </div>

          <div class="tm-r-bl w-full text-justify">
            <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Con quién vives actualmente?
            </h1>
            <!-- texto -->
            <textarea class="block w-11/12 p-2 mx-auto mt-1  font-bold border form-textarea rounded-md" rows="3" placeholder="Escribe aquí..." v-model="data.PersonasVive" ></textarea>
            <div class="mt-2" v-if="this.rules.PersonasVive == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>

        <!-- Form quien cubre tus estudios -->
        <div class="hcaja3 flex items-start mb-3 bg-white" v-if="parseInt(store.user_unidad_negocio) === 1">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/dolar.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Quién financia tus estudios?
            </div>
            <!-- texto -->
            <textarea class="block w-11/12 p-2 mx-auto mt-1  font-bold border form-textarea rounded-md" rows="3" placeholder="Escribe aquí..." v-model="data.FinanciaEstudios" ></textarea>
            <div class="mt-2" v-if="this.rules.FinanciaEstudios == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>

        <!-- Form motivo de elección -->
        <div class="hcaja3 flex items-start mb-3 bg-white">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/graduation.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding pr-4">
              ¿Cuál es el motivo principal por el que elegiste {{ classGeneral === 'purple' ? 'Idat' : 'Zegel Ipae'}} y no otro instituto?
            </div>
            <!-- text area -->
            <textarea class="block w-11/12 p-2 mx-auto mt-1  font-bold border form-textarea rounded-md" rows="3" placeholder="Escribe aquí..." v-model="data.EleccionMotivoPrincipal" ></textarea>
            <div class="mt-2" v-if="this.rules.EleccionMotivoPrincipal == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>

        <!-- Form motivo de interés -->
        <div class="hcaja4 flex items-start mb-3 bg-white">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/eye.svg" alt="idat"  />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding">
              ¿Cómo te enteraste de {{ classGeneral === 'purple' ? 'Idat' : 'Zegel Ipae'}}?
            </div>
            <!-- seleccion motivo v-model="form.interes"  -->
            <select :class="classGeneral" class="md:ml-8 lg:ml-8 ml-5 border text-gray-400 font-bold pl-5 pr-6 py-3 md:w-2/5 w-4/5 bg-white " v-model="data.InformacionIpae">
              <option disabled selected>Seleccione</option>
              <option v-for="(item, index) in interes" :key="index" :value="item.IdMaestroRegistro">{{ item.Nombre }}</option>
            </select>
            <div class="mt-2" v-if="this.rules.InformacionIpae == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>

        <!-- Form evaluación de otras opciones --> 
        <div class="hcaja3 flex items-start mb-3 bg-white">
          <!-- SVG IMAGEN -->
          <div class="barra-lateral flex justify-center items-center ">
            <img src="@/assets/svg/lapiz.svg" alt="idat" />
          </div>

          <div class="tm-r-bl w-full text-justify">
            <div class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-5 pt-2 w-auto border-cajas-onboarding pr-4">
              <span>¿Qué otros instituos y/o universidades evaluaste antes de elegir {{ classGeneral === 'purple' ? 'Idat' : 'Zegel Ipae'}}?</span>
            </div>
            <!-- text area -->
            <textarea class="block w-11/12 p-2 mx-auto mt-1  font-bold border form-textarea rounded-md" rows="3" placeholder="Escribe aquí..." v-model="data.EleccionCentroEstudio" ></textarea>
            <div class="mt-2" v-if="this.rules.EleccionCentroEstudio == true">
              <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
            </div>
          </div>
        </div>

        <!-- boton anterior -->
        <div class="justify-end md:flex">
          <!-- <div class="md:block md:mt-12">
            <router-link to="/beneficios">
              <button class="w-11/12 h-12 my-4 font-medium text-black bg-gray-300 rounded-lg md:w-40">
                Anterior
              </button>
            </router-link>
          </div> -->

          <!-- botton siguiente -->
          <div class="md:ml-4 md:mt-12">
            <!-- <router-link to="/main/validarDatos"> -->
              <button class="w-11/12 h-12 my-4 text-white rounded-lg md:w-60" :class="'bt-'+classGeneral" @click="send()">
                Guardar y continuar
              </button>
            <!-- </router-link> -->
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { eventBus } from "@/config/eventBus";
export default {
  name: "FormBienvenida",

  data() {
    return {
      form: {
        interes: null,
      },
      interes: [],
      data:{
        IdUsuario: 0,
        IdActor: 0,
        Login: 0,
        sntrabajando: null,
        tipotrabajo: null,
        nombreemepresa: '',
        mes: null,
        anio: null,
        cargotrabajo: '',
        expectativas: '',
        CambioPersonasVive: 1,
        PersonasVive: '',
        CambioFinanciaEstudios: 1,
        FinanciaEstudios: '',
        CambioEleccionMotivoPrincipal: 1,
        EleccionMotivoPrincipal: '',
        CambioInformacionIpae: 1,
        InformacionIpae: null,
        CambioEleccionCentroEstudio: 1,
        EleccionCentroEstudio: ''
      },
      rules:{
        sntrabajando: false,
        tipotrabajo: false,
        nombreemepresa: false,
        mes: false,
        anio: false,
        cargotrabajo: false,
        expectativas: false,
        PersonasVive: false,
        FinanciaEstudios: false,
        EleccionMotivoPrincipal: false,
        InformacionIpae: false,
        EleccionCentroEstudio: false,
      },

      sets:{
        primerset: false,
        segundoset: false,
        tercerset: false,
      }
    };
  },

  methods: {
    secltTrabjao(){
      this.data.tipotrabajo = null
      this.data.nombreemepresa = ''
      this.data.mes = null
      this.data.anio = null
      this.data.cargotrabajo = ''
    },
    consumirApi() {
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdTipoUsuario: store.user_type_usuario,
        Login: store.user_codigo,
        IdUltimaMatricula: store.user_matricula,
        IdUnidadNegocio: store.user_unidad_negocio,
        IdUnidadAcademica: store.user_unidad_academical,
        IdModulo: store.user_id_modulo,
        IdSede: store.user_id_sede
      }

      this.$store.dispatch("onboardingStore/paso1", formData).then(
        (response) => {
        if (response.success == true) {
          this.interes = response.results.ResLstInformacionIpae;
          var data = response.results
          this.data.PersonasVive = data.lstUsuarioPerfilZoom[0].PersonasVive
          this.data.FinanciaEstudios = data.lstUsuarioPerfilZoom[0].FinanciaEstudios
          this.data.EleccionMotivoPrincipal = data.lstUsuarioPerfilZoom[0].EleccionMotivoPrincipal
          this.data.InformacionIpae = data.lstUsuarioPerfilZoom[0].InformacionIpae
          this.data.EleccionCentroEstudio = data.lstUsuarioPerfilZoom[0].EleccionCentroEstudio
        }
      });

      this.$store.dispatch("perfilStore/getExpectativa").then(
        (response) => {
        if (response.success == true) {
          if(response.results.Mensaje == ""){
            this.data.expectativas = ""
          }else{
            var data = response.results.Mensaje
            this.data.expectativas = data
          }
        }
      });

      this.$store.dispatch("perfilStore/getTrabajo").then(
        (response) => {
        if (response.success == true) {
          if(response.results.Mensaje == ""){
            this.data.sntrabajando = 2
            this.data.tipotrabajo = null
            this.data.nombreemepresa = ''
            this.data.mes = null
            this.data.anio = null
            this.data.cargotrabajo = ''  
          }else{
            var data = response.results.Mensaje
            this.data.sntrabajando = 1
            this.data.tipotrabajo = data.IdTipoTrabajo
            this.data.nombreemepresa = data.NombreEmpresa
            this.data.mes = data.PeriodoMesInicio === '' ? null : data.PeriodoMesInicio
            this.data.anio = data.PeriodoAnnoInicio  === '' ? null : data.PeriodoAnnoInicio
            this.data.cargotrabajo = data.CargoNombre
          }
        }
      });
      
    },
    
    validarCampos(){

      let store = JSON.parse(localStorage.getItem('data'))

      if(this.data.sntrabajando === null) {
        this.rules.sntrabajando = true
      }else{
        this.rules.sntrabajando = false
      }

      if((this.data.sntrabajando === 1 || this.data.sntrabajando === '1') && this.data.tipotrabajo === null) {
        this.rules.tipotrabajo = true
      }else{
        this.rules.tipotrabajo = false
      }

      if((this.data.sntrabajando === 1 || this.data.sntrabajando === '1') && (this.data.nombreemepresa === null || this.data.nombreemepresa === '')) {
        this.rules.nombreemepresa = true
      }else{
        this.rules.nombreemepresa = false
      }

      if((this.data.sntrabajando === 1 || this.data.sntrabajando === '1') && this.data.mes === null) {
        this.rules.mes = true
      }else{
        this.rules.mes = false
      }

      if((this.data.sntrabajando === 1 || this.data.sntrabajando === '1') && this.data.anio === null) {
        this.rules.anio = true
      }else{
        this.rules.anio = false
      }

      if((this.data.sntrabajando === 1 || this.data.sntrabajando === '1') && (this.data.cargotrabajo === null || this.data.cargotrabajo === '')) {
        this.rules.cargotrabajo = true
      }else{
        this.rules.cargotrabajo = false
      }

      if(parseInt(store.user_unidad_negocio) === 1){
        if(this.data.expectativas === '' || this.data.expectativas === null) {
          this.rules.expectativas = true
        }else{
          this.rules.expectativas = false
        }
      }else{
        this.rules.expectativas = false
      }

      if(parseInt(store.user_unidad_negocio) === 1){

        if(this.data.PersonasVive === '' || this.data.PersonasVive === null) {
          this.rules.PersonasVive = true
        }else{
          this.rules.PersonasVive = false
        }
      }else{
        this.rules.PersonasVive = false
      }

      if(parseInt(store.user_unidad_negocio) === 1){
        if(this.data.FinanciaEstudios === '' || this.data.FinanciaEstudios === null) {
          this.rules.FinanciaEstudios = true
        }else{
          this.rules.FinanciaEstudios = false
        }
      }else{
        this.rules.FinanciaEstudios = false
      }

      if(this.data.EleccionMotivoPrincipal === '' || this.data.EleccionMotivoPrincipal === null) {
        this.rules.EleccionMotivoPrincipal = true
      }else{
        this.rules.EleccionMotivoPrincipal = false
      }

      if(this.data.InformacionIpae === null) {
        this.rules.InformacionIpae = true
      }else{
        this.rules.InformacionIpae = false
      }

      if(this.data.EleccionCentroEstudio === '' || this.data.EleccionCentroEstudio === null) {
        this.rules.EleccionCentroEstudio = true
      }else{
        this.rules.EleccionCentroEstudio = false
      }

      if( this.rules.sntrabajando === false && 
          this.rules.tipotrabajo === false && 
          this.rules.nombreemepresa === false && 
          this.rules.mes === false && 
          this.rules.anio === false && 
          this.rules.cargotrabajo === false && 
          this.rules.expectativas === false && 
          this.rules.PersonasVive === false && 
          this.rules.FinanciaEstudios === false && 
          this.rules.EleccionMotivoPrincipal === false && 
          this.rules.InformacionIpae === false && 
          this.rules.EleccionCentroEstudio === false ) {
            return true
          }else{
            return false
          }

    },

    send(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validates = this.validarCampos()

      if(validates == true){

        this.data.IdUsuario = store.user_id_usuario,
        this.data.IdActor = store.user_id_actor,
        this.data.Login = store.user_codigo

        let formOmbording = {
          IdUsuario: this.data.IdUsuario,
          IdActor: this.data.IdActor,
          CambioPersonasVive: this.data.CambioPersonasVive ,
          PersonasVive: this.data.PersonasVive ,
          CambioFinanciaEstudios: this.data.CambioFinanciaEstudios ,
          FinanciaEstudios: this.data.FinanciaEstudios ,
          CambioEleccionMotivoPrincipal: this.data.CambioEleccionMotivoPrincipal ,
          EleccionMotivoPrincipal: this.data.EleccionMotivoPrincipal ,
          CambioInformacionIpae: this.data.CambioInformacionIpae ,
          InformacionIpae: this.data.InformacionIpae ,
          CambioEleccionCentroEstudio: this.data.CambioEleccionCentroEstudio ,
          EleccionCentroEstudio: this.data.EleccionCentroEstudio ,
        }

        let formTrabajo = {
          IdActor: this.data.IdActor,
          CargoNombre: this.data.cargotrabajo,
          PeriodoMesInicio: this.data.mes,
          PeriodoAnnoInicio: this.data.anio,
          IdUsuario: this.data.IdUsuario,
          IdTipoTrabajo: this.data.tipotrabajo,
          NombreEmpresa: this.data.nombreemepresa
        }

        let formExpectativa = {
          IdUsuario: this.data.IdUsuario,
          IdActor: this.data.IdActor,
          Expectativas: this.data.expectativas
        }
        
        //primer set de envio para ombordgin
        this.$store.dispatch("onboardingStore/registropaso1", formOmbording).then(
          (response) => {
          if (response.success == true) {
            //segundo set para area trabajo
            this.$store.dispatch("perfilStore/setTrabajo",formTrabajo).then(
              (response) => {
              if (response.success == true) {
                 //segundo set para area expectativas
                 if(parseInt(store.user_unidad_negocio) === 1){
                  this.$store.dispatch("perfilStore/setExpectatica",formExpectativa).then(
                    (response) => {
                    if (response.success == true) {
                      this.$router.push({ name: 'alumnoValidarDatos' })
                    }
                  });
                 }else{
                   this.$router.push({ name: 'alumnoValidarDatos' })
                 }
              }
            });
          }
        });
      }
    },


    validarContent(){
      eventBus.$emit("bloquearLink");
    }
  },

  created() {
    this.consumirApi();
    this.validarContent()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>


<style>
@import "~@/assets/styles/global/_global.less";
</style>