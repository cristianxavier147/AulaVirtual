<template>
  <section class="bg-gray-100">
    <!-- Content-main -->
    <div class="pt-24 mx-auto md:w-3/5">
      <img v-if="classGeneral === 'purple'" src="@/assets/onboarding/alumnos/circle4-purple.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'red'" src="@/assets/onboarding/alumnos/circle4-red.svg" class="ml-2 md:ml-0" />
      <img v-if="classGeneral === 'blue'" src="@/assets/onboarding/alumnos/circle4-blue.svg" class="ml-2 md:ml-0" />
      <!-- Titulos - subtitulos -->
      <div class="mx-4 text-justify md:mx-0">
        <h1 class="pt-5 size-text-30 font-bold">Ya casi terminamos</h1>
        <p class="my-4 size-text-16 font-bold">
          Para que tus profesores y compañeros puedan identificarte de manera más rápida, te pedimos que subas una foto. Además, te pediremos otros datos.
        </p>
      </div>

      <div class="pb-8 mt-5">
        <!-- Form camera -->
        <form @submit.prevent="saveFile()" enctype="multipart/form-data">

          <div class="hcaja5 hcaja5-photo flex items-start mb-3 bg-white">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/photo.svg" alt="idat"/>
            </div>

            <div class="tm-r-bl w-full">
              <div class="relative">
                <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                  Escoge una foto para tu perfil
                </h1>
              </div>
            
              <!-- medio -->
              <div class="text-left ml-8">
                <span class="size-text-14 size-text-res-12 font-medium">Recuerda que esta foto es solo para fines sociales. </span>
              </div>
              <div class="flex mx-5 mb-0 mt-2">
                <div class="flex md:block lg:flex">
                    <div class="flex">
                        <label for="actual-btn"
                                class="ml-3 p-3 text-xs font-bold border border-gray-200 md:w-full text-left flex justify-start text-gray-400 items-center cursor-pointer" 
                                style="height: 50px;width:300px"
                        >{{this.formAvatar.NameFile | resumenTexto}}</label>
                        <input type="file" class="hidden" id="actual-btn" v-on:change="openModalPreview" accept=".jpg, .jpeg, .png">
                        <!-- <img src="@/assets/arrowUp.svg" alt="photo" class="relative right-10 md:w-5" /> -->
                    </div>
                  <button type="button" class="bt-avatar-res bg-gray-200 px-8 text-gray-800 size-text-14 size-text-res-12 font-medium " @click="openModalAvatar">Escoge un avatar</button>
                </div>
              </div>
              <div class="text-left" v-if="this.rules.foto == true">
                <span class="ml-5 md:ml-8 text-red size-text-12 font-bold">* Este campo es obligatorio </span>
              </div>
            </div>
          </div>

          <div class="hcaja1 hcaja1-cer flex items-start mb-3 bg-white" v-if="parseInt(store.user_unidad_negocio) === 1">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/photo.svg" alt="idat"/>
            </div>

            <div class="tm-r-bl w-full">
              <div class="relative">
                <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding">
                  Sube tu certificado de estudios por aquí
                </h1>
                <img v-if="classGeneral === 'purple'" class="absolute right-3 top-1" src="@/assets/global/info-purple.svg" alt="idat" @click="openModalExampleCertificado"/>
                <img v-if="classGeneral === 'red'" class="absolute right-3 top-1" src="@/assets/global/info-red.svg" alt="idat" @click="openModalExampleCertificado"/>
                <img v-if="classGeneral === 'blue'" class="absolute right-3 top-1" src="@/assets/global/info-blue.svg" alt="idat" @click="openModalExampleCertificado"/>
              </div>
              <!-- medio -->
              <div class="flex mx-5 my-3 text-left">
                <div>
                  <div class="text-left mb-2">
                    <span class="size-text-14 ml-3 size-text-res-12 font-medium">Formato: PDF o imagen legible. </span>
                    <br>
                     <span class="size-text-14 ml-3 size-text-res-12 font-medium"> Recuerda que es importante que tu certificado de estudios esté en buena calidad y sea legible.</span>
                  </div>
                  <div class="flex">
                    <label for="actual-btn-cert" class="ml-3 p-3 text-xs font-bold border border-gray-200 md:w-full text-left flex justify-start text-gray-400 items-center cursor-pointer" style="height: 50px;width:300px">{{this.formCertificado.NameFile | resumenTexto}}</label>
                    <input type="file" class="hidden" id="actual-btn-cert" v-on:change="openCertificado" accept=".jpg, .jpeg, .png, .pdf">
                    <img src="@/assets/svg/arrowUp.svg" alt="photo" class="relative right-10 md:w-5" />
                  </div>
                  <p class="size-text-12 font-medium pt-3 ml-3">*Si no cuentas con tu certificado ahora, no te preocupes, puedes adjuntarlo más adelante. </p>
                </div>
              </div>
            </div>
          </div>

          <!-- form celular en caso de emergencia -->
          <div class="hcaja4 hcaja4-2-r flex items-start mb-3 bg-white">
            <!-- SVG IMAGEN -->
            <div class="barra-lateral flex justify-center items-center">
              <img src="@/assets/svg/phone.svg" alt="idat" />
            </div>

            <div class="tm-r-bl w-full">
              <h1 class="flex my-5 pl-7 font-bold md:mt-4 md:mb-2 border-b pb-4 pt-2 w-auto border-cajas-onboarding text-left">
                Necesitamos un número de celular en caso de emergencia
              </h1>
              <!-- input ingresar celular -->
              <div class="md:flex ml-3">
                <input type="text" placeholder="Escribe su nombre completo" v-model="nombreemergencia" class="flex w-10/12 h-12 p-3 mb-1 ml-5 text-xs font-bold border md:w-2/6" />
                <input type="number" placeholder="Escribe un número de celular" v-model="numeroemergencia" class="flex w-10/12 h-12 p-3 ml-5 text-xs font-bold border md:w-2/6" />
              </div>
              <div class=" text-left" >
                <span class="ml-5 md:ml-8 text-red size-text-12 font-bold" v-if="this.rules.nombremergencia === true || this.rules.numeroemergencia === true">* Estos campos son obligatorios </span>
                <span class="ml-5 md:ml-8 text-red size-text-12 font-bold" v-if="this.rules.cantnumeroemergencia === true">* No tiene los dígitos necesarios</span>
              </div>
            </div>
          </div>

          <!-- botones -->
          <div class="mt-5 md:flex md:justify-end md:mt-2">
            <!-- botton anterior -->
            <div class="md:block" v-if="omitir == 0">
              <router-link to="/alumnos/onboarding/continuar">
                <button type="button" class="w-11/12 h-12 my-4 font-medium text-black bg-gray-300 rounded-lg md:w-40">
                  Anterior
                </button>
              </router-link>
            </div>

            <!-- botton siguiente -->
            <div class="md:ml-5">
              <button type="submit" class="w-11/12 h-12 text-white rounded-lg md:w-60 md:my-4" :class="'bt-' + classGeneral ">
                Guardar y continuar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <ModalPreviewPhoto v-if="modalPreview" @closeModal="closeModalPreviewPhoto" :img="this.img" />
    <ModalPreviewAvatar v-if="modalAvatar" @saveAvatar="closeModalPreviewAvatar" @closeModal="closeModalAvatar"/>

    <ModalPreviewExampleCertificado v-if="modalexamplecertificado" @closeModal="closeModalPreviewExampleCertificado" />

    <ModalFechaCertificado v-if="modalfecha" />
  </section>
</template>

<script>
import ModalPreviewPhoto from "@/components/Alumnos/Onboarding/Modal/ModalPreviewPhoto";
import ModalPreviewAvatar from "@/components/Alumnos/Onboarding/Modal/ModalAvatar";
import ModalPreviewExampleCertificado from "@/components/Alumnos/Onboarding/Modal/ModalPreviewExampleCertificado";
import ModalFechaCertificado from "@/components/Alumnos/Onboarding/Modal/ModalFechaCertificado";

export default {
  data() {
    return {
      modalPreview: false,
      modalAvatar: false,
      modalfecha: false,
      nameFilePhoto: 'Adjunta aquí',
      valornumerico : 1,
      nameFileCertificado: 'Adjunta aquí',
      modalexamplecertificado:false,
      omitir: 0,
      nombreemergencia: '',
      numeroemergencia: '',
      formAvatar:{
        BytesFoto: '',
        NameFile: 'Adjunta aquí',
        Ext: '',
        IdActor: '',
        Login: ''
      },
      formCertificado:{
        BytesFoto: '',
        NameFile: 'Adjunta aquí',
        Ext: '',
        IdActor: '',
        Login: ''
      },
      rules:{
        foto: false,
        nombremergencia: false,
        numeroemergencia: false,
        cantnumeroemergencia: false
      },
      sets:{
        primerset: false,
        segundoset: false,
        tercerset: false,
      },
      img: null
    }
  },

  components: {
    ModalPreviewPhoto,
    ModalPreviewAvatar,
    ModalPreviewExampleCertificado,
    ModalFechaCertificado
  },

  methods: {
    reviewOmitir(){
      let store = JSON.parse(localStorage.getItem('data'))
      let formData = {
        IdActor: store.user_id_actor,
        IdUsuario: store.user_id_usuario,
        IdTipoUsuario: store.user_type_usuario,
        Login: store.user_codigo,
        IdUltimaMatricula: store.user_matricula,
        IdUnidadNegocio: store.user_unidad_negocio,
        IdUnidadAcademica: store.user_unidad_academica,
        IdModulo: store.user_id_modulo,
        IdSede: store.user_id_sede
      }

      this.$store.dispatch("onboardingStore/paso1", formData).then(
        (response) => {
        if (response.success == true) {
          var data = response.results
          this.omitir = data.lstUsuarioPerfilZoom[0].Disponible3 == null ? 0 : parseInt(data.lstUsuarioPerfilZoom[0].Disponible3)
        }
      });
    },
    openModalPreview(e){
      let store = JSON.parse(localStorage.getItem('data'))
      this.modalPreview = true
      var fileReader = new FileReader()
      fileReader.readAsDataURL(e.target.files[0])
      fileReader.onload = (e) => {
          this.img =  fileReader.result
      }
      const file = e.target.files[0].name
      const type = e.target.files[0].type
      this.formAvatar.NameFile=  file
      this.formAvatar.Ext = type
      this.formAvatar.IdActor = store.user_id_actor
      this.formAvatar.Login = store.user_codigo
    },
    closeModalPreviewPhoto(content){
      this.formAvatar.BytesFoto = content
      this.modalPreview = false
    },
    openModalAvatar(){
      this.modalAvatar = true
    },
    closeModalPreviewAvatar(item){
      let store = JSON.parse(localStorage.getItem('data'))
      this.modalAvatar = false
      this.formAvatar.BytesFoto = item.img
      this.formAvatar.Ext = 'image/png'
      this.formAvatar.NameFile=  item.name
      this.formAvatar.IdActor = store.user_id_actor
      this.formAvatar.Login = store.user_codigo
    },

    openCertificado(e){
      let store = JSON.parse(localStorage.getItem('data'))
      var fileReader = new FileReader()
      fileReader.readAsDataURL(e.target.files[0])
      fileReader.onload = (e) => {
          this.formCertificado.BytesFoto = e.target.result
      }
      const file = e.target.files[0].name
      const type = e.target.files[0].type
      this.formCertificado.NameFile=  file
      this.formCertificado.Ext = type
      this.formCertificado.IdActor = store.user_id_actor
      this.formCertificado.Login = store.user_codigo
    },
    openModalExampleCertificado(){
      this.modalexamplecertificado = true
    },
    closeModalPreviewExampleCertificado(){
      this.modalexamplecertificado = false
    },

    validarCampos(){
      if(this.formAvatar.Ext === null || this.formAvatar.Ext === "") {
        this.rules.foto = true
      }else{
        this.rules.foto = false
      }

      if(this.nombreemergencia === null || this.nombreemergencia === "") {
        this.rules.nombremergencia = true
      }else{
        this.rules.nombremergencia = false
      }

      if(this.numeroemergencia === null || this.numeroemergencia === "") {
        this.rules.numeroemergencia = true
      }else{
        this.rules.numeroemergencia = false
      }

      if(this.numeroemergencia.length < 9){
        this.rules.cantnumeroemergencia = true
      }else{
        this.rules.cantnumeroemergencia = false
      }

      if( this.rules.foto === false && this.rules.nombremergencia === false && this.rules.numeroemergencia === false && this.rules.cantnumeroemergencia === false) {
        return true
      }else{
        return false
      }
    },

    saveFile(){
      let store = JSON.parse(localStorage.getItem('data'))
      var validate = this.validarCampos()
      if(validate === true){
        let formData = {
          IdUsuario:  store.user_id_usuario,
          IdActor:  store.user_id_actor,
          NombreEmergencia:  this.nombreemergencia,
          NumeroEmergencia:  this.numeroemergencia
        }
         //primer set de envio de foto
        this.$store.dispatch("perfilStore/guardarFoto", this.formAvatar).then(
          (response) => {
          if (response.success == true) {
            if(this.formCertificado.BytesFoto === ''){
              this.$store.dispatch("onboardingStore/registro_Paso_4",formData).then(
                (response) => {
                if (response.success == true) {
                  if(this.formCertificado.Ext === ''){
                    if(parseInt(store.user_unidad_negocio) === 1){
                      this.modalfecha = true
                    }else{
                      this.$router.push({ name: 'alumnoPassword' })  
                    }
                  }else{
                    this.$router.push({ name: 'alumnoPassword' })
                  }
                }
              });
            }else{
              this.$store.dispatch("perfilStore/guardarDocumento",this.formCertificado).then(
                (response) => {
                if (response.success == true) {
                  //segundo set para phone
                  this.$store.dispatch("onboardingStore/registro_Paso_4",formData).then(
                    (response) => {
                    if (response.success == true) {
                      this.$router.push({ name: 'alumnoPassword' })
                    }
                  });
                }
              });
            }
          }
        });
      }
    },
    closeModalAvatar(){
      this.modalAvatar = false
    }
  },

  filters: {
    resumenTexto(value){
      return value.slice(0,30)+'...';
    }
  },

  computed:{
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },

  created() {
    this.reviewOmitir()
  },
}
</script>

