<template>
  <div class="overlay">
    <div class="p-12 bg-white rounded-md" style="width:404px" v-if="omitir <= 2">
        <div class="mb-8 size-text-20 font-bold text-left">Necesitamos tus datos</div>
        <div class="size-text-12 font-bold text-left mb-1">La vez pasada no pudiste darnos tu teléfono ni tu mail.</div>
        <div class="size-text-12 font-medium text-left mb-5">Este paso es necesario para poder continuar, si todavía no cuentas con la información pedida puedes omitir una vez más. </div>
        <div class="size-text-12 text-gray-400 font-bold text-left mb-5">{{this.omitir}} de 2 veces omitidas.</div>
        <div class="text-left mb-5">
            <span @click="omitirButton" v-if="omitir <= 2" class="font-bold border-b  cursor-pointer" :class="'text-' + classGeneral + ' ; brdr-' + classGeneral">
                Omitir este paso
            </span>
        </div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Completar datos</button>
    </div>
    <div class="p-12 bg-white rounded-md" style="width:404px" v-if="omitir == 3">
        <div class="mb-8 size-text-20 font-bold text-left">Necesitamos tus datos</div>
        <div class="size-text-12 font-bold text-left mb-1">Ya omitiste 2 veces el paso para darnos tu teléfono y tu mail.</div>
        <div class="size-text-12 font-medium text-left mb-5">Este paso es necesario para poder continuar.</div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Completar datos</button>
    </div>
  </div>
</template>

<script>
export default {
    props: ['omitir'],
    name: "ModalOmitir",
    methods: {
        save(){
            this.$emit('closemodal',true)
        },

        omitirButton(){
            this.$emit('omitir',true)
        }
    },
    computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
