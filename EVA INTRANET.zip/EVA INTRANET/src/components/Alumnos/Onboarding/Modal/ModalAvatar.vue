<template>
  <div class="overlay">
    <div class="modal-res p-10 bg-white rounded-md text-left" style="width:404px">
        <div class="relative">
          <p class="size-text-20 font-bold">Escoge un avatar</p>
          <span class="absolute right-0 -top-2 cursor-pointer" @click="closeModal">x</span>
        </div>
        <div class="cont-modal-r py-5">
            <div class="grid grid-cols-4">
                <div class="contavatar" v-if="classGeneral === 'purple'">
                  <img id="idat" src="@/assets/avatar/idat.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('idat')">
                  <img id="slidat" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar" v-if="classGeneral === 'red'">
                  <img id="zegel" src="@/assets/avatar/zegel.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('zegel')">
                  <img id="slzegel" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar" v-if="classGeneral === 'blue'">
                  <img id="corriente" src="@/assets/avatar/corriente.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('corriente')">
                  <img id="slcorriente" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="tablet" src="@/assets/avatar/tablet.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('tablet')">
                  <img id="sltablet" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="manzana" src="@/assets/avatar/manzana.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('manzana')">
                  <img id="slmanzana" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="taza" src="@/assets/avatar/taza.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('taza')">
                  <img id="sltaza" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="libros" src="@/assets/avatar/libros.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('libros')">
                  <img id="sllibros" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="mundo" src="@/assets/avatar/mundo.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('mundo')">
                  <img id="slmundo" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="buho" src="@/assets/avatar/buho.png" alt="" class="col-span-1 py-3 px-3 cl-avatar " @click="selectAvatar('buho')">
                  <img id="slbuho" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
                <div class="contavatar">
                  <img id="avatar" src="@/assets/avatar/avatar.png" alt="" class="col-span-1 py-3 px-3" @click="selectAvatar('avatar')">
                  <img id="slavatar" src="@/assets/avatar/select.png" class="sl-avatar">
                </div>
            </div>
        </div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Escoger y guardar</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "SolicitudCorrecta",
  data() {
    return {
      img : '',
      select: '',
      name: ''
    }
  },
  methods: {
    save(){
      let form = {
        img: this.img,
        name: this.select
      }
      this.$emit('saveAvatar',form)
    },

    selectAvatar(item){
      let img = document.getElementById(item) 
      let sl = document.getElementById('sl'+item)
      sl.classList.add('select')

      if(this.select !== ''){
        let vl = document.getElementById('sl'+this.select)
        vl.classList.remove('select')
      }

      this.img = img.src
      this.select = item
      this.name = item+'.png'
    },

    closeModal(){
      this.$emit('closeModal',true)
    }
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  }
};
</script>

<style></style>
