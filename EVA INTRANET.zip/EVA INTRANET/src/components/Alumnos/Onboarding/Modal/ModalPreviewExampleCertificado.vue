<template>
  <div class="overlay">
    <div class=" modal-res bg-white rounded-md" style="width:649px">
        <div class="text-right px-10 pt-5 cursor-pointer" @click="save">
            x
        </div>
        <div class="cont-modal-r-cer px-10 py-2 text-left">
            <p class="size-text-20 font-bold mb-5">Certificado de estudios</p>
            <div class="mb-5">
              <p class="size-text-12 font-bold">¿Qué es un certificado de estudios?</p>
              <span class="size-text-12 font-medium">Es el documento que acredita que has culminado tus estudios secundarios con nota aprobatoria y que puedes estudiar una carrera para obtener un título a nombre de la nación. </span>
            </div>
            <div>
              <p class="size-text-12 font-bold">¿Cómo lo obtengo?</p>
              <span class="size-text-12 font-medium">A través de tu colegio o UGEL. Asimismo, durante la pandemia el MNEDU está entregando el certificado de manera virtual a los egresados registrados en el SAGIE. </span>
            </div>
            <div class="py-5">
              <img src="@/assets/global/exampleCertificado.svg" alt="">
            </div>
        </div>
        <button id="btncer" class="text-white size-text-16 font-medium py-4 rounded-md w-full hidden" :class="'bt-'+classGeneral" @click="save">Escoger y guardar</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "SolicitudCorrecta",
  methods: {
    save(){
      this.$emit('closeModal',false)
    }
  },
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  }
};
</script>

<style></style>
