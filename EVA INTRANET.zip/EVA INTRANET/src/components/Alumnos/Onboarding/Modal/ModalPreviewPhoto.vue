<template>
  <div class="overlay">
    <div class="p-10 bg-white rounded-md" style="width:600px">
		<div class="size-text-12 text-left py-5">
			<span class="font-bold">Indicaciones:</span>
			<br>
			<span>- Arrastra la imagen con puntero.</span>
			<br>
			<span>- Acerca o aleja la imagen haciendo scroll.</span>
		</div>
		<div class="mb-5">
			<cropper
				:src="img"
				ref="cropper"
				:stencil-props="{
					handlers: {},
					movable: false,
					scalable: false,
				}"
				:stencil-size="{
					width: 280,
					height: 280
				}"
				image-restriction="stencil"
				stencil-component="circle-stencil"
			/>
		</div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="crop">Recortar y guardar</button>
    </div>
  </div>
</template>

<script>
import { CircleStencil , Cropper } from 'vue-advanced-cropper';
import 'vue-advanced-cropper/dist/style.css';
export default {
	props: ['img'],
  	name: "SolicitudCorrecta",
	data() {
		return {
			image: null,
			coordinates: {
				width: 0,
				height: 0,
				left: 0,
				top: 0,
			}
		}
	},
	components:{
		Cropper,
		CircleStencil
	},
	methods: {
		save(){
			this.$emit('closeModal',this.image)
		},
		crop(){
			const { coordinates, canvas, } = this.$refs.cropper.getResult();
			this.coordinates = coordinates;
			this.image = canvas.toDataURL();
			this.save()
		}
	},
	computed: {
		classGeneral(){
			return localStorage.getItem('classGeneral')
		}
	}
};
</script>

<style></style>
