<template>
  <div class="overlay">
    <div class="p-12 bg-white rounded-md" style="width:404px" >
        <div class="mb-8 size-text-20 font-bold text-left relative">
            <span> Verificación </span> 
            <span class="absolute right-0 cursor-pointer" style="color: #616161" @click="closeModal"> x </span>
        </div>
        <div class="size-text-12 font-bold text-left mb-1">Hemos enviado un SMS al número que nos diste.</div>
        <div class="size-text-12 font-medium text-left mb-5">Para confirmar que el número es correcto, indícanos el código de verificación que recibiste.</div>
        <div class="size-text-12 text-gray-400 font-bold text-left mb-5">
            Si no recibes el mensaje en 01:00, haz 
            <span @click="sendCodigo" class="font-bold border-b  cursor-pointer" :class="'text-' + classGeneral + ' ; brdr-' + classGeneral"> click aquí </span> 
            para enviar de nuevo.
        </div>
        <div class="mb-4">
            <div class="grid grid-cols-6">
                <input v-model="data1" @keyup="focus(2)" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
                <input v-model="data2" id="input2" @keyup="focus(3)" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
                <input v-model="data3" id="input3" @keyup="focus(4)" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
                <input v-model="data4" id="input4" @keyup="focus(5)" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
                <input v-model="data5" id="input5" @keyup="focus(6)" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
                <input v-model="data6" id="input6" type="text" pattern="[0-9]+" maxlength="1" class="col-span-1 border-b-2 border-t-0 border-l-0 border-r-0 border-gray-500 mx-1 h-10 rounded-none text-center size-text-25" />
            </div>
        </div>
        <div class="text-left relative mb-3" style="height: 20px">
            <span class="text-red-500 text-size-12 absolute top-0" v-if="errorContent">* Debes completar todos los cuadros.</span>
            <span class="text-red-500 text-size-12 absolute top-0" v-if="errorCodigo">* {{message}}.</span>
        </div>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Completar datos</button>
    </div>
  </div>
</template>

<script>
export default {
    props: ['IdProgramacionDilo','phone'],
    name: "CambioContrasena",
    data() {
        return {
            data1: '',
            data2: '',
            data3: '',
            data4: '',
            data5: '',
            data6: '',
            errorContent: false,
            errorCodigo: '',
            message: ''
        }
    },
    methods: {
        focus(type){
            document.getElementById('input'+type).focus()
        },
        save(){
            let store = JSON.parse(localStorage.getItem('data'))
            if(this.data1 == "" && this.data2 == "" && this.data3 == "" && this.data4 == "" && this.data5 == "" && this.data6 == "" ){
                this.errorContent = true
            }else{
                let formValidar = {
                    IdUsuario : store.user_id_usuario,
                    CodigoDigitado : this.data1+this.data2+this.data3+this.data4+this.data5+this.data6
                }

                this.$store.dispatch("onboardingStore/getTelefonoValidar",formValidar).then(
                    (response) => {
                        if (response.success == true) {
                            if(store.user_type_usuario === "1"){
                                this.$router.push({ name: 'alumnoFotoUsuario' })
                            }else{
                                this.$router.push({ name: 'docenteFotoUsuario' })
                            }
                        }else{
                            this.message = response.msg
                            this.refreshCodigo()
                        }
                });
            }
        },

        sendCodigo(){
            let store = JSON.parse(localStorage.getItem('data'))
            let formValidar = {
                IdUsuario : store.user_id_usuario,
                Login : store.user_codigo,
                IdProgramacionDilo : this.IdProgramacionDilo,
                IdTipoUsuario : store.user_type_usuario,
                Telefono: this.phone
            }

            this.$store.dispatch("onboardingStore/setTelefonoValidar",formValidar).then(
              (response) => {
              if (response.success == true) {
                this.refreshCodigo()
              }
            });
        },

        refreshCodigo(){
            this.data1 = ''
            this.data2 = ''
            this.data3 = ''
            this.data4 = ''
            this.data5 = ''
            this.data6 = ''
        },

        closeModal(){
            this.$emit('closeModal',true)
        }
    },

    computed: {
        store(){
            return JSON.parse(localStorage.getItem('data'))
        },

        classGeneral(){
            return localStorage.getItem('classGeneral')
        }
    },
};
</script>

<style></style>
