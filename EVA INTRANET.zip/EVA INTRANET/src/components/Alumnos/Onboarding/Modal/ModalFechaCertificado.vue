<template>
  <div class="overlay">
    <div class="p-10 bg-white rounded-md text-left" style="width:404px">
        <div class="mb-8 size-text-20 font-bold text-left">Certificado de estudios</div>
        <p class="size-text-12 font-bold">
            No has adjuntado el certificado de estudios.
        </p>
        <p  class="size-text-12 font-medium">
            Queremos saber qué día te comprometes a adjuntarlo en nuestro sistema.
        </p>
        <br>
        <p class="size-text-12 text-gray-400 font-bold">
            Recuerda que realizar este paso es obligatorio.
        </p>
        <br>
        <span class="datepicker-toggle w-full mb-5">
            <div class="relative w-full">
                <input type="text" placeholder="Elige una fecha" class="w-full pl-2" v-model="fechaselect" :class="this.rules.fecha == true ? 'border-red-600' : ''">
                <img src="@/assets/global/selectPurple.svg" alt="photo" class="datepicker-toggle-button" />
            </div>
            <input id="date" type="date" class="datepicker-input" @change="prueba">
        </span>
        <button class="text-white size-text-16 font-medium py-4 rounded-md w-full" :class="'bt-'+classGeneral" @click="save">Guardar</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "SolicitudCorrecta",
  data() {
      return {
          fechaselect: '',
          rules:{
              fecha: false
          }
      }
  },
  methods: {
    validates(){
        if(this.fechaselect === null || this.fechaselect === "") {
            this.rules.fecha = true
        }else{
            this.rules.fecha = false
        }

        if( this.rules.fecha === false) {
            return true
        }else{
            return false
        }
    },
    save(){
      let store = JSON.parse(localStorage.getItem('data'))
      let validate = this.validates()

      if(validate === true){
        var formData = {
            IdUsuario:  store.user_id_usuario,
            IdActor:  store.user_id_actor,
            FechaDocumento : this.fechaselect
        }

        this.$store.dispatch("onboardingStore/setFechaDocumento",formData).then(
          (response) => {
          if (response.success == true) {
            this.$router.push({ name: 'alumnoPassword' }).catch(()=>{})
          }
        });

      }
    },
    prueba(){
        var id = document.getElementById('date')
        this.fechaselect = id.value
    }
  },
  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  }
};
</script>

<style>
.datepicker-toggle {
  display: inline-block;
  position: relative;
}
.datepicker-toggle-button {
  position: absolute;
  right: 20px;
  top: 25px;
}
.datepicker-input {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
  box-sizing: border-box;
}
.datepicker-input::-webkit-calendar-picker-indicator {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  cursor: pointer;
}
</style>
