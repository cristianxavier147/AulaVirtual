<template>
  <div class="pb-32">
    <h1 class="font-bold text-lg mb-10 flex md:bg-gray-100 bg-white h-14  md:border-b-0 border-b-4 pt-3 pl-4">
      Recursos
    </h1>
    <!-- cards 1-2 -->
    <div class="md:flex gap-7 mr-10 w-full md:w-11/12">
      <!-- card-1 -->
      <div class="bg-white mt-5 md:mt-0 pb-5">
        <img src="@/assets/png/bibliotecaVirtual.png" alt="clases" class="w-full" />
        <div class="flex mt-8 mx-4">
          <img src="@/assets/biblioteca/pc.svg" alt="bibliotecaVirtual" class="mr-2" />
          <span class="text-xs font-bold my-auto">Biblioteca Virtual</span>
        </div>
        <h2 class="p-5 text-xs text-left h-24">
          Aquí encontrarás plataformas con información bibliográfica a texto completo, con opción a lectura online y off line, descargas, impresiones, entre otras opciones.
        </h2>
        <button class="w-11/12 mx-auto block md:mt-3 text-white h-12 rounded-md font-medium" :class="'bt-'+classGeneral">
          Ir a Biblioteca Virtual
        </button>
      </div>

      <!-- card-2 -->
      <div class="bg-white mt-5 md:mt-0 pb-5">
        <img src="@/assets/svg/catalogolinea.svg" alt="clases" class="w-full" />
        <div class="flex mt-3 mx-4">
          <img src="@/assets/biblioteca/nube.svg" alt="bibliotecaVirtual" class="mr-2" />
          <span class="text-xs font-bold my-auto">Catálogo en línea</span>
        </div>
        <h2 class="p-5 text-xs text-left h-24">
          Aquí podrás buscar y acceder a todos los recursos bibliográficos físicos con los que contamos en el Centro de Información (libros, revistas, tesis, proyectos, material multimedia, etc.)
        </h2>
        <button class="w-11/12 mx-auto block md:mt-2 text-white h-12 rounded-md font-medium" :class="'bt-'+classGeneral">
          Ir al catálogo en línea
        </button>
      </div>
    </div>
    <!-- card 3-4 -->
    <div class="md:flex mt-5 gap-7">
      <!-- card-3 -->
      <div class="md:w-80 bg-white pb-7 mb-5 md:mb-0">
        <img src="@/assets/svg/recursoslibres.svg" alt="clases" class="w-full" />
        <div class="flex mt-3 mx-4">
          <img src="@/assets/biblioteca/usuario.svg" alt="bibliotecaVirtual" class="mr-2" />
          <span class="text-xs font-bold my-auto">Recursos libres</span>
        </div>
        <h2 class="p-5 text-xs text-left h-24">
          Aquí encontrarás los recursos virtuales de libre acceso.
        </h2>
        <button class="w-11/12 mx-auto block md:mt-2 text-white h-12 rounded-md font-medium" :class="'bt-'+classGeneral">
          Ir a recursos libres
        </button>
      </div>
      <!-- card-4 -->
      <div class="md:w-80 md:mr-11 bg-white pb-7">
        <img src="@/assets/svg/tutoriales.svg" alt="tutoriales" class="w-full" />
        <div class="flex mt-3 mx-4">
          <img src="@/assets/biblioteca/i.svg" alt="bibliotecaVirtual" class="mr-2" />
          <span class="text-xs font-bold my-auto">Tutoriales</span>
        </div>
        <h2 class="p-5 text-xs text-justify h-24">
          Sección de videos instructivos donde conocerás como acceder y manejar diferentes estrategias de búsquedas de las plataformas de la Biblioteca virtual y catálogo en línea.
        </h2>
        <button class="w-11/12 mx-auto block md:mt-2 text-white h-12 rounded-md font-medium" :class="'bt-' + classGeneral ">
          Ir a tutoriales
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BibliotecaContent",
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
