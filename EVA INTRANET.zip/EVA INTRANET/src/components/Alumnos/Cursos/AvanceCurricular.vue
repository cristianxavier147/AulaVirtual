<template>
  <div>
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div class="mb-5 text-left title-nivel">
        <span class="text-xl font-bold">Nivel: {{ ciclo }}</span>
      </div>
      <div>
        <div class="scroll-horizontal">
          <table class="table w-full">
            <thead class="bg-white">
              <tr>
                <th class="p-2 font-bold text-gray-400 size-text-12">Código curso</th>
                <th class="p-2 font-bold text-left text-gray-400 size-text-12">Nombre curso</th>
                <th class="p-2 font-bold text-gray-400 size-text-12">Crédito</th>
                <th class="p-2 font-bold text-gray-400 size-text-12"># de veces</th>
                <th class="p-2 font-bold text-gray-400 size-text-12">Nota</th>
                <th class="p-2 font-bold text-gray-400 size-text-12">Ciclo</th>
                <th class="p-2 font-bold text-gray-400 size-text-12">Estado</th>
                <th class="p-2 font-bold text-gray-400 size-text-12">Syllabus</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in content" :key="index">
                <td class="p-3 font-bold size-text-10">{{ item.CursoCodigo }}</td>
                <!-- <td class="p-3 font-bold text-left underline size-text-10" :class="'text-' + classGeneral + '-600'" v-if="item.EstadoNombre != 'PENDIENTE'">
                  <router-link :to="{ name: 'cursosAnvanceCurricularDetalle', params: { slug: item.CursoNombre }, query: { id_seccion: item.IdSeccion } }" exact>
                    <span>{{ item.CursoNombre }}</span>
                  </router-link>
                </td> -->
                <td class="p-3 font-bold text-left underline size-text-10" :class="'text-' + classGeneral + '-600'">
                  <span>{{ item.CursoNombre }}</span>
                </td>
                <td class="p-3 font-bold size-text-10">{{ item.CursoCredito }}</td>
                <!-- <td class="p-3 font-bold size-text-10" v-else-if="item.St">-</td> -->
                <td class="p-3 font-bold size-text-10">{{ item.NumVezCurso }}</td>

                <td v-if="isNaN(item.PromedioFinal)" class="p-3 text-xs font-bold">0</td>
                <td v-else class="p-3 text-xs font-bold">{{ Number(item.PromedioFinal).toFixed(2) }}</td>
                <td class="p-3 font-bold size-text-10">{{ item.PeriodoCodigo }}</td>
                <td class="p-3 font-bold size-text-10">{{ item.EstadoNombre }}</td>
                <!-- <td v-if="item.TipoCondicion === 'RE'" class="p-3 font-bold size-text-10">PROMOVIDO</td>
                <td v-else-if="item.TipoCondicion === 'CC'" class="p-3 font-bold size-text-10">CURSO REPITENCIA</td>
                <td v-else-if="item.TipoCondicion === 'RT'" class="p-3 font-bold size-text-10">REPITENCIA</td>
                <td v-else-if="item.TipoCondicion === 'RP'" classT="p-3 font-bold size-text-10">PROMOVIDO + CURSO</td> -->
                <td class="p-3 font-bold size-text-10">-</td>
              </tr>
              <!-- <tr>
                <td></td>
                <td class="flex ml-2 text-xs">Total de créditos</td>
                <td class="text-xs">{{ sumCreditos }}</td>
              </tr> -->
            </tbody>
            <tr class="font-bold">
              <td></td>
              <td class="flex ml-2 text-xs credist">Total de créditos</td>
              <td class="py-3 text-xs">{{ sumCreditos }}</td>
            </tr>
          </table>
        </div>
        <div class="scroll-horizontal" v-if="valor !== null">
          <table class="table w-full">
            <!-- <thead class="bg-white">
                <tr>
                  <th class="p-2 font-bold text-gray-400 size-text-12">Indicadores</th>
                  <th class="p-2 font-bold text-left text-gray-400 size-text-12">Matricula</th>
                  <th class="p-2 font-bold text-left text-gray-400 size-text-12">Datos del alumno</th>
                  <th class="p-2 font-bold text-left text-gray-400 size-text-12">Ponderado</th>
                  <th class="p-2 font-bold text-left text-gray-400 size-text-12">Orden de Mérito</th>
                </tr>
              </thead> -->
            <!-- <tbody>
                <tr>
                  <td class="px-3 pt-1 font-bold text-gray-400 size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4">Asist.</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Acade.</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-1 font-bold text-left text-gray-400 size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4">Estado</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Condición</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-1 font-bold text-left text-gray-400 size-text-10">
                    <div class="grid grid-cols-5">
                      <div class="col-span-3">
                        <span class="block mb-4">Producto</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Semestre</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Sección</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-1 font-bold text-left text-gray-400 size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4">Actual</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Acumulado</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-1 font-bold text-left text-gray-400 size-text-10">
                    <div class="grid grid-cols-3">
                      <div class="col">
                        <span class="block mb-4">Sección</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Semestre</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">Producto</span>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td class="px-3 pt-0 pb-3 size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4"></span>
                      </div>
                      <div class="col">
                        <span class="block mb-4"></span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-0 pb-3 text-left size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4">{{ valor.Estado }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.TipoCondicionNombre }}</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-0 pb-3 text-left size-text-10">
                    <div class="grid grid-cols-5">
                      <div class="col-span-3">
                        <span class="block mb-4">{{ valor.CurriculaNombre }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.Descripcion }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.GrupoCodigo }}</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-0 pb-3 text-left size-text-10">
                    <div class="grid grid-cols-2">
                      <div class="col">
                        <span class="block mb-4">{{ valor.PonderadoActual === "-1" || valor.PonderadoActual === -1 ? "-" : valor.PonderadoActual }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.PonderadoAcumulado === "-1" || valor.PonderadoAcumulado === -1 ? "-" : valor.PonderadoAcumulado }}</span>
                      </div>
                    </div>
                  </td>
                  <td class="px-3 pt-0 pb-3 text-left size-text-10">
                    <div class="grid grid-cols-3">
                      <div class="col">
                        <span class="block mb-4">{{ valor.OrdenMeritoSeccion === "-1" || valor.OrdenMeritoSeccion === -1 ? "-" : valor.OrdenMeritoSeccion }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.OrdenMeritoPromocion === "-1" || valor.OrdenMeritoPromocion === -1 ? "-" : valor.OrdenMeritoPromocion }}</span>
                      </div>
                      <div class="col">
                        <span class="block mb-4">{{ valor.OrdenMeritoProducto === "-1" || valor.OrdenMeritoProducto === -1 ? "-" : valor.OrdenMeritoProducto }}</span>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody> -->
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    ciclo: String,
    content: Array,
    valor: Object,
    cargaPreloader: true,
  },

  data() {
    return {
      preloader: false,
    };
  },

  computed: {
    classGeneral() {
      return localStorage.getItem("classGeneral");
    },

    store() {
      return JSON.parse(localStorage.getItem("data"));
    },
    sumCreditos() {
      let arr = this.content.map((x) => Number(x.CursoCredito));
      return arr.reduce((a, b) => a + b);
    },
  },
};
</script>
<style>
td {
  border-right: 1px solid #ffffff;
}

.credist {
  border: none;
}

td:last-child {
  border: none;
}
tbody::before {
  content: none;
}
</style>
