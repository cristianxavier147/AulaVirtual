import { Bar } from './BaseCharts'
import { reactiveProp } from '@/mixins/chart'

export default {
  extends: Bar,
  mixins: [reactiveProp],
  data: () => ({
    options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
            display: false
        },
        scales: {
          yAxes: [{
            ticks: {
              max: 20,
              min: 0,
              stepSize: 5
            },
          }],
          xAxes: [{
            gridLines : {
              display : false
            }
        }],
        },
    },
  }),
  mounted () {
    this.renderChart(this.chartData, this.options)
  }
}