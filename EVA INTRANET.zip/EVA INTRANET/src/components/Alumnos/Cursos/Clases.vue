<template>
  <div class="mb-28">
    <div class="mt-8" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div class="block w-full grid-cols-4 px-5 mb-3 md:grid lg:grid md:p-0 lg:p-0">
        <div class="col-span-1 mb-3 text-left">
          <span class="pl-1 font-bold size-text-12">Actualmente estás en la semana {{ estoy }} de {{ total }}</span>
        </div>
        <div class="flex items-center justify-center w-full col-span-3 mb-3">
          <div class="w-full col-span-2 rounded-md" style="background: #EAEAEA">
            <div :class="'fnd-' + classGeneral" class="rounded-md" style="height: 10px" :style="'width:' + tme + '%'"></div>
          </div>
        </div>
      </div>
      <iframe :src="moodle == '' ? moddle : moodle" width="100%" height="800px" />
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { eventBus } from "@/config/eventBus";
export default {
  data() {
    return {
      tme: "",
      total: "",
      estoy: "",
      moddle: "",
      preloader: true,
    };
  },

  computed: {
    ...mapState("sidebarStore", ["moodleState"]),
    moodle() {
      return this.moodleState
    },
    classGeneral() {
      return localStorage.getItem("classGeneral");
    },

    store() {
      return JSON.parse(localStorage.getItem("data"));
    },
  },

  methods: {
    allData() {
      let store = JSON.parse(localStorage.getItem("data"));

      this.preloader = true;
      var formdata = {
        IdTipoUsuario: store.user_type_usuario,
        IdSeccion: this.$route.query.id_seccion,
        CodigoAlumno: store.user_codigo,
      };

      this.$store.dispatch("cursoStore/informacioncurso", formdata).then((response) => {
        if (response.success == true) {
          let data = response.results;
          this.tme = data.PorcentajeCompletado;
          this.total = data.TotalSemana;
          this.estoy = data.SemanaPorcentaje;
          this.moddle = data.MoodleURL;
          this.preloader = false;
        }
      });
    },

    refresData() {
      this.preloader = true;
      setTimeout(() => {
        this.allData();
      }, 1000);
    },
  },

  created() {
    this.allData();
    eventBus.$on("refreshCurso", this.refresData);
  },
};
</script>
