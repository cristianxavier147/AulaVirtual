<template>
  <div class="pb-32">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else class="grid grid-cols-1 lg:grid-cols-3 md:grid-cols-3">
      <div class="col-span-1 text-left mb-10">
        <div class="mb-5">
          <span class="size-text-16 font-bold md:p-0 lg:p-0 pl-5">Promedio:</span> <span class="size-text-16 font-bold text-gray-400">{{data.Promedio}}</span>
        </div>
        <bar-example :chart-data="dataPoints"/>
      </div>
      <div class="col-span-2 p-0 lg:pl-10 md:pl-10 ">
        <div class="bg-white card rounded-md">
          <div class="card-header">
            <div class="grid grid-cols-2 p-4 border-b border-gray-100">
              <div class="col-span-1 text-left">
                <span class="font-bold size-text-16">Detalle</span>
              </div>
              <!-- <div class="col-span-1 text-right">
                <img v-if="classGeneral === 'purple'" src="@/assets/global/info-purple.svg" alt="logo-idat" class="float-right mr-2" />
                <img v-if="classGeneral === 'red'" src="@/assets/global/info-red.svg" alt="logo-idat" class="float-right mr-2" />
                <img v-if="classGeneral === 'blue'" src="@/assets/global/info-blue.svg" alt="logo-idat" class="float-right mr-2" />
              </div> -->
            </div>
          </div>
          <div class="card-body" style="height: 270px" v-if="detalle.length > 0">
            <div class="grid w-full md:grid-cols-4 lg:grid-cols-4 grid-cols-6 p-4 my-2 bg-white" v-for="(item, index) in detalle" :key="index">
              <div class="md:col-span-2 lg:col-span-2 col-span-3">
                <div class="flex">
                  <div class="w-4 h-4 rounded-lg" :style="porcentajes[index].Valor > 0 && porcentajes[index].Valor < 11 ? 'background: #F85649' :  porcentajes[index].Valor > 11 ? 'background: #49F87F' : 'background: #7F8794'"></div>
                  <span class="ml-2 size-text-14 size-text-res-10 font-bold" :style="porcentajes[index].Valor > 0 && porcentajes[index].Valor < 11 ? '' :  porcentajes[index].Valor > 11 ? '' : 'color: #7F8794'">{{item.TipoNotaNombre | capitalize}} ({{porcentajes[index].Disponible1}})</span>
                </div>
              </div>
              <div class="md:col-span-1 lg:col-span-1 col-span-1 text-right">
                <span class="pr-4 size-text-14 size-text-res-12 lg:p-0 md:p-0">{{porcentajes[index].Valor === '' ? '-' : porcentajes[index].Valor}}</span>
              </div>
              <div class="md:col-span-1 lg:col-span-1 col-span-2 text-right">
                <!-- <span class="font-bold underline size-text-12" :class="'text-' + classGeneral">Solicitar revisión</span> -->
              </div>
            </div>
          </div>
          <div class="card-body flex justify-center items-center" style="height: 270px" v-else>
            Aún no se registra notas
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { eventBus } from "@/config/eventBus";
import BarExample from '@/components/Alumnos/Cursos/Grafics/Bar'
import { nameCursoService } from "@/mixins/nameCurso";

export default {
  data() {
    return {
      data: [],
      detalle: [],
      porcentajes: [],
      preloader : true,
      dataPoints: null,
    }
  },
  components: {
    BarExample
  },
  methods: {
    allData(){
      let store = JSON.parse(localStorage.getItem('data'))

      this.preloader = true
      var formdata = {
        'IdAlumno' : store.user_id_actor,
        'IdSeccion' : this.$route.query.id_seccion
      }

      this.$store.dispatch('cursoStore/notascurso' , formdata).then(
        (response) => {
          if(response.success == true){
            this.data = response.results
            console.log(this.data)
            this.detalle = this.data.ResLstPromedios === null ? [] : this.data.ResLstPromedios
            this.porcentajes = this.data.ResListAlumnoCursoNota === null ? [] : this.data.ResListAlumnoCursoNota
            var detalle = []
            var notas = []
            var color = []
            this.porcentajes.map(vl => {
              detalle.push(vl.CodigoCalificacion)
              notas.push(vl.Valor)
              if(vl.Valor < 11){
                color.push('#F85649')
              }else{
                color.push('#49F87F')
              }
            })

            this.preloader = false
            
            this.dataPoints = {
              labels: detalle,
              datasets: [
                {
                  label: false,
                  backgroundColor: color,
                  data: notas,
                  barPercentage: 0.2,
                },
              ],
              options: {
                legend: {
                    display: false,
                }
              },
            }
          }
        }
      )
    },

    refresData(){
      this.preloader = true
      setTimeout(() => {
        this.allData()
      }, 1000)
    }
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
}
</script>