<template>
    <div class="overlay">
        <div class="bg-white">
            <div class="card">
                <div class="card-header">
                    <div class="grid grid-cols-7 p-4 border-b border-gray-100">
                        <div class="col-span-6 text-left">
                            <div class="flex ml-3">
                                <div class="flex justify-center items-center">
                                    <img
                                        src="@/assets/avatar/avatar.png"
                                        alt="logo-idat"
                                        class="mr-2"
                                        style="width: 30px;height: 30px"
                                    />
                                </div>
                                <span class="size-text-16 font-medium mt-3">{{capitalize}}</span>
                            </div>
                        </div>
                        <div class="col-span-1 text-right">
                            <div class="mt-3">
                                <img
                                    src="@/assets/global/cerrar.svg"
                                    alt="logo-idat"
                                    class="mr-2 float-right cursor-pointer"
                                    @click="closeModal"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="px-6 py-7">
                        <div class="pb-5">
                            <div class="size-text-16 text-gray-400 font-bold mb-1">Correo:</div>
                            <div class="size-text-16 font-bold" :class="'text-' + classGeneral">{{data.AlumnoEmailInstitucion}}</div>
                        </div>
                        <div class="pb-5" v-if="data.ActorTelefonoDescripcion !== ''">
                            <div class="size-text-16 text-gray-400 font-bold mb-1">Teléfono:</div>
                            <div class="size-text-16 font-bold" :class="'text-' + classGeneral">{{data.ActorTelefonoDescripcion}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {
    props: ['data'],
    mounted() {
        console.log(this.data)
    },
    methods: {
        closeModal(){
            this.$emit('closeModal')
        }
    },
    computed: {
        store(){
            return JSON.parse(localStorage.getItem('data'))
        },

        classGeneral(){
            return localStorage.getItem('classGeneral')
        },

        capitalize(){
            var name = this.data.AlumnoSobreNombre +' '+this.data.AlumnoApellidos
            return nameCursoService.palabraFiltrada(name);
        }
    },
}
</script>