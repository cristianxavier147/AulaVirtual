<template>
  <div class="pb-32">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div class="grid grid-cols-2" >
        <div class="md:col-span-1 lg:col-span-1 col-span-2 p-0 lg:pr-3 md:pr-3 mb-5" style="height: 156px">
          <div class="flex p-5 bg-white h-full rounded-md">
            <img :src="data.FotoProfesor" alt="accesso" style="width: 105px;height: 105px;border-radius:50%" />
            <div class="pl-5 mt-4 text-left">
              <div class="mb-1 font-bold text-gray-400 size-text-14">Profesor@</div>
              <div class="mb-3 font-bold size-text-18" v-if="data.Nombres">{{data.Nombres | capitalize}},  {{data.Apellidos | capitalize }}</div>
              <div class="mb-3 font-bold size-text-18" v-else>No registra profesor asignado</div>
              <div class="font-bold underline size-text-1" :class="'text-' + classGeneral " v-if="data.Nombres">
                <router-link :to="{ name: 'horario', params: { slug: data.IdActor } , query : { id_seccion : this.$route.query.id_seccion , curso: this.$route.params.slug , credito: this.$route.query.credito }}">
                  Ver horario profesor@
                </router-link>
              </div>
            </div>
          </div>
        </div>
        <div class="md:col-span-1 lg:col-span-1 col-span-2 p-0 lg:pl-3 md:pl-3 mb-5" style="height: 156px">
          <div class="p-5 bg-white h-full rounded-md">
            <div class="text-left">
              <div class="mb-6 font-bold text-gray-400 size-text-18 size-text-res-14">Horario: {{data.TurnoNombre | capitalize}}</div>
              <div class="grid grid-cols-2 mb-5 font-medium size-text-16 size-text-res-12">
                <span class="col-span-1">Sede: {{data.SedeNombre | capitalize}}</span>
                <span class="col-span-1">Aula: {{data.AmbienteNombre}}</span>
              </div>
              <div class="grid grid-cols-2 mb-3 font-medium size-text-16 size-text-res-12">
                <span class="col-span-1" v-if="data.PromocionCodigo">{{data.PromocionCodigo}}</span>
                <span class="col-span-1" v-else>-</span>
                <span class="col-span-1">{{data.IdUnidadNegocio == "1" ? 'Créditos' : 'Horas'}}: {{this.$route.query.credito}}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import { eventBus } from "@/config/eventBus";
import { nameCursoService } from "@/mixins/nameCurso";
export default {
  data() {
    return {
      data: [],
      preloader : true
    }
  },
  methods: {
    allData(){
      let store = JSON.parse(localStorage.getItem('data'))
      this.preloader = true
      var formdata = {
        'IdTipoUsuario' : store.user_type_usuario,
        'IdSeccion' : this.$route.query.id_seccion
      }

      this.$store.dispatch('cursoStore/informacioncurso' , formdata).then(
        (response) => {
          if(response.success == true){
            this.preloader = false
            this.data = response.results
          }
        }
      )
    },

    refresData(){
      this.preloader = true
      setTimeout(() => {
        this.allData()
      }, 1000)
    }
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  created() {
    this.allData()
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
}
</script>
