<template>
  <div class="pb-32">
    <div class="grid grid-cols-4 mb-2">
      <div class="col-span-2 pr-1 md:col-span-2 sm:col-span-2 lg:col-span-1 xl:col-span-1">
        <div class="relative flex">
          <input type="text" name="" class="w-full bg-white  font-bold p-2.5" placeholder="Buscar" v-model="txt" @keyup="search()" />
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" class="absolute right-0 mr-2 top-3">
            <path id="Trazado_4792" data-name="Trazado 4792" d="M163.161,781.488,159,777.313a8.534,8.534,0,0,0,1.745-5.171c.163-4.6-3.7-8.473-8.648-8.642-4.9.167-8.764,4.043-8.6,8.6-.163,4.6,3.7,8.473,8.628,8.641a8.608,8.608,0,0,0,5.168-1.718l4.089,4.107a1.262,1.262,0,0,0,.891.37,1.238,1.238,0,0,0,.876-.365A1.168,1.168,0,0,0,163.161,781.488ZM145.945,772.1a6.247,6.247,0,1,1,0,.04v-.04Z" transform="translate(-143.496 -763.5)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
          </svg>
        </div>
      </div>
      <div class="col-span-2 pl-1 md:col-span-2 sm:col-span-2 lg:col-span-1 xl:col-span-1">
        <div class="relative flex">
          <input type="text" name="" disabled class="w-full bg-white  font-bold p-2.5" :placeholder="order === 1 ? 'A - Z' : 'Z - A'"  />
          <svg xmlns="http://www.w3.org/2000/svg" width="18.432" height="20" viewBox="0 0 18.432 20" class="absolute right-0 mr-2 cursor-pointer top-3" @click="ordenar">
            <g id="Grupo_8195" data-name="Grupo 8195" transform="translate(-198.294 28.707)">
              <g id="Grupo_8194" data-name="Grupo 8194" transform="translate(216.726 -20.828) rotate(90)">
                <g id="Grupo_225" data-name="Grupo 225">
                  <path id="Trazado_67" data-name="Trazado 67" d="M11.9,4.74,7.313.217A.754.754,0,0,0,6.255,1.29L9.53,4.523H.754a.754.754,0,1,0,0,1.508H9.53L6.255,9.263a.754.754,0,1,0,1.058,1.073L11.9,5.813a.753.753,0,0,0,0-1.073Z" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                </g>
              </g>
              <g id="Grupo_8193" data-name="Grupo 8193" transform="translate(198.294 -16.586) rotate(-90)">
                <g id="Grupo_225-2" data-name="Grupo 225">
                  <path id="Trazado_67-2" data-name="Trazado 67" d="M11.9,4.74,7.313.217A.754.754,0,0,0,6.255,1.29L9.53,4.523H.754a.754.754,0,1,0,0,1.508H9.53L6.255,9.263a.754.754,0,1,0,1.058,1.073L11.9,5.813a.753.753,0,0,0,0-1.073Z" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                </g>
              </g>
            </g>
          </svg>
        </div>
      </div>
    </div>
    <div class="mt-8" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div class="mt-8" v-else>
      <div class="grid grid-cols-2 lg:grid-cols-7 md:grid-cols-7">
        <div class="col-span-1 py-2 mx-2 mb-8 rounded-lg he-cont relative" v-if="profesorview">
          <div class="absolute top-0 w-full">
            <span class="bg-gray-900 text-white size-text-10 rounded-2xl px-3 py-1 font-bold">PROFESOR(A)</span>
          </div>
          <div class="px-2 text-center bg-white py-7 rounded-md">
            <div class="flex w-full justify-center items-center">
              <img src="@/assets/avatar/avatar.png" alt="accesso" class=" mb-4 img-w" style="border-radius:50%" />
            </div>
            <div class="block mb-1 font-medium size-text-14 h-cont-tc">{{nameProfesor  | capitalize}}</div>
            <div>
              <button @click="openModal(correoProfesor,1)" class="hei-bt-c font-bold text-center underline size-text-14" :class="'text-' + classGeneral">Ver contacto</button>
            </div>
          </div>
        </div>
        <div class="col-span-1 py-2 mx-2 mb-8 rounded-lg he-cont relative" v-for="(item , index) in data" :key="index">
          <div class="absolute top-0 w-full" v-if="item.IdAlumno === idDelegado">
            <span class="bg-gray-900 text-white size-text-10 rounded-2xl px-3 py-1 font-bold">DELEGAD@</span>
          </div>
          <div class="px-2 text-center bg-white py-7 rounded-md"> 
            <div class="flex w-full justify-center items-center">
              <img v-if="item.FileFoto !== ''" :src="item.FileFoto" alt="accesso" class=" mb-4 img-w" style="border-radius:50%" />
              <img v-else src="@/assets/avatar/avatar.png" alt="accesso" class=" mb-4 img-w" />
            </div>
            <div class="block mb-1 font-medium size-text-14 h-cont-tc">{{item.AlumnoSobreNombre  | capitalize}} {{item.AlumnoApellidos  | capitalize}}</div>
            <div>
              <button @click="openModal(item,2)" class="hei-bt-c font-bold text-center underline size-text-14" :class="'text-' + classGeneral">Ver contacto</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <ModalCursoEmail v-if="modal" @closeModal="closeModal" :data="this.dataModal" />
  </div>
</template>

<script>
import ModalCursoEmail from "@/components/Alumnos/Cursos/Modal/ModalCursoEmail";
import { eventBus } from "@/config/eventBus";
import { nameCursoService } from "@/mixins/nameCurso";
export default {
  components: {
    ModalCursoEmail,
    preloader : true
  },
  data() {
    return {
      modal: false,
      data: [],
      preloader : true,
      nameProfesor: '',
      correoProfesor: '',
      idDelegado: '',
      dataModal: [],
      txt:'',
      searchData: [],
      profesorview: true,
      order : 1
    };
  },
  methods: {
    allData(){
      this.preloader = true
      var formdata = {
        'IdSeccion' : this.$route.query.id_seccion
      }

      this.$store.dispatch('cursoStore/informacioncontacto' , formdata).then(
        (response) => {
          if(response.success == true){
            this.data = response.results.ResLstAlumnoCurso
            this.searchData = response.results.ResLstAlumnoCurso
            var cont = response.results
            this.nameProfesor =cont.Nombres+' '+cont.Apellidos
            this.correoProfesor = cont.EmailProfesor
            this.idDelegado = parseInt(cont.Delegado)
            this.preloader = false

            this.searchData.map(vl => {
              vl.NombreSoloBusqueda = vl.NombreSoloBusqueda.replace(/Á/g, 'A')
              vl.NombreSoloBusqueda = vl.NombreSoloBusqueda.replace(/É/g, 'E')
              vl.NombreSoloBusqueda = vl.NombreSoloBusqueda.replace(/Í/g, 'I')
              vl.NombreSoloBusqueda = vl.NombreSoloBusqueda.replace(/Ó/g, 'O')
              vl.NombreSoloBusqueda = vl.NombreSoloBusqueda.replace(/Ú/g, 'U')
            })

          }
        }
      )
    },
    openModal(item,value) {
      if(value === 1){
        let form = {
          AlumnoEmailInstitucion: this.correoProfesor,
          AlumnoSobreNombre: this.nameProfesor,
          AlumnoApellidos: '',
          ActorTelefonoDescripcion: ''
        } 
        this.dataModal = form
      }else{
        this.dataModal = item
      }
      this.modal = true;

    },
    closeModal() {
      this.modal = false;
    },
    search(){
      this.profesorview = false
      this.data = []
      this.delegado = []
      if(this.txt !== ''){
        var filterText  = this.txt.toUpperCase()
        this.searchData.map(vl =>{
          if(vl.ActorNombreCompleto.includes(filterText)){
              this.data.push(vl)
          }
        })
      }else{
        this.allData()
        this.profesorview = true
      }
    },

    esAnagrama(palabra, posibleAnagrama){
      //Si desde un principio son iguales, regresamos false; ya que no tienen orden distinto
      if(palabra === posibleAnagrama) return false;
      
      return palabra.split("").sort().join("") === posibleAnagrama.split("").sort().join("");
    },

    refresData(){
      this.preloader = true
      setTimeout(() => {
        this.allData()
      }, 1000)
    },

    ordenar(){
      this.preloader = true
      this.order = this.order === 1 ? 2 : 1
      if(this.order === 1){
        this.searchData.sort((a , b) => a.NombreSoloBusqueda.localeCompare(b.NombreSoloBusqueda))
      }else{
        this.searchData.sort((a , b) => b.NombreSoloBusqueda.localeCompare(a.NombreSoloBusqueda))
      }
      this.preloader = false
    }
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  created() {
    this.allData()
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    },

    store(){
      return JSON.parse(localStorage.getItem('data'))
    }
  }
};
</script>
