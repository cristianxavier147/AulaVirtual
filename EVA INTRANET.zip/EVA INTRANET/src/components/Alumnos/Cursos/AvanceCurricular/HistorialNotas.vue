<template>
  <div id="" class="pb-24 mx-4 align-middle pb-responsive cont-final">
    <div id="contTabCursos" class="active">
      <div id="contSearch" class="grid w-full grid-cols-3 mb-2 lg:grid-cols-3 md:grid-cols-3">
        <!-- <div class="col-span-1 pr-2 mb-3">
                    <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12  font-bold p-2.5" name="" id="" v-model="lineaNegocio">
                        <option :value="item.UnidadNegocioIdUnidadNegocio" v-for="(item , index) in lineaNegocios" :key="index">{{item.UnidadNegocioNombre}}</option>
                    </select>
                </div> -->
        <!-- <div class="col-span-1 px-2 mb-3">
                    <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12  font-bold p-2.5" name="" id="" v-model="sede">
                        <option :value="item.IdSede" v-for="(item , index) in sedes" :key="index">{{item.SedeNombre}}</option>
                    </select>
                </div> -->
        <!-- <div class="col-span-1 pr-2 mb-3">
                    <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12  font-bold p-2.5" name="" id="" v-model="division">
                        <option :value="item.FacultadIdFacultad" v-for="(item , index) in facultad" :key="index">{{item.FacultadNombre}}</option>
                    </select>
                </div> -->
        <div class="col-span-1 pr-2 mb-3">
          <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12  font-bold p-2.5" name="" id="" v-model="programa">
            <option :value="item.UnidadAcademicaIdUnidadAcademica" v-for="(item, index) in unidadacademica" :key="index">{{ item.UnidadAcademicaNombre }}</option>
          </select>
        </div>
        <div class="col-span-2 px-2 mb-3">
          <select :class="classGeneral" class=" w-full size-text-16 size-text-res-12  font-bold p-2.5" name="" id="" v-model="producto" @change="filtros">
            <option :value="item.IdCurriculaProducto" v-for="(item, index) in productosComputed" :key="index">{{ item.NombreCurriculaProducto }}</option>
          </select>
        </div>
      </div>
      <div class="w-full text-center" v-if="preloader">
        <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
      </div>
      <div v-else>
        <HistorialNotasAC v-for="(item, index) in data" :key="index" :ciclo="item.CursoNivel" :content="item.cursos" :valor="item.valor" />
      </div>
    </div>
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div id="contTabResumen" v-else>
      <!-- <div class="mb-5 text-left title-nivel">
        <span class="font-bold size-text-12 size-text-res-14">Resumen de cumplimiento de asignaturas obligatorias</span>
      </div> -->
      <!-- <div>
        <table class="table w-full">
          <thead class="bg-white">
            <tr>
              <th class="p-2 font-bold text-gray-400 size-text-12"></th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">A cumplir</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Cumplido</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">% cumplido</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-3 font-bold text-left size-text-12">Asignatura</td>
              <td class="p-3 font-bold text-left size-text-12">{{ cumplir }}</td>
              <td class="p-3 font-bold text-left size-text-12">{{ cumplidos }}</td>
              <td class="p-3 font-bold text-left size-text-12">{{ porcentajecumplidos }}</td>
            </tr>
          </tbody>
        </table>
      </div> -->
      <div class="scroll-horizontal" v-if="certificadoModular.length > 0">
        <table class="table w-full">
          <thead>
            <th class="p-2 font-bold text-left size-text-12">Clasificación modular (I, II, III)</th>
            <th class="p-2 font-bold text-left size-text-12" colspan="2">Validación de prácticas</th>
            <th class="p-2 font-bold text-left size-text-12" colspan="3">Certificación modular (Cumpl. Prácticas + Cumpl. Académico)</th>
          </thead>
          <thead class="bg-white">
            <tr>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Módulo</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Cumpl. Horas práctica</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Descarga constancia</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Cumplimiento académico</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Certifica</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Descarga certificado</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in certificadoModular" :key="index">
              <td class="p-3 text-left size-text-10">{{ item.CertificadoNombre }}</td>
              <td class="p-3 text-left size-text-10">{{ item.CumplidasPPP }} horas de {{ item.ACumplirPPP }} ({{ (item.CumplidasPPP / item.ACumplirPPP) * 100 + "%" }})</td>
              <td class="p-3 text-left size-text-10">
                <span v-if="(item.CumplidasPPP / item.ACumplirPPP) * 100 === 100" class="font-bold underline" :class="'text-' + classGeneral + '-600'">
                  <a :href="item.ValidacionPracticasUrl">Descargar</a>
                </span>
              </td>
              <td class="p-3 text-left size-text-10">{{ item.CumplidasAcad }} horas de {{ item.ACumplirAcad }} ({{ (item.CumplidasAcad / item.ACumplirAcad) * 100 + "%" }})</td>
              <td class="p-3 text-left size-text-10">{{ item.Certifica }}</td>
              <td class="p-3 text-left size-text-12">
                <span v-if="(item.CumplidasAcad / item.ACumplirAcad) * 100 === 100" class="font-bold underline" :class="'text-' + classGeneral + '-600'">
                  <a :href="item.CertificacionModularUrl">Descargar</a>
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <IrClase />
  </div>
</template>

<script>
import IrClase from "@/components/Button/IrClase";
import AvanceCurricular from "@/components/Alumnos/Cursos/AvanceCurricular";
import HistorialNotasAC from "@/components/Alumnos/Cursos/HistorialNotasAC";
import { nameCursoService } from "@/mixins/nameCurso";

export default {
  components: {
    IrClase,
    AvanceCurricular,
    HistorialNotasAC,
  },
  data() {
    return {
      lineaNegocio: null,
      lineaNegocios: [],
      sede: null,
      sedes: [],
      division: null,
      facultad: [],
      programa: null,
      unidadacademica: [],
      producto: null,
      productos: [],
      data: [],
      cumplir: 0,
      cumplidos: 0,
      porcentajecumplidos: 0,
      certificadoModular: [],
      preloader: true,
    };
  },
  watch: {
    producto(val) {
      this.filtros();
    },
  },
  methods: {
    tabItem(item) {
      if (item == 1) {
        //tabs
        let tabcurso = document.getElementById("tabCurso");
        tabcurso.classList.add("active");
        let tabresumen = document.getElementById("tabResumen");
        tabresumen.classList.remove("active");

        //cont
        let contcurso = document.getElementById("contTabCursos");
        contcurso.classList.add("active");
        let contresumen = document.getElementById("contTabResumen");
        contresumen.classList.remove("active");
      } else {
        //tabs
        let tabcurso = document.getElementById("tabCurso");
        tabcurso.classList.remove("active");
        let tabresumen = document.getElementById("tabResumen");
        tabresumen.classList.add("active");

        //cont
        let contcurso = document.getElementById("contTabCursos");
        contcurso.classList.remove("active");
        let contresumen = document.getElementById("contTabResumen");
        contresumen.classList.add("active");
      }
    },
    allData() {
      let formaData = {
        IdAlumno: this.store.user_id_actor,
      };

      this.$store.dispatch("cursoStore/avanceCurricular", formaData).then((response) => {
        if (response.success === true) {
          this.lineaNegocios = response.results.UnidadNegocio;
          this.lineaNegocio = this.lineaNegocios[0].UnidadNegocioIdUnidadNegocio;
          this.sedes = response.results.Sede;
          this.sede = this.sedes[0].IdSede;
          this.facultad = response.results.Facultad;
          this.division = this.facultad[0].FacultadIdFacultad;
          this.unidadacademica = response.results.UnidadAcademica;
          this.programa = this.unidadacademica[0].UnidadAcademicaIdUnidadAcademica;
          this.productos = response.results.Producto;
          this.producto = this.productos[0].IdCurriculaProducto;

          this.filtros();
        }
      });
    },

    filtros() {
      this.preloader = true;

      let formaData = {
        IdAlumno: this.store.user_id_actor,
        IdSede: this.sede,
        IdFacultad: this.division,
        IdUnidadNegocio: this.lineaNegocio,
        IdUnidadAcademica: this.programa,
        IdCurriculaProducto: this.producto,
      };

      this.$store.dispatch("cursoStore/avanceCurricular", formaData).then((response) => {
        if (response.success === true) {
          console.log("ss");
          let niveles = response.results.Nivel;
          let matriculas = response.results.Matriculas;
          let estadoMatricula = response.results.EstadoMatricula;
          let matriculaPeriodo = response.results.MatriculaPeriodo;

          for (let x = 0; x < niveles.length; x++) {
            niveles[x].cursos = [];
            niveles[x].valor = {};
            for (let y = 0; y < matriculas.length; y++) {
              if (niveles[x].CursoNivel === matriculas[y].CursoNivel) {
                niveles[x].cursos.push(matriculas[y]);
              }
            }

            for (let z = 0; z < estadoMatricula.length; z++) {
              for (let j = 0; j < matriculaPeriodo.length; j++) {
                if (estadoMatricula[z].IdMatricula === matriculaPeriodo[j].IdMatricula && estadoMatricula[z].EstadoNombre === "NORMAL" && estadoMatricula[z].Descripcion === niveles[x].CursoNivel) {
                  niveles[x].valor = estadoMatricula[z];
                }
              }
            }
          }

          let cantidadCursos = matriculas.length;
          let aprovados = 0;
          let desaprobados = 0;
          let pendientes = 0;

          for (let x = 0; x < matriculas.length; x++) {
            if (matriculas[x].PromedioCondicion === "A") {
              aprovados = aprovados + 1;
            } else if (matriculas[x].PromedioCondicion === "D") {
              desaprobados = desaprobados + 1;
            } else {
              pendientes = pendientes + 1;
            }
          }

          this.cumplir = aprovados + pendientes;
          this.cumplidos = aprovados;
          this.porcentajecumplidos = Math.round((aprovados * 100) / (pendientes + desaprobados + aprovados));

          this.certificadoModular = response.results.Certificado;

          this.data = niveles;

          console.log(this.data);

          this.preloader = false;
        }
      });
    },
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    productosComputed() {
      let a = this.productos.filter((x) => x.UnidadAcademicaIdUnidadAcademica == this.programa);
      if (a.length != 0) {
        this.producto = a[0].IdCurriculaProducto;
      }
      return a;
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },

  created() {
    this.allData();
  },
};
</script>

<style>
@media (max-width: 450px) {
  #contSearch {
    padding-top: 3rem;
  }
}

@media (min-width: 1024px) {
  #contSearch {
    padding-top: 2rem;
  }
}
</style>
