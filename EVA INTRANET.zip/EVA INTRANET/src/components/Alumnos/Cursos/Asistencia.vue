<template>
  <div class="pb-44">
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div class="grid grid-cols-1 lg:grid-cols-3 ml:grid-cols-2">
        <div class="col-span-1 lg:col-span-2 md:col-span-2">
          <div class="p-5 text-left bg-white lg:p-6 md:p-6 rounded-md">
            <span class="font-bold size-text-16" v-if="this.data.IntNroFaltas !== 0 && (this.data.IntPuaFaltas >= faltas.length)">Te {{this.data.IntPuaFaltas - this.data.IntNroFaltas == 1 ? 'queda' : 'quedan' }} {{this.data.IntPuaFaltas - this.data.IntNroFaltas}} {{this.data.IntPuaFaltas - this.data.IntNroFaltas == 1 ? 'falta' : 'faltas' }}</span>
            <span class="fotn-bold size-text-16" v-if="this.data.IntPuaFaltas < faltas.length">Desaprobado por Inasistencia</span>
            <span class="font-bold size-text-16" v-if="this.data.IntNroFaltas === 0">¡Felicidades! No tienes faltas</span>
            <div class="grid grid-cols-5 pt-4 lg:pt-4 md:pt-4" >
              <div v-for="(item , index) in this.data.IntPuaFaltas" :key="index">
                <div class="col-span-1 p-2 mx-1 mb-2 bg-gray-200 lg:mx-2 md:lg:mx-2" v-if="data.IntNroFaltas == 0 && index == 0" :class="data.IntNroFaltas == 0 && index == 0 ? 'rounded-lg' : ''" :style="data.IntNroFaltas >= index + 1 ?  'background: #49F87F' : ''"></div>
                <div class="col-span-1 p-2 mx-1 mb-2 bg-gray-200 lg:mx-2 md:lg:mx-2" v-else-if="index == 0 && data.IntNroFaltas !== 0" :class="index == 0 && data.IntNroFaltas !== 0 ? 'rounded-lg' : ''" :style="data.IntNroFaltas >= index + 1 ?  'background: #49F87F' : ''"></div>
                <div class="col-span-1 p-2 mx-1 mb-2 bg-gray-200 lg:mx-2 md:lg:mx-2" v-else-if="index > 0 && index < data.IntPuaFaltas - 1" :style="data.IntNroFaltas >= index + 1 ?  'background: #49F87F' : ''"></div>
                <div class="col-span-1 p-2 mx-1 mb-2 bg-gray-200 lg:mx-2 md:lg:mx-2" v-else-if="index === data.IntPuaFaltas - 1" :class="index == data.IntPuaFaltas - 1 ? 'rounded-tr-lg rounded-br-lg' : ''" :style="data.IntNroFaltas >= index + 1 ?  'background: #49F87F' : ''"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-span-1">
          <div class="flex pl-5 pr-4 py-4">
            <div>
              <img src="@/assets/global/infoblack.svg" alt="logo-idat" class="top-0 mr-2" />
            </div>
            <div class="text-left">
              <span class="block size-text-14 size-text-res-12"> a) DPI = Desaprobado por Inasistencia </span>
              <span class="block size-text-14 size-text-res-12"> b) {{this.data.IntMaximoTardanzas}} tardanzas acumulan 1 Falta </span>
              <span class="block size-text-14 size-text-res-12"> c) Faltas máximas permitidas: {{this.data.IntPuaFaltas}} </span>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-2 lg:mt-8 md:mt-8">
        <div class="grid grid-cols-1 lg:grid-cols-2 ml:grid-cols-2">
          <div class="col-span-1 lg:pr-5 md:pr-5 mb-5" style="height:300px">
            <div class="bg-white card rounded-md">
              <div class="card-header">
                <div class="grid grid-cols-2 p-4 border-b border-gray-100">
                  <div class="col-span-1 text-left">
                    <span class="font-bold size-text-14">Faltas</span>
                  </div>
                  <div class="col-span-1 text-right">
                    <a :href="store.linksae" target="_blank" class="font-bold underline size-text-12" :class="'text-' + classGeneral">Justificar</a>
                  </div>
                </div>
              </div>
              <div class="card-body overflow-auto" style="height:249px" v-if="faltas.length > 0">
                <div class="w-full p-4 my-2 text-left bg-white" v-for="(item , index) in faltas" :key="index">
                  <span class="block size-text-14 -mt-1.5">{{item.HorarioSesionFecha}}</span>
                </div>
              </div>
              <div class="card-body overflow-auto" v-else style="height:249px">
                <div class="flex justify-center items-center h-full relative">
                  <img src="@/assets/global/ninguna-as-tar.svg" alt="">
                  <span class="size-text-16 text-gray-400 absolute top-36">No tienes faltas</span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-span-1 lg:pl-5 md:pl-5 mb-5" style="height:249px">
            <div class="bg-white card rounded-md">
              <div class="card-header">
                <div class="grid grid-cols-1 p-4 border-b border-gray-100">
                  <div class="col-span-1 text-left">
                    <span class="font-bold size-text-14">Tardanzas</span>
                  </div>
                </div>
              </div>
              <div class="card-body overflow-auto" style="height:249px" v-if="tardanzas.length > 0">
                <div class="w-full p-4 my-2 text-left bg-white" v-for="(item , index) in tardanzas" :key="index">
                  <span class="block size-text-14 -mt-1.5">{{item.HorarioSesionFecha}}</span>
                </div>
              </div>
              <div class="card-body overflow-auto" v-else style="height:249px">
                <div class="flex justify-center items-center h-full relative">
                  <img src="@/assets/global/ninguna-as-tar.svg" alt="">
                  <span class="size-text-16 text-gray-400 absolute top-36">No tienes tardanzas</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import { eventBus } from "@/config/eventBus";
export default {
  data() {
    return {
      data: [],
      faltas: [],
      tardanzas: [],
      preloader : true,
    }
  },
  methods: {
    allData(){
      let store = JSON.parse(localStorage.getItem('data'))

      this.preloader = true
      this.faltas = []
      this.tardanzas = []
      
      var formdata = {
      'IdAlumno' : store.user_id_actor,
      'IdSeccion' : this.$route.query.id_seccion
      }

      this.$store.dispatch('cursoStore/asitenciacurso' , formdata).then(
        (response) => {
          if (response.success == true) {
            this.data = response.results
            this.data.lstAlumnoCursoAsistencia.map(vl => {
              if(vl.Valor === "F"){
                this.faltas.push(vl)
              }else if(vl.Valor === 'T'){
                this.tardanzas.push(vl)
              }
            })
            this.preloader = false
          }
        }
      )
    },

    refresData(){
      this.preloader = true
      setTimeout(() => {
        this.allData()
      }, 1000)
    }
  },
  created() {
    this.allData()
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    },

    store(){
      return JSON.parse(localStorage.getItem('data'))
    }
  }
}
</script>