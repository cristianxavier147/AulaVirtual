<template>
  <div>
    <div class="pt-20 bg-white md:pt-16">
      <!-- content -->
      <div class="text-left mx-3.5 md:mx-36  md:w-1/3 md:mt-5  md:absolute md:z-10">
        <h1 class="my-4 text-5xl font-extrabold text-purple-600 md:text-7xl">
          Oops...
        </h1>
        <h2 class="my-4 text-3xl font-bold text-black md:text-5xl">ERROR 404</h2>
        <span class="text-sm font-medium text-gray-500 md:text-2xl">No se encontró la página</span>
        <p class="my-4 text-xs text-gray-500 md:text-base">
          Lo sentimos, puede que la página que buscas ya no exista, haya cambiado de nombre o no esté disponible temporalmente.
        </p>
        <p class="text-xs text-gray-500 md:text-base">
          Dirígete a nuestro
          <span class="font-bold text-purple-600 underline cursor-pointer">home</span>
          para que explores todas las opciones que tenemos para ti.
        </p>
      </div>
      <!-- img 404 -->
      <div class="w-11/12 mx-auto md:w-8/12 md:mx-auto md:relative top-24">
        <img src="@/assets/error404/404.png" alt="problemas" class="md:h-screen/2" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Error404",
};
</script>

<style scoped></style>
