<template>
    <div class="text-left">
        <span>.... Redireccionando</span>
        <span v-if="msgError">{{msg}}</span>
    </div>
</template>\

<script>
export default {
    data() {
        return {
            msgError: false
        }
    },

    methods: {
        validateToken(){
            var form = {
                query: this.$route.query.q
            }
            this.$store.dispatch("loginStore/validateToken",form).then(
                (response) => {
                    if(!response.success){
                        this.msgError = false
                        setTimeout(() => {
                            this.$router.push({ path: 'login' }).catch(()=>{})
                        }, 1000);
                    }
                }
            )
        }
    },

    created() {
        this.validateToken()
    },
}
</script>