<template>
  <div id="preLoading" class="h-full pre-loading">
    <div class="flex items-center justify-center h-full bg-white">
      <div>
        <div class="flex px-10">
          <img id="evafinal" src="https://cdn.idat.edu.pe/eva/img/preloader/evafinal.svg" width="auto" height="auto" alt="accesso" class="inactive active" />
          <img id="eva" src="https://cdn.idat.edu.pe/eva/img/preloader/eva.svg" width="auto" height="auto" alt="accesso" class="inactive active" />
          <img id="va" src="https://cdn.idat.edu.pe/eva/img/preloader/va.svg" width="auto" height="auto" alt="accesso" class="inactive active" />
          <img id="a" src="https://cdn.idat.edu.pe/eva/img/preloader/a.svg" width="auto" height="auto" alt="accesso" class="inactive active" />
        </div>
        <br />
        <div style="height: 8px;display: block">
          <div :style="'width:' + valornumerico + '%'" style=" height: 8px; border-radius:5px; border: none;" :class="'fnd-' + this.classGeneral "></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Home",

  data() {
    return {
      valornumerico: 0,
    };
  },

  computed: {
    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },

  beforeMount() {
    var inicio = new Date();
    onload = function() {
      this.tiempoCarga(inicio);
    }.bind(this);
  },

  methods: {
    tiempoCarga(inicio) {
      var fin = new Date();
      var segundos = (1500 - 1) / 10;
      this.valornumerico = 1;
      this.valorCarga(segundos);
    },
    valorCarga(initial) {
      var id = setInterval(() => {
        var valinitial = initial;
        this.valornumerico = this.valornumerico + Math.ceil((100 * this.valornumerico) / valinitial);

        if(this.valornumerico === 2) {
          var ct = document.getElementById('a')
          ct.classList.toggle('inactive')
        }else if(this.valornumerico === 7) {
          var ct = document.getElementById('a')
          ct.classList.toggle('inactive')
          var ct = document.getElementById('va')
          ct.classList.toggle('inactive')
        }else if(this.valornumerico === 21) {
          var ct = document.getElementById('va')
          ct.classList.toggle('inactive')
          var ct = document.getElementById('eva')
          ct.classList.toggle('inactive')
        }else if(this.valornumerico === 61) {
          var ct = document.getElementById('eva')
          ct.classList.toggle('inactive')
          var ct = document.getElementById('evafinal')
          ct.classList.toggle('inactive')
        }

        if (this.valornumerico > 100) {
          this.valornumerico = this.valornumerico * 100;
        }
        if (this.valornumerico >= valinitial) {
          this.valornumerico = 100;
          if(!localStorage.getItem("token")){
            this.$router.push({ name: "login" })
          }else{
            this.$router.push({name: 'dashboard'})
          }
          clearInterval(id);
        }
      }, 500);
    },
    validateFormat() {
      const route = window.location.host;
      if (route == process.env.VUE_APP_RUTA_IDAT) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_IDAT);
      } else if (route == process.env.VUE_APP_RUTA_ZEGEL) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_ZEGEL);
      } else if (route == process.env.VUE_APP_RUTA_CORRIENTE) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_CORRIENTE);
      } else {
        localStorage.setItem("classGeneral", 'purple');
      }
    },
  },

  created() {
    this.validateFormat();
  },

};
</script>

<style scoped>
.val-login {
  display: none !important;
}

.inactive{
  width: 0 !important;
  transition: all 0.5s;
}

.active{
  width: initial;
  transition: all 0.5s;
}


@media (max-width: 767px) {
  .inicio {
    height: 100%;
  }
  .inicio > div {
    height: 100%;
  }
}
</style>
