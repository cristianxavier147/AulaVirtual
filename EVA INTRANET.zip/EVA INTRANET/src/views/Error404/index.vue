<template>
  <div class="bg-white h-screen">
    <Errores />
  </div>
</template>

<script>
import Errores from "@/components/Errores/Error404";
export default {
  name: "Error404",
  components: {
    Errores,
  },
};
</script>

<style></style>
