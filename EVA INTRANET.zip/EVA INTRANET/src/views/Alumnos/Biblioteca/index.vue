<template>
  <div>
    <BibliotecaContent />
  </div>
</template>

<script>
import BibliotecaContent from "@/components/Alumnos/Biblioteca/BibliotecaContent";
export default {
  name: "Biblioteca",
  components: {
    BibliotecaContent,
  },
};
</script>

<style></style>
