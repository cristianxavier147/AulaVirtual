<template>
  <div>
    <TardePago />
  </div>
</template>

<script>
import TardePago from "@/components/Alumnos/DeudaPendiente/TardePago";
export default {
  name: "PagoTarde",
  components: {
    TardePago,
  },
};
</script>

<style></style>
