<template>
  <div>
    <Reagendar />
  </div>
</template>

<script>
import Reagendar from "@/components/Alumnos/DeudaPendiente/OlvidePagar/Reagendar";
export default {
  name: "ReagendarPago",
  components: {
    Reagendar,
  },
};
</script>

<style></style>
