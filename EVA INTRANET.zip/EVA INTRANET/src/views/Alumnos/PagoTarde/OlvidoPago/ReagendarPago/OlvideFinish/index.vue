<template>
  <div class="bg-gray-100 h-screen">
    <OlvidoFinish />
  </div>
</template>

<script>
import OlvidoFinish from "@/components/Alumnos/DeudaPendiente/OlvidePagar/OlvidoFinish";
export default {
  name: "OlvideFinish",
  components: {
    OlvidoFinish,
  },
};
</script>

<style></style>
