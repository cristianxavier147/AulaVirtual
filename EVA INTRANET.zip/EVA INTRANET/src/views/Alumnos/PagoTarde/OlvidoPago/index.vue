<template>
  <div>
    <Olvido />
  </div>
</template>

<script>
import Olvido from "@/components/Alumnos/DeudaPendiente/OlvidePagar/Olvido";

export default {
  name: "Olvide",
  components: {
    Olvido,
  },
};
</script>

<style></style>
