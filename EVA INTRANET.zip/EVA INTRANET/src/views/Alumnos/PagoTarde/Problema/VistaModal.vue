<template>
  <div>
    <modal-component
      v-if="isVisibility"
      title="Bienvenidos"
      @toggle-modal="toggleModal"
    >
      <!-- slot -->
      Esto es el slot del modal
    </modal-component>

    <!-- Boton Open -->
    <button
      @click.prevent="toggleModal"
      class="bg-blue-500 text-white p-2 text-sm rounded"
    >
      Confirmar
    </button>
  </div>
</template>

<script>
import ModalComponent from "@/components/ModalComponent";
export default {
  name: "BotonModal",
  components: {
    ModalComponent,
  },

  data() {
    return {
      isVisibility: false,
    };
  },

  methods: {
    toggleModal() {
      this.isVisibility = !this.isVisibility;
    },
  },
};
</script>
