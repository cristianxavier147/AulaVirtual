<template>
  <div class="bg-gray-100 h-screen">
    <SolucionProblem />
    <!-- componente modal -->

    <modal-component
      v-if="isVisibility"
      title="Te estaremos contactando lo más pronto posible"
      @toggle-modal="toggleModal"
    >
    </modal-component>

    <!-- Boton Open -->

    <div class="md:w-3/5 mx-auto md:flex">
      <button
        @click.prevent="toggleModal"
        class="text-white p-2 text-sm rounded-md h-12 font-medium  w-11/12 md:w-3/12 md:mt-5 mt-12"
        :class="'bt-'+classGeneral+'-600'"
      >
        Confirmar
      </button>
    </div>
  </div>
</template>

<script>
import SolucionProblem from "@/components/Alumnos/DeudaPendiente/ProblemaPagar/SolucionProblem";
import ModalComponent from "@/components/Alumnos/DeudaPendiente/ProblemaPagar/ModalComponent";
export default {
  name: "Problema",
  components: {
    SolucionProblem,
    ModalComponent,
  },
  data() {
    return {
      isVisibility: false,
    };
  },

  methods: {
    toggleModal() {
      this.isVisibility = !this.isVisibility;
    },
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
