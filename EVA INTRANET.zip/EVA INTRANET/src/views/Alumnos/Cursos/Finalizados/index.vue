<template>
  <div class="pb-24 mx-4 align-middle pb-responsive cont-final">
    <div id="contTitle" class="mb-5 text-left size-text-16">
      <span class="font-bold">Cursos finalizados</span>
    </div>
    <div id="contSearch" class="grid grid-cols-4 mb-2">
      <div class="col-span-2 mr-2 md:col-span-4 sm:col-span-4 lg:col-span-1 xl:col-span-2">
        <select :class="classGeneral" class=" w-full  font-bold  p-2.5 h-full" name="" id="" v-model="producto" @change="filter">
          <option selected disabled value="null"> Producto </option>
          <option value=""> Todos </option>
          <option v-for="(item, index) in productos" :key="index" :value="item.ProductoIdProducto">{{ item.ProductoNombre | capitalize }}</option>
        </select>
      </div>
      <div class="col-span-2 pr-1 md:col-span-2 sm:col-span-2 lg:col-span-1 xl:col-span-1">
        <div class="relative flex">
          <input type="text" name="" id="" class="w-full bg-white  font-bold p-2.5" placeholder="Buscar" v-model="text" @keyup="filter" />
          <img src="@/assets/global/search.svg" alt="accesso" class="absolute right-0 mr-2 top-3" @click="filter" />
        </div>
      </div>
      <div class="col-span-2 pl-1 md:col-span-2 sm:col-span-2 lg:col-span-1 xl:col-span-1">
        <select :class="classGeneral" class=" w-full  font-bold  p-2.5 h-full" name="" id="" v-model="anio" @change="filter">
          <option selected disabled value="null"> Año </option>
          <option value=""> Todos </option>
          <option v-for="(item, index) in periodos" :key="index" :value="item.PeriodoCodigo">{{ item.PeriodoCodigo }}</option>
        </select>
      </div>
    </div>
    <div class="w-full text-center" v-if="preloader">
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <div v-else>
      <div class="flex flex-row items-center w-full p-4 my-3 bg-white" v-for="(item, index) in data" :key="index">
        <div class="rounded-lg w-2.5 h-2.5" :style="'background: #' + 'b' + 3 + 1 + 'cdd'"></div>
        <router-link :to="{ path: '/alumnos/cursos/curso/' + item.CursoNombre, query: { id_seccion: item.IdSeccion, credito: item.CursoCredito, isEnded: item.isEnded } }">
          <span class="text-sm -mt-1.5 ml-2"> {{ item.CursoNombre }}</span>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      anio: null,
      text: "",
      producto: null,
      data: [],
      productos: [],
      periodos: [],
      preloader: true,
    };
  },
  methods: {
    allData() {
      this.preloader = true;
      var formdata = {
        IdActor: this.store.user_id_actor,
      };
      this.$store.dispatch("cursoStore/finalizados", formdata).then((response) => {
        if (response.success == true) {
          response.results.lstCursosFinalizados.forEach((e) => {
            e.isEnded = true;
            this.data.push(e);
          });
          var hash = {};
          this.productos = this.data.filter(function(current) {
            var exists = !hash[current.ProductoIdProducto];
            hash[current.ProductoIdProducto] = true;
            return exists;
          });
          this.periodos = this.data.filter(function(current) {
            var exists = !hash[current.PeriodoCodigo];
            hash[current.PeriodoCodigo] = true;
            return exists;
          });
          this.preloader = false;
        }
      });
    },

    filter() {
      this.preloader = true;
      var formdata = {
        IdActor: this.store.user_id_actor,
        NombreCurso: this.text,
        CodigoPeriodo: this.anio,
        IdProducto: this.producto,
      };
      this.$store.dispatch("cursoStore/finalizados", formdata).then((response) => {
        if (response.success == true) {
          this.data = response.results.lstCursosFinalizados;
          this.preloader = false;
        }
      });
    },
  },

  created() {
    this.allData();
  },

  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },
};
</script>
