<template>
  <SituacionAcademica />
</template>

<script>
import SituacionAcademica from "@/components/Alumnos/Cursos/AvanceCurricular/SituacionAcademica.vue";
export default {
  components: {
    SituacionAcademica,
  },
};
</script>

<style lang="scss" scoped></style>
