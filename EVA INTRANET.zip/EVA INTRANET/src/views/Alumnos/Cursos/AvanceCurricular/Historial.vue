<template>
  <HistorialNotas />
</template>

<script>
import HistorialNotas from "@/components/Alumnos/Cursos/AvanceCurricular/HistorialNotas.vue";
export default {
  components: {
    HistorialNotas,
  },
};
</script>

<style lang="scss" scoped></style>
