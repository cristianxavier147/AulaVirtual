<template>
  <div class="my-2 md:px-7 md:py-3">
    <div class="overflow-auto font-bold text-gray-400 tabs-custom size-text-12 md:gap-2">
      <div class="flex h-full ml-2 text-base w-max">
        <router-link :exact-active-class="'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600'" class="max-w-lg mx-2 cursor-pointer" to="/alumnos/cursos/avance-curricular">Situación Académica</router-link>
        <router-link :exact-active-class="'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600'" class="max-w-lg mx-2 cursor-pointer" to="/alumnos/cursos/avance-curricular/historial">Historial de notas</router-link>
      </div>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
import HistorialNotas from "@/components/Alumnos/Cursos/AvanceCurricular/HistorialNotas.vue";
import SituacionAcademica from "@/components/Alumnos/Cursos/AvanceCurricular/SituacionAcademica.vue";

export default {
  props: ["data"],

  components: {
    HistorialNotas,
    SituacionAcademica,
  },

  data() {
    return {
      active: "actualizarDatos",
    };
  },

  methods: {
    openTab(item) {
      this.active = item;
    },
  },

  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },
};
</script>
<style>
@media (max-width: 450px) {
  .tabs-custom {
    background: #ffffff;
    height: 45px;
    padding: 1rem 0.5rem 0rem;
  }
}
</style>
