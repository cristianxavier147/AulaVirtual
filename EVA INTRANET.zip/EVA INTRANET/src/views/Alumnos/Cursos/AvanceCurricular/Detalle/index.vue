<template>
  <div id="" class="pb-24 mx-4 align-middle pb-responsive cont-final">
    <div id="contTitle" class="mb-5 text-left size-text-24">
      <span class="block font-bold">Avance Curricular</span>
    </div>
    <div id="contSearchInter" class="mb-2 text-left">
      <div class="inline-flex">
        <router-link to="/alumnos/cursos/avance-curricular">
          <arrow-left-icon class="mr-3" :class="'fill-' + classGeneral" />
        </router-link>
        <span class="font-bold size-text-20 size-text-res-14">{{ this.$route.params.slug | capitalize }}</span>
      </div>
    </div>
    <div class="grid w-full grid-cols-1 mb-2 lg:grid-cols-3 md:grid-cols-2">
      <div class="col-span-2 pl-0 pr-2 mb-3">
        <input type="text" name="" class="w-full bg-white  font-bold p-2.5" disabled :placeholder="'Facilitador : ' + profesor" />
      </div>
    </div>
    <div v-if="!preloader">
      <div class="mb-5 text-left title-nivel">
        <span class="font-bold size-text-16 size-text-res-14">Detalles de notas</span>
      </div>
      <div class="scroll-horizontal">
        <table class="table w-full">
          <thead class="bg-white">
            <tr>
              <th class="p-2 font-bold text-gray-400 size-text-12">Tipo prueba</th>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12">Descripción</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Nota</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Peso</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Ponderación</th>
            </tr>
          </thead>
          <tbody v-if="detalle.length > 0">
            <tr v-for="(item, index) in detalle" :key="index">
              <td class="p-3 font-bold text-center size-text-12">{{ porcentajes[index].CodigoCalificacion }}</td>
              <td class="p-3 font-bold text-left size-text-12">{{ item.TipoNotaNombre | capitalize }}</td>
              <td class="p-3 font-bold text-center size-text-12">{{ Number(porcentajes[index].Valor).toFixed(0) }}</td>
              <td class="p-3 font-bold text-center size-text-12">{{ porcentajes[index].Disponible1 }}</td>
              <td class="p-3 font-bold text-center size-text-12">{{ (porcentajes[index].Valor * porcentajes[index].Disponible1.replace("%", "")) / 100 }}</td>
            </tr>
            <tr>
              <td class="p-3 font-bold text-center size-text-12">PF</td>
              <td class="p-3 font-bold text-left size-text-12">
                {{ "PROMEDIO FINAL" | capitalize }}
              </td>
              <td class="p-3 font-bold text-center size-text-12">{{ Promedio }}</td>
              <td class="p-3 font-bold text-center size-text-12"></td>
              <td class="p-3 font-bold text-center size-text-12">{{ ponderadoComputed }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="scroll-horizontal">
        <table class="table w-full">
          <thead class="bg-white">
            <tr>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12"></th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Programadas</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Dictadas</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Inasistidas</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Con tardanzas</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-3 font-bold text-left size-text-12">CLASES</td>
              <td class="p-3 text-center size-text-12">{{ total }}</td>
              <td class="p-3 text-center size-text-12">{{ estoy }}</td>
              <td class="p-3 text-center size-text-12">{{ faltas.length }}</td>
              <td class="p-3 text-center size-text-12">{{ tardanzas.length }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="scroll-horizontal">
        <table class="table w-full">
          <thead class="bg-white">
            <tr>
              <th class="p-2 font-bold text-left text-gray-400 size-text-12"></th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Permitidas</th>
              <th class="p-2 font-bold text-center text-gray-400 size-text-12">Efectivas</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-3 font-bold text-left size-text-12">INASISTENCIAS</td>
              <td class="p-3 text-center size-text-12">{{ permitidas }}%</td>
              <td class="p-3 text-center size-text-12">{{ ntardanzas }} (0,00%). 5 Tardanzas = 1 Inasistencia</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div v-else>
      <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>
    </div>
    <IrClase />
  </div>
</template>

<script>
import IrClase from "@/components/Button/IrClase";
import { nameCursoService } from "@/mixins/nameCurso";
import ArrowLeftIcon from "@/components/Icons/arrowLeftIcon.vue";

export default {
  components: {
    IrClase,
    ArrowLeftIcon,
  },

  data() {
    return {
      detalle: [],
      porcentajes: [],
      total: "",
      estoy: "",
      profesor: "",
      faltas: [],
      tardanzas: [],
      permitidas: "",
      ntardanzas: "",
      Promedio: 0,
      preloader: true,
    };
  },

  methods: {
    allData() {
      let store = JSON.parse(localStorage.getItem("data"));

      var formdataNotas = {
        IdAlumno: store.user_id_actor,
        IdSeccion: this.$route.query.id_seccion,
      };

      this.$store.dispatch("cursoStore/notascurso", formdataNotas).then((response) => {
        if (response.success == true) {
          let data = response.results;
          this.detalle = data.ResLstPromedios === null ? [] : data.ResLstPromedios;
          this.porcentajes = data.ResListAlumnoCursoNota === null ? [] : data.ResListAlumnoCursoNota;
          this.Promedio = Number(data.Promedio).toFixed(0);
        }
      });

      var formdataCurso = {
        IdTipoUsuario: store.user_type_usuario,
        IdSeccion: this.$route.query.id_seccion,
        CodigoAlumno: store.user_codigo,
      };

      this.$store.dispatch("cursoStore/informacioncurso", formdataCurso).then((response) => {
        if (response.success == true) {
          let data = response.results;
          this.total = data.TotalSemana;
          this.estoy = data.SemanaPorcentaje;
          this.profesor = data.Nombres + " " + data.Apellidos;
        }
      });

      var formdataAsistencia = {
        IdAlumno: store.user_id_actor,
        IdSeccion: this.$route.query.id_seccion,
      };

      this.$store.dispatch("cursoStore/asitenciacurso", formdataAsistencia).then((response) => {
        if (response.success == true) {
          let data = response.results;
          data.lstAlumnoCursoAsistencia.map((vl) => {
            if (vl.Valor === "F") {
              this.faltas.push(vl);
            } else if (vl.Valor === "T") {
              this.tardanzas.push(vl);
            }
          });
          this.permitidas = isNaN(data.IntNroFaltas / data.IntPuaFaltas) ? 0 : Number(((data.IntNroFaltas / data.IntPuaFaltas) * 100).toFixed(0));
          this.ntardanzas = data.IntNroTardanzas;
          this.preloader = false;
        }
      });
    },
  },

  filters: {
    capitalize(value) {
      return nameCursoService.palabraFiltrada(value);
    },
  },

  computed: {
    ponderadoComputed() {
      let arr = this.porcentajes.map((x) => {
        let p = (x.Valor * x.Disponible1.replace("%", "")) / 100;
        return p;
      });
      return Number(arr.reduce((a, b) => a + b, 0)).toFixed(2);
    },
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },

  created() {
    this.allData();
  },
};
</script>
