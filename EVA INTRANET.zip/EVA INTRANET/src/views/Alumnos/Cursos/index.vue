<template>
  <div class="md:mx-4 lg:mx-4 cont-final">
    <div class="st-fix-cursos">
      <div id="contTitle" class="mb-5 text-left">
        <span class="font-bold size-text-24 size-text-res-16">{{ capitalize }}</span>
        <select :class="classGeneral" class="md:mt-4 lg:mt-4 mt-3 w-full size-text-16 size-text-res-12 md:border-gray-200 lg:border-gray-200 border  border-gray-400 font-bold p-2.5 pl-4 h-fullme " style="height: 50px;border-radius: 5px;color:#7f8794" v-model="component" @change="selectComponent()" :disabled="endedCourse">
          <option class="font-bold" selected disabled> Seleccione </option>
          <option class="font-bold" value="clases">Clases</option>
          <option class="font-bold" value="notas">Notas</option>
          <option class="font-bold" value="asistencia">Asistencia</option>
          <option class="font-bold" value="contacto">Contacto</option>
          <option class="font-bold" value="informacion">Información</option>
        </select>
      </div>
    </div>

    <div id="contDetailCursos">
      <component v-bind:is="currentComponent"></component>
    </div>
  </div>
</template>

<script>
import MarcaRapida from "@/components/Dashboard/MarcacionRapida/MarcaRapida";
import Clases from "@/components/Alumnos/Cursos/Clases";
import Notas from "@/components/Alumnos/Cursos/Notas";
import Asistencia from "@/components/Alumnos/Cursos/Asistencia";
import Contacto from "@/components/Alumnos/Cursos/Contacto";
import Informacion from "@/components/Alumnos/Cursos/Informacion";
import { nameCursoService } from "@/mixins/nameCurso";
import { eventBus } from "@/config/eventBus";
export default {
  components: {
    Clases,
    Notas,
    Asistencia,
    Contacto,
    Informacion,
    MarcaRapida,
  },
  data() {
    return {
      currentComponent: "clases",
      component: "clases",
    };
  },
  methods: {
    selectComponent() {
      this.currentComponent = this.component;
    },

    refreshSelect() {
      this.currentComponent = "clases";
      this.component = "clases";
    },
  },
  computed: {
    capitalize() {
      let route = this.$route.params.slug;
      return nameCursoService.palabraFiltrada(route);
    },
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
    endedCourse() {
      return false;
    },
  },
  created() {
    eventBus.$on("refreshCurso", this.refreshSelect);
  },
};
</script>
