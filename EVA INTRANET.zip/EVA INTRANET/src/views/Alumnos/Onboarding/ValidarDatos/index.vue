<template>
  <div>
    <FormValidar />
  </div>
</template>

<script>
import FormValidar from "@/components/Alumnos/Onboarding/FormValidar";
export default {
  name: "ValidarDatos",
  components: {
    FormValidar,
  },
};
</script>

<style></style>
