<template>
  <div>
    <FormContinuar />
  </div>
</template>

<script>
import FormContinuar from "@/components/Alumnos/Onboarding/FormContinuar";
export default {
  name: "Continuar",
  components: {
    FormContinuar,
  },
};
</script>

<style></style>
