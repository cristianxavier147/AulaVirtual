<template>
  <div>
    <FormFinalizar />
  </div>
</template>

<script>
import FormFinalizar from "@/components/Alumnos/Onboarding/FormFinalizar";
export default {
  name: "Password",
  components: {
    FormFinalizar,
  },
};
</script>

<style></style>
