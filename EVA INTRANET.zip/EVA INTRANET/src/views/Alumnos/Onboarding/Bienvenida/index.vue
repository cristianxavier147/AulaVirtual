<template>
  <div>
    <FormBienvenida />
  </div>
</template>

<script>
import FormBienvenida from "@/components/Alumnos/Onboarding/FormBienvenida";

export default {
  name: "Bienvenido",
  components: {
    FormBienvenida,
  },
};
</script>

<style></style>
