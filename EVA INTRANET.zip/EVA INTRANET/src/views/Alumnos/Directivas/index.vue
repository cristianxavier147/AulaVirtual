<template>
  <div>
    <h1>hola</h1>
    <Directivas />
  </div>
</template>

<script>
import Directivas from "@/components/Alumnos/Condiciones/Directivas";

export default {
  name: "Main",
  components: {
    Directivas,
  },
};
</script>

<style></style>
