<template>
<div class="lg:ml-5 md:ml-5 mx-0 cont-final">
    <div id="contTitle" class="mb-5 text-left text-2xl">
        <div class="inline-flex">
            <router-link :to="{ path: '/alumnos/cursos/curso/'+this.$route.query.curso, query : { id_seccion : this.$route.query.id_seccion , credito: this.$route.query.credito} }">
                <svg xmlns="http://www.w3.org/2000/svg" width="15.334" height="13.35" viewBox="0 0 15.334 13.35" class="mr-3 mt-1">
                    <g id="Grupo_18846" data-name="Grupo 18846" transform="translate(15.334 13.35) rotate(180)">
                        <g id="Grupo_225" data-name="Grupo 225">
                        <path id="Trazado_67" data-name="Trazado 67" d="M185.149,113.161l-5.8-5.722a.953.953,0,0,0-1.339,1.358l4.143,4.089h-11.1a.954.954,0,0,0,0,1.907h11.1l-4.143,4.089a.953.953,0,1,0,1.339,1.358l5.8-5.721a.953.953,0,0,0,0-1.358Z" transform="translate(-170.1 -107.165)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                        </g>
                    </g>
                </svg>
            </router-link>
            <span class="size-text-20 size-text-res-14 font-bold">Horario profesor</span>
        </div>
    </div>
    <div class="pb-32">
        <div class="grid lg:grid-cols-3 md:grid-cols-3 grid-cols-2">
            <div id="conthorarioresponsive" class="col-span-3 lg:pr-3 md:pr-3 p-0">
                <div class="flex bg-white p-5 mb-3">
                    <img
                        src="@/assets/avatar/avatar.png"
                        alt="accesso"
                        style="width: 105px ; height: 105px"
                    />
                    <div class="text-left pl-5 mt-8">
                        <div class="size-text-14 font-bold text-gray-400 mb-1">Profesor@</div>
                        <div class="size-text-18 font-bold mb-3">{{valores.Nombres | filterText}},  {{valores.Apellidos | filterText }}</div>
                    </div>
                </div>
                <!-- <div class="bg-white p-5">
                    <div class="text-left">
                        <div class="mb-6 font-bold text-gray-400 size-text-14">Horario: {{valores.TurnoNombre | filterText}}</div>
                        <div class="grid grid-cols-2 mb-5 font-medium size-text-12">
                            <span class="col-span-1">Sede: {{valores.SedeNombre | filterText}}</span>
                            <span class="col-span-1">Aula: {{valores.AmbienteNombre}}</span>
                        </div>
                        <div class="grid grid-cols-2 mb-3 font-medium size-text-12">
                            <span class="col-span-1">{{valores.PromocionCodigo}}</span>
                            <span class="col-span-1">{{valores.IdUnidadNegocio == "1" ? 'Créditos' : 'Horas'}}: {{this.$route.query.credito}}</span>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="col-span-3 lg:mr-5 md:mr-5 mr-0 relative">
                <div class="w-full text-center preloader-content-horario" v-if="preloader">
                    <div class="lds-dual-ring loaderCursos" :class="classGeneral"></div>  
                </div>
                <div class="md:px-4 lg:px-4 px-3 py-3 bg-white" >
                    <div class="flex py-8 px-5 md:mb-3 lg:mb-3 mb-1">
                        <span class="mr-6 size-text-16 font-bold text-gray-900 cursor-pointer" @click="functionDates(4)">Hoy</span>
                        <span class="mr-5 flex justify-center items-center">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="6.844" height="11.562" viewBox="0 0 6.844 11.562" class="cursor-pointer" @click="nextPrev(1)">
                                <path id="Trazado_16456" data-name="Trazado 16456" d="M11.3,5.187,6.466.291A.991.991,0,0,0,5.056.3L.264,5.157A.986.986,0,0,0,1.671,6.538L5.764,2.392,9.855,6.53A.986.986,0,1,0,11.3,5.187Z" transform="translate(0 11.562) rotate(-90)" fill="#bdbdbd"/>
                            </svg>
                            <svg  class="ml-5 cursor-pointer" xmlns="http://www.w3.org/2000/svg" width="6.844" height="11.562" viewBox="0 0 6.844 11.562" @click="nextPrev(2)">
                                <path id="Trazado_16455" data-name="Trazado 16455" d="M11.3,5.187,6.466.291A.991.991,0,0,0,5.056.3L.264,5.157A.986.986,0,0,0,1.671,6.538L5.764,2.392,9.855,6.53A.986.986,0,1,0,11.3,5.187Z" transform="translate(6.844 0) rotate(90)" fill="#bdbdbd"/>
                            </svg>
                        </span>
                        <span class="mr-2 size-text-16 font-medium">{{this.mes}}</span>
                        <span class="mr-2 size-text-16 font-medium">{{this.year}}</span>
                    </div>
                    <div class="flex md:mb-14 lg:mb-14 mb-4">
                        <div class="col-span-1 mr-2 md:block lg:block hidden" style="width: 50px"></div>
                        <div 
                            class="col-span-1 md:flex lg:flex hidden md:border lg:border border-gray-300 text-gray-300  justify-center items-center mx-1 py-4 rounded-lg size-text-14 font-bold" 
                            style="width: 125px" 
                            v-for="(item , index) in semana" 
                            :key="index"
                            :class="dias[index] === diasenial ? 'fnd-'+classGeneral+' text-white' : ''"
                        >
                            <div>
                                <span class="md:block lg:block hidden">{{item.des}}</span>
                                <span class="md:hidden lg:hidden block mb-3">{{item.mov}}</span>
                                <span 
                                    class="rounded-xl w-6 h-6 justify-center items-center md:flex lg:flex hidden md:text-gray-300 lg:text-gray-300"
                                >{{dias[index]}}</span>
                            </div>
                        </div>
                        <div 
                            class="col-span-1 md:hidden lg:hidden flex md:border lg:border border-gray-300 text-gray-300  justify-center items-center mx-1 py-4 rounded-lg size-text-14 font-bold" 
                            style="width: 90px" 
                            v-for="(item , index) in semana" 
                            :key="index+1*1000"
                        >
                            <div>
                                <span class="md:block lg:block hidden">{{item.des}}</span>
                                <span class="md:hidden lg:hidden block mb-3">{{item.mov}}</span>
                                <span 
                                    class="rounded-xl w-6 h-6 justify-center items-center md:hidden lg:hidden flex"
                                    :class="dias[index] === diasenial ? ' md:text-gray-300 lg:text-gray-300 fnd-'+classGeneral+' text-white' : ''"
                                    @click="selectDay(index + 1 , dias[index])"
                                >{{dias[index]}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="md:hidden lg:hidden block mb-7">
                        <div class="size-text-16 font-bold text-gray-400">{{fecha}}</div>
                    </div>

                    <!-- modo escritorio -->
                    <div class="md:flex lg:flex hidden" v-for="(item , index) in horas" :key="index">
                        <div class="col-span-1 size-text-10" style="width: 60px ; height:55px"> 
                            <div class="-mt-3">{{item.hora + ' ' +item.tiempo}} </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.lun" class="flex">
                                    <div :class="'bg-'+item.lun.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.lun.rango )) +'px;margin-top:'+item.lun.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.lun.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.lun.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.lun.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.lun}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.mar" class="flex">
                                    <div :class="'bg-'+item.mar.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.mar.rango )) +'px;margin-top:'+item.mar.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.mar.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.mar.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.mar.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.mar}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.mie" class="flex">
                                    <div :class="'bg-'+item.mie.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.mie.rango )) +'px;margin-top:'+item.mie.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.mie.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.mie.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.mie.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.mie}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.jue" class="flex">
                                    <div :class="'bg-'+item.jue.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.jue.rango )) +'px ; margin-top:'+item.jue.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.jue.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.jue.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.jue.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.jue}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.vie" class="flex">
                                    <div :class="'bg-'+item.vie.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.vie.rango )) +'px;margin-top:'+item.vie.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.vie.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.vie.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.vie.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.vie}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.sab" class="flex">
                                    <div :class="'bg-'+item.sab.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.sab.rango )) +'px;margin-top:'+item.sab.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.sab.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.sab.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.sab.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.sab}}</div>
                            </div>
                        </div>
                        <div class="col-span-1 size-text-10 border-r border-l relative cont-horario-int" >
                            <div class="absolute">
                                <div v-if="item.dom" class="flex">
                                    <div :class="'bg-'+item.dom.bg+'-500'" class="table z-10 rounded-2xl" :style="'height:'+ ((item.dom.rango )) +'px;margin-top:'+item.dom.minutos + 'px ; width: 3px'"></div>
                                    <div class="text-left z-10" :style="'margin-top:'+item.dom.minutos + 'px'">
                                        <span class="block size-text-10 font-bold ml-1 mt-1">{{item.dom.curso | filterText}}</span>
                                        <span class="block size-text-10 text-gray-400 font-bold ml-1">{{item.dom.hora}}</span>
                                    </div>
                                </div>
                                <div v-else>{{item.dom}}</div>
                            </div>
                        </div>
                    </div>

                    <!-- modo movil -->
                    <div class="md:hidden lg:hidden flex" v-for="(item , i) in horas" :key="(i+5)*10">
                        <div class="col-span-1 size-text-10" style="width: 50px ; height:55px"> {{item.hora + ' ' +item.tiempo}} </div>
                        <div v-if="actual === 0" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.lun" class="flex">
                                <div :class="'bg-'+item.lun.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.lun.rango)) + 'px ; margin-top : '+item.lun.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.lun.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.lun.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.lun.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.lun}}</div>
                        </div>
                        <div v-if="actual === 1" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.mar" class="flex">
                                <div :class="'bg-'+item.mar.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.mar.rango)) + 'px ; margin-top : '+item.mar.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.mar.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.mar.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.mar.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.mar}}</div>
                        </div>
                        <div v-if="actual === 2" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.mie" class="flex">
                                <div :class="'bg-'+item.mie.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.mie.rango)) + 'px ; margin-top : '+item.mie.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.mie.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.mie.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.mie.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.mie}}</div>
                        </div>
                        <div v-if="actual === 3" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.jue" class="flex">
                                <div :class="'bg-'+item.jue.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.jue.rango)) + 'px ; margin-top : '+item.jue.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.jue.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.jue.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.jue.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.jue}}</div>
                        </div>
                        <div v-if="actual === 4" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.vie" class="flex">
                                <div :class="'bg-'+item.vie.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.vie.rango)) + 'px ; margin-top : '+item.vie.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.vie.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.vie.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.vie.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.vie}}</div>
                        </div>
                        <div v-if="actual === 5" class="col-span-1 size-text-10 border-t" style="width: 100% ; height:60px">
                            <div v-if="item.sab" class="flex">
                                <div :class="'bg-'+item.sab.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.sab.rango)) + 'px ; margin-top : '+item.sab.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.sab.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.sab.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.sab.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.sab}}</div>
                        </div>
                        <div v-if="actual === 6" class="col-span-1 size-text-10 border-b border-t" style="width: 100% ; height:60px">
                            <div v-if="item.dom" class="flex">
                                <div :class="'bg-'+item.dom.bg+'-500'" class="ml-2 mt-1 w-1 z-10 rounded-2xl" :style="'height:'+ ((item.dom.rango)) + 'px ; margin-top : '+item.dom.minutos+'px'"></div>
                                <div class="text-left z-10" :style="'margin-top:'+item.dom.minutos + 'px'">
                                    <span class="block size-text-10 font-bold ml-2 mt-1">{{item.dom.curso | filterText}}</span>
                                    <span class="block ml-2 text-gray-400 font-bold">{{item.dom.hora}}</span>
                                </div>
                            </div>
                            <div v-else>{{item.dom}}</div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import { nameCursoService } from "@/mixins/nameCurso";
export default {
    data() {
        return {
            valores: [],
            actual: '',
            mes:'',
            year: '',
            dia: '',
            dias: [],
            fecha:'',
            semana : [
                {'des' : "Lun" , 'mov' : 'L' , 'normal' : "Lunes"},
                {'des' : "Mar" , 'mov' : 'M' , 'normal' : "Martes"},
                {'des' : "Mie" , 'mov' : 'X' , 'normal' : "Miercoles"},
                {'des' : "Jue" , 'mov' : 'J' , 'normal' : "Jueves"},
                {'des' : "Vie" , 'mov' : 'V' , 'normal' : "Viernes"},
                {'des' : "Sab" , 'mov' : 'S' , 'normal' : "Sabado"},
                {'des' : "Dom" , 'mov' : 'D' , 'normal' : "Domingo"},
            ],
            meses: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio','Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
            horas: [
                {
                    hora: 6,
                    timer: 600,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },{
                    hora: 7,
                    timer: 700,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 8,
                    timer: 800,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 9,
                    timer: 900,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 10,
                    timer: 1000,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 11,
                    timer: 1100,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 12,
                    timer: 1200,
                    tiempo: 'am',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 13,
                    timer: 1300,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 14,
                    timer: 1400,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 15,
                    timer: 1500,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 16,
                    timer: 1600,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 17,
                    timer: 1700,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 18,
                    timer: 1800,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 19,
                    timer: 1900,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 20,
                    timer: 2000,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 21,
                    timer: 2100,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 22,
                    timer: 2200,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
                {
                    hora: 23,
                    timer: 2300,
                    tiempo: 'pm',
                    lun: null,
                    mar: null,
                    mie: null,
                    jue: null,
                    vie: null,
                    sab: null,
                    dom: null,
                },
            ],
            preloader: false,
            data: [],
            diaincial: '',
            mesactual: '',
            diasenial: '',
        }
    },

    methods: {
        functionDates(type){
            if(type === 1 || type === 4){
                var fecha = new Date()
                this.actual = type === 1 ? (fecha.getDay() === 0 ? 7 : fecha.getDay()) - 1 : ''
                this.diasenial = fecha.getDate()
                if(type === 4){
                    this.dias = []
                }
            }else if(type === 2){
                var fecha = new Date(this.year,this.mesactual,this.diaincial)
                if(fecha.getDay() === 0){
                    fecha.setDate(fecha.getDate() + 1)
                }else if(fecha.getDay() === 6){
                    fecha.setDate(fecha.getDate() + 2)
                }else if(fecha.getDay() === 5){
                    fecha.setDate(fecha.getDate() + 3)
                }else if(fecha.getDay() === 4){
                    fecha.setDate(fecha.getDate() + 4)
                }else if(fecha.getDay() === 3){
                    fecha.setDate(fecha.getDate() + 5)
                }else if(fecha.getDay() === 2){
                    fecha.setDate(fecha.getDate() + 6)
                }else if(fecha.getDay() === 1){
                    fecha.setDate(fecha.getDate() + 7)
                }
                this.dias = []
            }else if(type === 3){
                var fecha = new Date(this.year,this.mesactual,this.diaincial)
                if(fecha.getDay() === 0){
                    fecha.setDate(fecha.getDate() - 1)
                }else if(fecha.getDay() === 6){
                    fecha.setDate(fecha.getDate() - 2)
                }else if(fecha.getDay() === 5){
                    fecha.setDate(fecha.getDate() - 3)
                }else if(fecha.getDay() === 4){
                    fecha.setDate(fecha.getDate() - 4)
                }else if(fecha.getDay() === 3){
                    fecha.setDate(fecha.getDate() - 5)
                }else if(fecha.getDay() === 2){
                    fecha.setDate(fecha.getDate() - 6)
                }else if(fecha.getDay() === 1){
                    fecha.setDate(fecha.getDate() - 7)
                }
                this.dias = []
            }

            var mes = fecha.getMonth()
            var dia = fecha.getDay()

            var cantidadDias = new Date(fecha.getFullYear(), mes + 1 , 0).getDate()

            if(dia !== 0){
                var primerdia = fecha.getDate() - fecha.getDay() + 1
                var utlimodia = primerdia + 7
            }else{
                var primerdia = fecha.getDate() - 6
                var utlimodia = primerdia + 7
            }
            
            for (let i = primerdia ; i < utlimodia ; i++) {
                if(i <= cantidadDias){
                    this.dias.push(i)
                }
            }

            if(this.dias.length < 7){
                var cont = 7 - this.dias.length
                for (let j = 1; j <= cont ; j++) {
                    this.dias.push(j)
                }
            }

            // this.fecha = this.semana[(fecha.getDay() === 0 ? 7 : getDay()) - 1].normal + ', ' + fecha.getDate() + ' de ' + this.meses[mes] + ' ' + fecha.getFullYear()  
            this.dia = (dia === 0 ? 7 : dia) - 1
            this.mes = this.meses[mes]
            this.year = fecha.getFullYear()
            this.diaincial = primerdia
            this.mesactual = mes

            if(type === 4){
                this.data = []
                console.log('ss')
                this.allData()
            }
        },
        selectDay(item,dia){
            var fecha = new Date()
            var mes = fecha.getMonth()
            var cantidadDias = new Date(fecha.getFullYear(), mes + 1 , 0).getDate()
            
            if(dia < cantidadDias){
                this.fecha = this.semana[item - 1].normal + ', ' + dia + ' de ' + this.meses[mes] + ' ' + fecha.getFullYear()  
            }else{
                this.fecha = this.semana[item - 1].normal + ', ' + dia + ' de ' + this.meses[mes + 1] + ' ' + fecha.getFullYear()  
            }
            this.actual = item - 1
        },

        nextPrev(type){
            let store = JSON.parse(localStorage.getItem('data'))
            if(type === 2){
                this.preloader = true
                var fecha = new Date(this.year,this.mesactual,this.diaincial)
                if(fecha.getDay() === 0){
                    fecha.setDate(fecha.getDate() + 1)
                }else if(fecha.getDay() === 6){
                    fecha.setDate(fecha.getDate() + 2)
                }else if(fecha.getDay() === 5){
                    fecha.setDate(fecha.getDate() + 3)
                }else if(fecha.getDay() === 4){
                    fecha.setDate(fecha.getDate() + 4)
                }else if(fecha.getDay() === 3){
                    fecha.setDate(fecha.getDate() + 5)
                }else if(fecha.getDay() === 2){
                    fecha.setDate(fecha.getDate() + 6)
                }else if(fecha.getDay() === 1){
                    fecha.setDate(fecha.getDate() + 7)
                }
                
                this.functionDates(2)

            }else{
                this.preloader = true
                var fecha = new Date(this.year,this.mesactual,this.diaincial)
                if(fecha.getDay() === 0){
                    fecha.setDate(fecha.getDate() - 1)
                }else if(fecha.getDay() === 6){
                    fecha.setDate(fecha.getDate() - 2)
                }else if(fecha.getDay() === 5){
                    fecha.setDate(fecha.getDate() - 3)
                }else if(fecha.getDay() === 4){
                    fecha.setDate(fecha.getDate() - 4)
                }else if(fecha.getDay() === 3){
                    fecha.setDate(fecha.getDate() - 5)
                }else if(fecha.getDay() === 2){
                    fecha.setDate(fecha.getDate() - 6)
                }else if(fecha.getDay() === 1){
                    fecha.setDate(fecha.getDate() - 7)
                }
                // console.log(fecha.setDate(fecha.getDate() - 1))
                this.functionDates(3)
            }


            var mes = parseInt(fecha.getMonth()) + 1
            var dia = fecha.getDate() - fecha.getDay() + 1

            var initial = (dia < 10 ? '0'+dia : dia) + '-' + (mes < 10 ? '0' + mes : mes ) + '-' + fecha.getFullYear()
            fecha.setDate(fecha.getDate() + 6 - fecha.getDay())
            var newmonth = parseInt(fecha.getMonth()) + 1
            var final = (fecha.getDate() < 10 ? '0'+(fecha.getDate() + 1) : (fecha.getDate() + 1)) + '-' + (newmonth < 10 ? '0' + newmonth : newmonth) + '-' + fecha.getFullYear()

            var formdata = {
                'IdFacilitador' : this.$route.params.slug,
                'FechaInicio' : initial,
                'FechaFin' : final,
            }

            this.$store.dispatch('cursoStore/horarioFacilitador' , formdata).then(
                (response) => {
                    if (response.success == true) {
                        this.data = response.results.lisQueryHorarios
                        this.distrubucionHorario()
                        this.preloader = false
                    }
                }
            )


            var data = {
                'IdTipoUsuario' : store.user_type_usuario,
                'IdSeccion' : this.$route.query.id_seccion
            }

            this.$store.dispatch('cursoStore/informacioncurso' , data).then(
                (response) => {
                    if(response.success == true){
                        this.valores = response.results
                    }
                }
            )
        },

        allData(){
            let store = JSON.parse(localStorage.getItem('data'))
            this.preloader = true
            var fecha = new Date()
            var mes = parseInt(fecha.getMonth()) + 1

            var dia = fecha.getDate() - fecha.getDay() + 1
            var initial = (dia < 10 ? '0'+dia : dia) + '-' + (mes < 10 ? '0' + mes : mes ) + '-' + fecha.getFullYear()
            fecha.setDate(fecha.getDate() + 6 - fecha.getDay())
            var newmonth = parseInt(fecha.getMonth()) + 1
            var final = (fecha.getDate() < 10 ? '0'+(fecha.getDate() + 1) : (fecha.getDate() + 1)) + '-' + (newmonth < 10 ? '0' + newmonth : newmonth) + '-' + fecha.getFullYear()
            
            var formdata = {
                'IdFacilitador' : this.$route.params.slug,
                'FechaInicio' : initial,
                'FechaFin' : final,
            }

            this.$store.dispatch('cursoStore/horarioFacilitador' , formdata).then(
                (response) => {
                    if (response.success == true) {
                        this.data = response.results.lisQueryHorarios
                        this.distrubucionHorario()
                        this.preloader = false
                    }
                }
            )


            var data = {
                'IdTipoUsuario' : store.user_type_usuario,
                'IdSeccion' : this.$route.query.id_seccion
            }

            this.$store.dispatch('cursoStore/informacioncurso' , data).then(
                (response) => {
                    if(response.success == true){
                        this.valores = response.results
                    }
                }
            )
        },

        formatHorario(value) {
            value = value.toString();
            if(value.length > 3){
                return value.charAt(0) + value.charAt(1) + ":" + value.slice(2);  
            }else{
                return '0' + value.charAt(0) + ":" + value.slice(1);  
            }
        },

        ranges(vfin , vinicio , type){

            let inicio = this.formatHorario(vinicio)
            let fin = this.formatHorario(vfin)

            let inicioMinutos = parseInt(inicio.substr(3,2));
            let inicioHoras = parseInt(inicio.substr(0,2));
            
            let finMinutos = parseInt(fin.substr(3,2));
            let finHoras = parseInt(fin.substr(0,2));

            let transcurridoMinutos = finMinutos - inicioMinutos;
            let transcurridoHoras = finHoras - inicioHoras;
            
            if (transcurridoMinutos < 0) {
                transcurridoHoras--;
                transcurridoMinutos = 60 + transcurridoMinutos;
            }
            
            let horas = transcurridoHoras.toString();
            let minutos = transcurridoMinutos.toString();
            
            if (horas.length < 2) {
                horas = "0"+horas;
            }
            
            if (horas.length < 2) {
                horas = "0"+horas;
            }

            if(type == 1){
                return parseInt(horas*60) + parseInt(minutos)
            }else{
                return inicioMinutos
            }
        },

        validatehora(inicio, timer){
            if( timer <= inicio && inicio <= timer+60 ){
                return true
            }else{
                return false
            }
        },

        distrubucionHorario(){
            if(this.data.length > 0){
                this.data.map(vl => {
                    if(vl.Dia === 1){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.lun = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 2){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.mar = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 3){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.mie = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 4){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.jue = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 5){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.vie = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 6){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.sab = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }else if(vl.Dia === 7){
                        this.horas.map(hr => {
                            let validate = this.validatehora(vl.Inicio , hr.timer)
                            if(validate === true){
                                hr.dom = {
                                            'curso' : vl.CursoNombre,
                                            'hora' :  this.formatHorario(vl.Inicio)+' - '+this.formatHorario(vl.Fin),
                                            'rango' : this.ranges(vl.Fin,vl.Inicio,1),
                                            'minutos': this.ranges(vl.Fin,vl.Inicio,2),
                                            'bg' : 'red'
                                        }
                            }
                        })
                    }
                })
            }else{
                this.horas.map(vl => {
                    vl.lun = null
                    vl.mar = null
                    vl.mie = null
                    vl.jue = null
                    vl.vie = null
                    vl.sab = null
                    vl.dom = null
                })
            }
        }
    },

    filters: {
        filterText(value){
            return nameCursoService.palabraFiltrada(value);
        },
    },

    created() {
        this.functionDates(1)
        this.allData()
    },

    computed: {
        store(){
        return JSON.parse(localStorage.getItem('data'))
        },

        classGeneral(){
        return localStorage.getItem('classGeneral')
        }
    },
}
</script>