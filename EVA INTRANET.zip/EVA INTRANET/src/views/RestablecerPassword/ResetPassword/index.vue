<template>
  <div class="h-screen" :class="'fnd-' + classGeneral ">
    <ResetPassword />
  </div>
</template>

<script>
import ResetPassword from "@/components/OlvidePassword/ResetPassword";
export default {
  name: "RestablecerPass",
  components: {
    ResetPassword,
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
