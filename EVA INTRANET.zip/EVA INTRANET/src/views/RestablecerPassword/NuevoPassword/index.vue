<template>
  <div class="bg-white h-screen" :class="'md:bg-' + classGeneral + '-500'">
    <PasswordNuevo />
  </div>
</template>

<script>
import PasswordNuevo from "@/components/OlvidePassword/PasswordNuevo";
export default {
  name: "NewPassword",
  components: {
    PasswordNuevo,
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style></style>
