<template>
  <div id="app">
    <div v-if="this.$route.meta.auth">
      <div v-if="this.$route.meta.showNavbar">
        <Navbar />
      </div>
      <div class="h-full bg-gray-100">
        <div class="h-full">
          <div class="h-full">
            <div id="wrapper" :class="{ 'content-view': this.$route.meta.showHome }">
              <nav id="sidebar" :class="{ 'content-view': this.$route.meta.showSidebar }">
                <Sidebar @closeSidebar="closeSidebar" @cerrarSession="closemodalsession"/>
              </nav>
              <div id="content" :class="{ 'content-view': this.$route.meta.showContent }">
                <transition name="component-fade" mode="out-in">
                  <router-view />
                </transition>
                <!-- <Notificaciones /> -->
              </div>
              <div id="horarios" :class="{ 'content-view': this.$route.meta.showHoraios }">
                <CursosyHorarios />
              </div>
            </div>
          </div>
        </div>
        <div id="menuResponsive" class="py-2 bg-gray-100" v-if="this.$route.meta.showMenu">
          <div class="grid w-full grid-cols-3">
            <div class="col-span-1 p-2 ">
              <div class="flex justify-start items-center text-left" @click="openNav(1,1)">
                <img v-if="activeSidebar === false" src="@/assets/global/menu.svg" alt="accesso" class="ml-3" />
                <img v-if="classGeneral === 'purple' && activeSidebar === true" src="@/assets/global/menu-purple.svg" alt="accesso" class="ml-3" />
                <img v-if="classGeneral === 'red' && activeSidebar === true" src="@/assets/global/menu-red.svg" alt="accesso" class="ml-3" />
                <img v-if="classGeneral === 'blue' && activeSidebar === true" src="@/assets/global/menu-blue.svg" alt="accesso" class="ml-3" />
              </div>
            </div>
            <div class="col-span-1 p-2 ">
              <div class="flex items-center justify-center text-center" @click="openNav(2,1)">
                <img v-if="this.$route.name !== 'dashboard' && activeHome == true" src="@/assets/global/home.svg" alt="accesso" class="mr-2" />
                <img v-if="this.$route.name !== 'dashboard' && activeHome == false" src="@/assets/global/home.svg" alt="accesso" class="mr-2" />
                <img v-if="this.$route.name === 'dashboard' && activeHome == false" src="@/assets/global/home.svg" alt="accesso" class="mr-2" />
                <img v-if="classGeneral === 'purple' && this.$route.name === 'dashboard' && activeHome == true" src="@/assets/global/home-purple.svg" alt="accesso" class="mr-2" />
                <img v-if="classGeneral === 'red' && this.$route.name === 'dashboard' && activeHome == true" src="@/assets/global/home-red.svg" alt="accesso" class="mr-2" />
                <img v-if="classGeneral === 'blue' && this.$route.name === 'dashboard' && activeHome == true" src="@/assets/global/home-blue.svg" alt="accesso" class="mr-2" />
              </div>
            </div>
            <div class="col-span-1 p-2 ">
              <div class="flex justify-end items-center text-right" @click="openNav(3,1)">
                <img v-if="activeCurso === false" src="@/assets/global/cursohorario.svg" alt="accesso" class="mr-3" />
                <img v-if="classGeneral === 'purple' && activeCurso === true" src="@/assets/global/cursohorario-purple.svg" alt="accesso" class="mr-3" />
                <img v-if="classGeneral === 'red' && activeCurso === true" src="@/assets/global/cursohorario-red.svg" alt="accesso" class="mr-3" />
                <img v-if="classGeneral === 'blue' && activeCurso === true" src="@/assets/global/cursohorario-blue.svg" alt="accesso" class="mr-3" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <ModalSessionExpiro  v-if="modalSessionExpiro" @closemodalsession="closemodalsession" />
    </div>
    <div class="h-full" v-else>
      <transition name="slide-fade">
        <router-view />
      </transition>
    </div>
  </div>
</template>

<script>
import Navbar from "@/components/Dashboard/Navbar";
import Sidebar from "@/components/Dashboard/Sidebar";
import Notificaciones from "@/components/Dashboard/Notificaciones/Contenido";
import CursosyHorarios from "@/components/Dashboard/CursosyHorarios/CursosyHorarios";
import { mapMutations } from "vuex";
import ModalSessionExpiro from "@/components/Alertas/CerraSession";

export default {
  name: "Dashboard",
  components: {
    Navbar,
    Sidebar,
    Notificaciones,
    CursosyHorarios,
    ModalSessionExpiro
  },
  data() {
    return {
      vlInicial: "",
      vlFinal: "",
      AdminVer: [],
      modalSessionExpiro: false,
      activeSidebar: false,
      activeHome: true,
      activeCurso: false,
    };
  },
  methods: {
    closeSidebar(item) {
      setTimeout(() => {
        if(this.$route.name === 'login' || this.$route.name === 'preloader') {
          this.openNav(0)
        }else{
          this.openNav(item,2)
        }
      }, 1000);
    },
    openNav(item,type) {
      if (item == 1) {
        let sidebar = document.getElementById("sidebar");
        sidebar.classList.toggle("active");
        this.activeSidebar = !this.activeSidebar
        let horarios = document.getElementById("horarios");
        horarios.classList.remove("active");
        this.activeCurso = false
        if (this.vlFinal == 1) {
          let content = document.getElementById("content");
          content.classList.toggle("inactive");
          this.activeHome = !this.activeHome
        } else {
          let content = document.getElementById("content");
          content.classList.add("inactive");
          this.activeHome = false
        }
      }
      if (item == 2) {
        let sidebar = document.getElementById("sidebar");
        sidebar.classList.remove("active");
        let horarios = document.getElementById("horarios");
        horarios.classList.remove("active");
        let content = document.getElementById("content");
        content.classList.remove("inactive");
        this.activeSidebar = false
        this.activeCurso = false
        this.activeHome = true
        if(type == 1){
          this.$router.push({ name: 'dashboard' }).catch(()=>{})
        }
      }
      if (item == 3) {
        let sidebar = document.getElementById("sidebar");
        sidebar.classList.remove("active");
        this.activeSidebar = false
        let nav = document.getElementById("horarios");
        nav.classList.toggle("active");
        this.activeCurso = !this.activeCurso
        if (this.vlFinal == 3) {
          let content = document.getElementById("content");
          content.classList.toggle("inactive");
          this.activeHome = !this.activeHome
        } else {
          let content = document.getElementById("content");
          content.classList.add("inactive");
          this.activeHome = false
        }

        //caso especifcio en responsive para que vea la seccion de horarios y cursos
        var val = nav.classList.contains("content-view");
        if (!val) nav.classList.add("content-view");
      }
      this.vlFinal = item;
    },
    validateFormat() {
      const route = window.location.host;
      if (route == process.env.VUE_APP_RUTA_IDAT) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_IDAT);
      } else if (route == process.env.VUE_APP_RUTA_ZEGEL) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_ZEGEL);
      } else if (route == process.env.VUE_APP_RUTA_CORRIENTE) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_CORRIENTE);
      } else {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_IDAT);
      }
    },
    closemodalsession(){
      this.modalSessionExpiro = false
    }
    
    
  },
  created() {
    this.closeSidebar(2);
  },
  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style>
@import "~@/assets/styles/global/_global.less";
</style>
