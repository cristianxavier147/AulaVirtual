<template>
  <div>
    <MainBeneficios />
  </div>
</template>

<script>
import MainBeneficios from "@/components/Beneficios/MainBeneficios";
export default {
  name: "Beneficios",
  components: {
    MainBeneficios,
  },
};
</script>

<style></style>
