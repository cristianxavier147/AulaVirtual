<template>
  <div class="h-full">
    <div class="login inicio" :class="'fnd-' + classGeneral ">
      <div class="home">
        <Login />
      </div>
    </div>
  </div>
</template>

<script>
import Login from "@/components/Login/Login";

export default {
  name: "index",
  components: {
    Login,
  },
  data() {
    return {
      valornumerico: 0,
    };
  },

  methods: {
    validateFormat() {
      const route = window.location.host;
      if (route == process.env.VUE_APP_RUTA_IDAT) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_IDAT);
      } else if (route == process.env.VUE_APP_RUTA_ZEGEL) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_ZEGEL);
      } else if (route == process.env.VUE_APP_RUTA_CORRIENTE) {
        localStorage.setItem("classGeneral", process.env.VUE_APP_BG_CORRIENTE);
      } else {
        localStorage.setItem("classGeneral", 'purple');
      }
    },
  },

  created() {
    this.validateFormat();
  },

  computed: {
    store(){
      return JSON.parse(localStorage.getItem('data'))
    },

    classGeneral(){
      return localStorage.getItem('classGeneral')
    }
  },
};
</script>

<style scoped>
@media (max-width: 767px) {
  .inicio {
    height: 100%;
  }
  .inicio > div {
    height: 100%;
  }
}
</style>
