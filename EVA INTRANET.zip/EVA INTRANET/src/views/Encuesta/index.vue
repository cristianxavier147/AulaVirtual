<template>
  <div>
    <EncuestaAlumno />
  </div>
</template>

<script>
import EncuestaAlumno from "../../components/Encuesta/EncuestaAlumno.vue";
export default {
  components: { EncuestaAlumno },
};
</script>

<style></style>
