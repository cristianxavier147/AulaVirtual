<template>
  <div>
    <EncuestaDocente />
  </div>
</template>

<script>
import EncuestaDocente from "../../../components/Encuesta/EncuestaDocente.vue";

export default {
  components: { EncuestaDocente },
};
</script>

<style></style>
