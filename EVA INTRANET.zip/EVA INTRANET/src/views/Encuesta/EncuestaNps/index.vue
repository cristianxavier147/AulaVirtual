<template>
  <div>
    <EncuestaNps />
  </div>
</template>

<script>
import EncuestaNps from "../../../components/Encuesta/EncuestaNps.vue";
export default {
  components: { EncuestaNps },
};
</script>

<style></style>
