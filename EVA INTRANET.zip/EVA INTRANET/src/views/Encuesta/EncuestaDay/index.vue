<template>
  <div>
    <EncuestaDay />
  </div>
</template>

<script>
import EncuestaDay from "../../../components/Encuesta/EncuestaDay.vue";
export default {
  components: { EncuestaDay },
};
</script>

<style></style>
