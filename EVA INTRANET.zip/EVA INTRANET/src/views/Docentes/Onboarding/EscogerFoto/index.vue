<template>
  <div>
    <FotoUser />
  </div>
</template>

<script>
import FotoUser from "@/components/Docentes/Onboarding/FormPhoto";
export default {
  name: "FotoUsuario",
  components: {
    FotoUser,
  },
};
</script>

<style></style>
