<template>
    <div class="md:mx-4 lg:mx-4 text-left mb-28">
        <Navbar class="lg:p-0 pl-2" :data="['Inicio','Mis cursos']" />
        <div class="mb-4">
            <span class="size-text-40 font-bold lg:p-0 pl-2">Mis cursos</span>
        </div>

        <div class="mb-5" v-for="(item , index) in newArr" :key="index">
            <div class="nav relative" @click="openTab(index)">
                <span class="size-text-20 font-bold">{{item.PeriodoCodigo}}</span>
                <SvgComponent :id="'open'+index" svg="openTab" class="absolute right-5 top-5" style="display: block"/>
                <SvgComponent :id="'close'+index" svg="closeTab" class="absolute right-5 top-5" style="display: none"/>
            </div>
            <div :id="'content'+index" class="mt-6" style="display: none">
                <div class="grid grid-cols-3">
                    <div class="lg:col-span-1 col-span-3 lg:mr-3 mr-0 mb-3" v-for="(curso , i) in item.cursos" :key="(i+1)*10">
                        <div class="p-5 bg-white rounded-md" style="border: 1px solid #EAEAEA">
                            <div class="size-text-18 font-bold pt-3 pb-5" :class="'text-'+classGeneral">
                                <span>{{curso.CursoNombre | capitalize}}</span>
                            </div>
                            <div class="grid grid-cols-3 size-text-16">
                                <div class="col-span-1 text-gray-400 font-bold">Carrera:</div>
                                <div class="col-span-2 font-medium text-left">{{curso.ProductoNombre | capitalize}}</div>
                            </div>
                            <div class="grid grid-cols-3 size-text-16 mb-5">
                                <div class="col-span-1 text-gray-400 font-bold">Ciclo:</div>
                                <div class="col-span-2 font-medium">{{curso.Semestre}}</div>
                            </div>
                            <div>
                                <router-link :to="{ name: 'cursosDocentesDetalle', params: { slug: rename(curso.CursoNombre) } , query : { id_producto : curso.IdProducto}}" exact>
                                    <button :class="'bt-'+classGeneral" class="w-full px-10 py-2">Entrar</button>
                                </router-link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Navbar from "@/components/Docentes/Cursos/Componentes/Navbar";
import { nameCursoService } from "@/mixins/nameCurso";
import SvgComponent from "@/components/Docentes/Svg/Svg";
export default {
    data() {
        return {
            newArr:[]
        }
    },
    components: {
        Navbar,
        SvgComponent
    },
    methods: {
        openTab(item){
            var open = document.getElementById('open'+item)
            open.style.display = open.style.display === 'block' ? 'none' : 'block'
            var close = document.getElementById('close'+item)
            close.style.display = close.style.display === 'none' ? 'block' : 'none'

            var content = document.getElementById('content'+item)
            content.style.display = content.style.display === 'none' ? 'block' : 'none'
        },

        allData(){
            let nuevoObjeto = {};
            this.cursos.forEach((vl , i) => {
                if (!nuevoObjeto.hasOwnProperty(vl.PeriodoCodigo)) {
                    nuevoObjeto[vl.PeriodoCodigo] = {
                        cursos: [],
                        PeriodoCodigo: vl.PeriodoCodigo
                    };
                }
                nuevoObjeto[vl.PeriodoCodigo].cursos.push(vl);
            });

            var newarr = nuevoObjeto;
            Object.values(newarr).map(vt => {
                let hash = {}
                vt.cursos = vt.cursos.filter(o => hash[o.ProductoNombre] ? false : hash[o.ProductoNombre] = true)
            })
            this.newArr = Object.values(newarr)
        },

        rename(value){
            return nameCursoService.simbolos(value);
        }
    },
    computed: {
        classGeneral(){
            return localStorage.getItem('classGeneral')
        },

        store(){
            return JSON.parse(localStorage.getItem('data'))
        },

        cursos(){
            return JSON.parse(localStorage.getItem('cursos'))
        },
    },

    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
    },

    created() {
        this.allData()
    },
}
</script>