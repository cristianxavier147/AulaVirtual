<template>
    <div class="md:mx-4 lg:mx-4 text-left mb-28">
        <Navbar class="lg:p-0 pl-2" :data="['Inicio','Mis cursos',this.$route.params.slug]" />
        <div class="flex my-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="15.334" height="13.35" viewBox="0 0 15.334 13.35" class="mr-3 mt-2">
                <g id="Grupo_18846" data-name="Grupo 18846" transform="translate(15.334 13.35) rotate(180)">
                    <g id="Grupo_225" data-name="Grupo 225">
                    <path id="Trazado_67" data-name="Trazado 67" d="M185.149,113.161l-5.8-5.722a.953.953,0,0,0-1.339,1.358l4.143,4.089h-11.1a.954.954,0,0,0,0,1.907h11.1l-4.143,4.089a.953.953,0,1,0,1.339,1.358l5.8-5.721a.953.953,0,0,0,0-1.358Z" transform="translate(-170.1 -107.165)" :fill="classGeneral === 'purple' ? '#722ae9' : classGeneral === 'red' ? '#C92033' : '#171FFE'"/>
                    </g>
                </g>
            </svg>
            <span class="size-text-30 font-bold">{{this.$route.params.slug | capitalize}}</span>
        </div>
        <div class="grid grid-cols-3">
            <!-- linea funcional -->
            <!-- <div class="col-span-2 pr-3 lg:inline-block md:inline-block hidden">
                <div>
                    <div class="bg-white grid grid-cols-3 p-4 rounded-md mb-1" style="border: 1px solid #EAEAEA">
                        <span class="font-bold size-text-16 col-span-2 mt-3">Mira el video de presentación del curso</span>
                        <div class="col-span-1 text-right">
                            <button :class="'bt-'+classGeneral" class="px-10 py-3">Ver video</button>
                        </div>                        
                    </div>
                    <div class="bg-white p-4 rounded-md mt-5" style="border: 1px solid #EAEAEA">
                        <div class="text-left w-full py-4">
                            <span class="size-text-20 font-bold">Línea funcional - Empleabilidad</span>
                        </div>
                        <div>
                            <div class="grid grid-cols-4">
                                <div class="col-span-1 rounded-md mr-5" style="background: #EAEAEA">
                                    <ul>
                                        <li class="mb-8 flex justify-center items-center size-text-14 font-bold py-3" style="height:80px" v-for="(item , index) in 6" :key="index">{{'Ciclo '+item}}</li>
                                    </ul>
                                </div>
                                <div class="col-span-1 mx-2">
                                    <ul>
                                        <li class="mb-8 flex justify-center items-center size-text-14 font-bold text-center py-3 px-3 rounded-md" style="height:80px;border: 1px solid #EAEAEA"  v-for="(item , index) in 6" :key="index" :class="index === 2 ? 'fnd-'+classGeneral+' text-white' : ''">{{'Habilidades Comunicativas '+item}}</li>
                                    </ul>
                                </div>
                                <div class="col-span-1 mx-2">
                                    <ul>
                                        <li class="mb-8 flex justify-center items-center size-text-14 font-bold text-center py-3 px-3 rounded-md" style="height:80px;border: 1px solid #EAEAEA" v-for="(item , index) in 6" :key="index">{{'Desarrollo personal '+item}}</li>
                                    </ul>
                                </div>
                                <div class="col-span-1 mx-2">
                                    <ul>
                                        <li class="mb-8 flex justify-center items-center size-text-14 font-bold text-center py-3 px-3 rounded-md" style="height:80px;border: 1px solid #EAEAEA" v-for="(item , index) in 6" :key="index">{{'Desarrollo personal '+item}}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- secciones -->
            <div class="lg:col-span-3 md:col-span-1 col-span-3 pl-2">
                <div class="bg-white p-4 rounded-md" style="border: 1px solid #EAEAEA">
                    <div class="text-left w-full py-4">
                        <span class="size-text-20 font-bold">Elige tu sección</span>
                    </div>
                    <!-- <div style="height: 775px" class="overflow-auto"> -->
                    <div class="grid grid-cols-3">
                        <div class="rounded-md mb-4 col-span-1 mr-3" style="border: 1px solid #EAEAEA;background: #F5F5F5" v-for="(item , index) in secciones" :key="index">
                            <div>
                                <div class="">
                                    <div class="size-text-16 font-bold py-5 px-3">
                                        <span> Sección {{item.GrupoCodigo}}</span>
                                    </div>
                                    <div class="p-3">
                                        <div class="grid grid-cols-3 size-text-16 pb-2">
                                            <div class="col-span-1 font-bold" style="color: #7F8794">Sede:</div>
                                            <div class="col-span-2 font-medium">{{item.SedeNombre | capitalize}}</div>
                                        </div>
                                        <div class="grid grid-cols-3 size-text-16 pb-2">
                                            <div class="col-span-1 font-bold" style="color: #7F8794">Horario:</div>
                                            <div class="col-span-2 font-medium">
                                                <span>{{item.Frecuencia}}</span>
                                            </div>
                                        </div>
                                        <div class="text-right mt-2">
                                            <router-link :to="{name: 'cursosDocentesSeccion' , params: { slug: rename($route.params.slug) }}">
                                                <span class="underline font-bold" :class="'text-'+classGeneral" @click="saveStore(item)">Elegir sección</span>
                                            </router-link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- comentarios -->
        <!-- <div class="bg-white mt-5 rounded-md" style="border: 1px solid #EAEAEA">
            <div>
                <div class="relative py-7 px-5">
                    <span class="size-text-20 font-semibold">Nos encantaría saber tu opinión sobre el curso para seguir mejorando</span>
                    <span class="size-text-16 font-bold underline absolute right-5 lg:inline-block md:inline-block hidden" :class="'text-'+classGeneral">Ver todas las opiniones</span>
                </div>
                <div class="flex mb-5 px-5">
                    <img src="@/assets/avatar/avatar.png" alt="" class="mr-2" style="width:40px ; height:40px">
                    <textarea name="" id="" placeholder="Escribe aquí" class="w-full rounded-md pl-2 pt-2" style="border: 1px solid #EAEAEA ; height:100px"></textarea>
                </div>
                <div class="w-full lg:text-right md:text-right px-5 mb-5 text-center">
                    <span class="size-text-16 font-bold underline lg:hidden md:hidden block mb-5" :class="'text-'+classGeneral">Ver todas las opiniones</span>
                    <button :class="'bt-'+classGeneral" class="lg:w-auto md:w-auto w-full py-2 px-10">Publicar</button>
                </div>
            </div>
        </div> -->
    </div>
</template>

<script>
import Navbar from "@/components/Docentes/Cursos/Componentes/Navbar";
import { nameCursoService } from "@/mixins/nameCurso";
export default {
    data() {
        return {
            secciones: []
        }
    },
    methods: {
        allData(){
            let dataForm = {
                IdTipoUsuario: this.store.user_type_usuario,
                IdActor: this.store.user_id_actor,
                IdProducto: this.$route.query.id_producto
            };
            this.$store.dispatch("cursoDocenteStore/cursoProducto", dataForm).then(
                (response) => {
                    if(response.success === true){
                        this.secciones = response.results.Cursos
                    }
                }
            )
        },
        saveStore(item){
            localStorage.setItem('seccion',JSON.stringify(item))
            localStorage.setItem('secciones',JSON.stringify(this.secciones))
        },
        rename(value){
            return nameCursoService.simbolos(value);
        }
    },
    components: {
        Navbar
    },
    computed: {
        classGeneral(){
            return localStorage.getItem('classGeneral')
        },

        store(){
            return JSON.parse(localStorage.getItem('data'))
        },

        cursos(){
            return JSON.parse(localStorage.getItem('cursos'))
        }
    },
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
    },
    created() {
        this.allData()
    },
}
</script>