<template>
    <div class="md:mx-4 lg:mx-4 text-left mb-28">
        <Navbar class="lg:p-0 pl-2" :data="['Inicio','Mis cursos',this.$route.params.slug,component]" />
        <div class="flex my-3">
            <SvgComponent svg="retroBlack" class="mt-2"/>
            <!-- <div class="size-text-20 font-semibold bg-black text-white w-full rounded-md py-4 px-5">{{'Sección ' + seccion.GrupoCodigo + ' . '}} {{seccion.SedeNombre+ ' . ' | capitalize}} {{seccion.Frecuencia}}</div> -->
            <select 
                class="white w-full size-text-20 bg-black text-white font-semibold p-2.5 pl-4 h-full lg:block md:block hidden" style="height: 50px;border-radius: 5px"
                v-model="seccion"
            >
                <option class="size-text-16 bg-black text-white font-semibold " v-for="(item , index) in secciones" :key="index" :value="item.IdSeccion">
                    {{'Sección ' + item.GrupoCodigo + ' . '}} {{item.SedeNombre+ ' . ' | capitalize}} {{item.Frecuencia}}
                </option>
            </select>
            <select 
                class="white w-full size-text-20 bg-black text-white font-semibold p-2.5 pl-4 h-full lg:hidden md:hidden block" style="height: 50px;border-radius: 5px"
                v-model="seccion"
            >
                <option class="size-text-16 bg-black text-white font-semibold " v-for="(item , index) in secciones" :key="index" :value="item.IdSeccion">
                    {{'Sección ' + item.GrupoCodigo }}
                </option>
            </select>
        </div>
        <div>
            <select :class="classGeneral + ' text-'+classGeneral" class="md:mt-4 lg:mt-4 mt-3 w-full size-text-20 md:border-gray-200 lg:border-gray-200 border border-gray-400 font-bold p-2.5 pl-4 h-fullme " style="height: 50px;border-radius: 5px" 
                v-model="component" @change="selectComponent()">
                <option class="font-bold text-black" selected disabled> Seleccione </option>
                <option class="font-bold text-black" value="materiales">Materiales</option>
                <option class="font-bold text-black" value="asistencia">Asistencia</option>
                <option class="font-bold text-black" value="alumnos">Alumnos</option>
                <option class="font-bold text-black" value="notas">Notas</option>
                <option class="font-bold text-black" value="reporte">Reporte</option>
            </select>   
        </div>
        <div class="mt-5">
            <component v-bind:is="currentComponent"></component>
        </div>
    </div>
</template>

<script>
import Navbar from "@/components/Docentes/Cursos/Componentes/Navbar";
import Materiales from "@/components/Docentes/Cursos/Materiales";
import Asistencia from "@/components/Docentes/Cursos/Asistencia";
import Alumnos from "@/components/Docentes/Cursos/Alumnos";
import Notas from "@/components/Docentes/Cursos/Notas";
import Reporte from "@/components/Docentes/Cursos/Reporte";
import { nameCursoService } from "@/mixins/nameCurso";
import SvgComponent from "@/components/Docentes/Svg/Svg";
export default {
    data() {
        return {
            currentComponent: 'asistencia',
            component: 'asistencia',
            seccion: ''
        }
    },
    methods: {
        allData(){
            this.seccion = this.seccionObject.IdSeccion
        },
        selectComponent(){
            this.currentComponent = this.component
        },
    },
    components: {
        Navbar,
        Materiales,
        Asistencia,
        Alumnos,
        Notas,
        Reporte,
        SvgComponent
    },
    computed: {
        classGeneral(){
            return localStorage.getItem('classGeneral')
        },

        store(){
            return JSON.parse(localStorage.getItem('data'))
        },

        cursos(){
            return JSON.parse(localStorage.getItem('cursos'))
        },
        
        seccionObject(){
            return JSON.parse(localStorage.getItem('seccion'))
        },

        secciones(){
            return JSON.parse(localStorage.getItem('secciones'))
        }
    },
    filters: {
        capitalize(value) {
            return nameCursoService.palabraFiltrada(value);
        },
    },
    created() {
        this.allData()
    },
}
</script>