<template>
  <div class="my-2 md:px-7 md:py-3">
    <h1 class="flex mb-5 text-3xl font-bold">Mi perfil</h1>
    <div class="overflow-auto font-bold text-gray-400 size-text-12 md:gap-2">
      <div class="flex w-max">
        <!-- <div @click="openTab('sobreMi')" :class="active == 'sobreMi' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block" :class="active == 'sobreMi' ? 'text-' + classGeneral + '-600' : ''">Acerca de mí</span>
        </div> -->

        <!-- DATOS PERSONALES -->
        <div @click="openTab('datosPersonales')" :class="active == 'datosPersonales' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'datosPersonales' ? 'text-' + classGeneral + '-600' : ''">Datos Personales</span>
        </div>

        <!--DATOS ORGANIZACIONALES  -->
        <div @click="openTab('datosOrganizacionales')" :class="active == 'datosOrganizacionales' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'datosOrganizacionales' ? 'text-' + classGeneral + '-600' : ''">Datos Organizacionales</span>
        </div>

        <!-- Actualiza CV -->
        <div @click="openTab('actualizaCv')" :class="active == 'actualizaCv' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'actualizaCv' ? 'text-' + classGeneral + '-600' : ''">Actualiza tu cv</span>
        </div>

        <!-- Configuracion -->
        <div @click="openTab('configuracion')" :class="active == 'configuracion' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'configuracion' ? 'text-' + classGeneral + '-600' : ''">Configuración</span>
        </div>

        <!-- <div @click="openTab('actualizarDatos')" :class="active == 'actualizarDatos' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'actualizarDatos' ? 'text-' + classGeneral + '-600' : ''">Actualizar datos</span>
        </div>
        <div @click="openTab('cambiarPassword')" :class="active == 'cambiarPassword' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'cambiarPassword' ? 'text-' + classGeneral + '-600' : ''">Cambiar contraseña</span>
        </div>
        <div id="avanceCurricular" @click="openTab('avanceCurricular')" :class="active == 'avanceCurricular' ? 'text-' + classGeneral + '-600 border-b-4 border-' + classGeneral + '-600' : ''" class="max-w-lg mx-2 cursor-pointer">
          <span class="block " :class="active == 'avanceCurricular' ? 'text-' + classGeneral + '-600' : ''">Avance curricular</span>
        </div> -->
      </div>
    </div>
    <DatosPersonales v-if="active == 'datosPersonales'" />
    <DatosOrganizacionales v-if="active == 'datosOrganizacionales'" />
    <ActualizaCv v-if="active == 'actualizaCv'" />
    <Configuracion v-if="active == 'configuracion'" />
    <SobreMi v-if="active == 'sobreMi'" />
    <!-- <ActualizarDatos v-if="active == 'actualizarDatos'" :data="this.data" /> -->
    <CambiarPassword v-if="active == 'cambiarPassword'" />
    <AvanceCurricular v-if="active == 'avanceCurricular'" />
  </div>
</template>

<script>
import DatosPersonales from "@/components/Docentes/Perfil/TabsPerfil/DatosPersonales";
import DatosOrganizacionales from "@/components/Docentes/Perfil/TabsPerfil/DatosOrganizacionales";
import ActualizaCv from "@/components/Docentes/Perfil/TabsPerfil/ActualizaCv";
import Configuracion from "@/components/Docentes/Perfil/TabsPerfil/Configuracion";
// import SobreMi from "@/components/Alumnos/Perfil/SeccionesPerfil/SobreMi";
// import ActualizarDatos from "@/components/Alumnos/Perfil/SeccionesPerfil/ActualizarDatos";
// import CambiarPassword from "@/components/Alumnos/Perfil/SeccionesPerfil/CambiarPassword";
// import AvanceCurricular from "@/components/Alumnos/Perfil/SeccionesPerfil/AvanceCurricular";

export default {
  props: ["data"],

  components: {
    // SobreMi,
    // ActualizarDatos,
    // CambiarPassword,
    // AvanceCurricular,
    DatosPersonales,
    DatosOrganizacionales,
    ActualizaCv,
    Configuracion,
  },

  data() {
    return {
      active: "actualizarDatos",
    };
  },

  methods: {
    openTab(item) {
      this.active = item;
    },
  },

  computed: {
    store() {
      return JSON.parse(localStorage.getItem("data"));
    },

    classGeneral() {
      return localStorage.getItem("classGeneral");
    },
  },
};
</script>

<style type="text/scss"></style>
