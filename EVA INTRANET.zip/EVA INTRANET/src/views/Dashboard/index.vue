<template>
    <div>
        <Notificaciones />
    </div>
</template>

<script>
import Notificaciones from "@/components/Dashboard/Notificaciones/Contenido";

export default {
    name: "Dashboard",
    components: {
        Notificaciones
    },
}
</script>