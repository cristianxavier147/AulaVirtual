import { requestService } from "@/mixins/request";

export const cursoService = {
    cursoProducto
};


function cursoProducto(payload) {
    return requestService.get("cursos/CursosProducto", payload);
}
