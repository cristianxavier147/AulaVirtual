export * from "@/module/Eva/docentes/service/curso/curso.service";
