import { cursoDocenteStore } from "@/module/Eva/docentes/store/curso/curso.store";


export default {
    cursoDocenteStore,
};
