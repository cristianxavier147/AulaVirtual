import { cursoService } from "@/module/Eva/docentes/service";
import router from "@/router";

const actions = {
    async cursoProducto(commit, payload) {
        const response = await cursoService.cursoProducto(payload);
        return response;
    },
};


export const cursoDocenteStore = {
  namespaced: true,
  actions
};
