import { requestService } from "@/mixins/request";

export const encuestasService = {
  getEncuesta(IdActor, IdTipoUsuario) {
    return requestService.get("Encuesta/GetEncuesta", { IdActor: IdActor, IdTipoUsuario: IdTipoUsuario });
  },
};
