import { requestService } from "@/mixins/request";

export const directivasService = {
    Directivas,
    DirectivasPOST
};

const app = "terminos/";

function Directivas() {
  let store = JSON.parse(localStorage.getItem('data'))
  return requestService.get(app + "Terminos?IdActor="+store.user_id_actor+"&IdUsuario="+store.user_id_usuario+"&IdUnidadNegocio=1");
}
 
function DirectivasPOST() {
  let store = JSON.parse(localStorage.getItem('data'))
  return requestService.post(app + "Terminos", {DatosGrabar: DatosGrabars, IdActor: IdActors, IdDirectiva3:IdDirectiva3s, IdDirectiva4: IdDirectiva4s, IdMatriculaDirectiva: IdMatriculaDirectivas, IdUsuarioDirectiva: IdUsuarioDirectivas });
}