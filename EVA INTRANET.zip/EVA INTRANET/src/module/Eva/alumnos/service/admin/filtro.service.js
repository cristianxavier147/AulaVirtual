import { requestService } from "@/mixins/request";

export const filtroService = {
    filtro
};

const app = "publicacion/";

function filtro(IdEmpresas,IdSedes,IdFacultads,IdUnidadNegocios,IdUnidadAcademicas,IdProductos,opciones) {
    return requestService.get(app + "GetPublicacionFiltros", { IdEmpresa : IdEmpresas , IdSede : IdSedes, IdFacultad: IdFacultads, IdUnidadNegocio: IdUnidadNegocios, IdUnidadAcademica : IdUnidadAcademicas, IdProducto : IdProductos, OPCION : opciones});
}

