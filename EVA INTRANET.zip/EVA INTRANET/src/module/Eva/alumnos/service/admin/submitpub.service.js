import { requestService } from "@/mixins/request";

export const submitpubService = {
    SubmitPublicacion
};

const app = "publicacion/";

function SubmitPublicacion(IdPublicacions,IdUsuarioPublicadors,NombreUsuarioPublicadors,IdAreaPublicadoras,AreaPublicadoras,Textos,IdTipoPublicacions,DescPublicacions,LinkTextoTipoPublicacions,CorreoInfoTipoPublicacions,EsFijadas,URLImagens,RutaImagens,URLArchivos,RutaArchivos,IdUsuarioAudiencias,IdSedes,IdFacultads,IdUnidadNegocios,IdUnidadAcademicas,IdProductos,IdModulos,IdPromocions,IdGrupos,IdSeccions,FechaInicials,FechaFinals,Estados,UsuarioCreacions,FechaCreacions,UsuarioModificacions,FechaModificacions,MeInteresas,MeEmocionas,MeEnorgulleces,IdActorImg,BytesFotoImg, LoginImg,ExtImg,IdActorArchivo, BytesFotoArchivo, LoginArchivo, ExtArchivo) {
    return requestService.post(app + "PostPublicacion", { IdPublicacion : IdPublicacions , IdUsuarioPublicador : IdUsuarioPublicadors, NombreUsuarioPublicador: NombreUsuarioPublicadors, IdAreaPublicadora: IdAreaPublicadoras, AreaPublicadora : AreaPublicadoras, Texto : Textos, CodTipoPublicacion : IdTipoPublicacions, DescPublicacion: DescPublicacions, LinkTextoTipoPublicacion: LinkTextoTipoPublicacions,CorreoInfoTipoPublicacion:CorreoInfoTipoPublicacions,EsFijada:EsFijadas,URLImagen:URLImagens,RutaImagen:RutaImagens,URLArchivo:URLArchivos,RutaArchivo:RutaArchivos,IdUsuarioAudiencia:IdUsuarioAudiencias,IdSede:IdSedes,IdFacultad:IdFacultads,IdUnidadNegocio:IdUnidadNegocios,IdUnidadAcademica:IdUnidadAcademicas,IdProducto:IdProductos,IdModulo:IdModulos,IdPromocion:IdPromocions,IdGrupo:IdGrupos,IdSeccion:IdSeccions,FechaInicial:FechaInicials,FechaFinal:FechaFinals,Estado:Estados,UsuarioCreacion:UsuarioCreacions, FechaCreacion:FechaCreacions,UsuarioModificacion:UsuarioModificacions,FechaModificacion:FechaModificacions,MeInteresa:MeInteresas,MeEmociona:MeEmocionas,MeEnorgullece:MeEnorgulleces,ImagenPublicacion:[{IdActor:IdActorImg,BytesFoto:BytesFotoImg,Login:LoginImg, Ext: ExtImg}], ArchivoPublicacion:[{IdActor: IdActorArchivo, BytesFoto: BytesFotoArchivo, Login: LoginArchivo, Ext: ExtArchivo }] });
}
