import { requestService } from "@/mixins/request";

export const marcadorapidoService = {
    marcadorapido,
    verificarmarcado
};

function marcadorapido(IdSeccions,IdHorarios, IdSesions, IdAlumnos, Valors, Observacions, IdUsuarios) {
    return requestService.post("asistencia/MarcarAsistencia", { IdSeccion : IdSeccions , IdHorario : IdHorarios, IdSesion: IdSesions, IdAlumno: IdAlumnos, Valor: Valors, Observacion: Observacions, IdUsuario: IdUsuarios });
}

function verificarmarcado(IdSeccions, IdAlumnos) { 
    return requestService.get("asistencia/VerificarMarcacion", {IdAlumno: IdAlumnos, IdSeccion: IdSeccions });
}