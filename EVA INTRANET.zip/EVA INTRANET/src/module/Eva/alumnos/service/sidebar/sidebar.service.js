import { requestService } from "@/mixins/request";

export const sidebarService = {
    cursos,
    sidebar,
    ValidarAdmin,
    ValidarFijar
};

const app = "cursos/";
const appvalidar = "MenuAdmin/";

function sidebar(state){
    return requestService.get("menu/menu", state);
}

function cursos(state) {
    return requestService.get(app + "Cursos", state);
}

function ValidarAdmin() {
    let store = JSON.parse(localStorage.getItem('data'))
    //return requestService.get(appvalidar + "Menu?IdUsuario=" + store.user_id_usuario);
    //return requestService.get(appvalidar + "Menu?IdUsuario=309195"); //es admin
    return requestService.get(appvalidar + "Menu?IdUsuario=" + store.user_id_usuario + "&CodigoPadre=MNUPUBLICACIONES"); //no es admin
}

function ValidarFijar() {
    let store = JSON.parse(localStorage.getItem('data'))
    //return requestService.get(appvalidar + "Menu?IdUsuario=" + store.user_id_usuario);
    //return requestService.get(appvalidar + "Menu?IdUsuario=309195"); //es admin
    return requestService.get(appvalidar + "Menu?IdUsuario=" + store.user_id_usuario + "&CodigoPadre=SMNUPUBLICAR"); //no es admin
}