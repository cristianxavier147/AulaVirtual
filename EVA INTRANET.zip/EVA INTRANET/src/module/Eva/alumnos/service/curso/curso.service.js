import { requestService } from "@/mixins/request";

export const cursoService = {
    asitenciacurso,
    informacioncurso,
    informacioncontacto,
    notascurso,
    horarioFacilitador,
    avanceCurricular,
    finalizados
};


function asitenciacurso(IdAlumno,IdSeccion) {
    return requestService.get("asistencia/VerificarAsistencia", { IdAlumno : IdAlumno , IdSeccion : IdSeccion });
}

function informacioncurso(IdTipoUsuario,IdSeccion,CodigoAlumno) {
    return requestService.get("InfoCurso/Info", { IdTipoUsuario : IdTipoUsuario , IdSeccion : IdSeccion, CodigoAlumno: CodigoAlumno });
}

function informacioncontacto(IdSeccion) {
    return requestService.get("contacto/TraerContactos", { IdSeccion : IdSeccion });
}

function notascurso(IdAlumno,IdSeccion) {
    return requestService.get("Notas/Notas", { IdAlumno : IdAlumno , IdSeccion : IdSeccion });
}

function horarioFacilitador(payload) {
    return requestService.get("InfoCurso/HorarioFacilitador", payload);
}

function avanceCurricular(payload) {
    return requestService.get("avancecurricular/traer", payload);
}

function finalizados(payload){
    return requestService.get("cursos/CursosFinalizados", payload);
}
