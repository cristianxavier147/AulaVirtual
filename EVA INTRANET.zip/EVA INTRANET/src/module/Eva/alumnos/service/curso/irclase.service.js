import { requestService } from "@/mixins/request";

export const irclaseService = {
    irclase
};


function irclase(IdActors,IdTipoUsuarios) {
    return requestService.get("cursos/Cursos", { IdActor : IdActors , IdTipoUsuario : IdTipoUsuarios });
}
