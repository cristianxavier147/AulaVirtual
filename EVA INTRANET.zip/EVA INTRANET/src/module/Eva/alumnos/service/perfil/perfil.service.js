import { requestService } from "@/mixins/request";

export const perfilService = {
  perfil,
  getTrabajo,
  getExpectativa,
  getSobrenombre,
  setExpectatica,
  setSobreNombre,
  setTrabajo,
  setEsPrivado,
  setEmail,
  setCelular,
  guardarFoto,
  guardarDocumento,
  getDireccion,
  getUbigeo,
  setDireccion
};

const app = "perfil/";

function perfil(params) {
  return requestService.post(app + "perfil", params);
}

function getTrabajo(params) {
  return requestService.get(app + "GetTrabajo", params);
}

function getExpectativa(params) {
  return requestService.get(app + "GetExpectativa", params);
}

function getSobrenombre(params) {
  return requestService.get(app + "GetSobrenombre", params);
}

function getDireccion(params) {
  return requestService.get(app + "GetDireccion", params);
}

function getUbigeo(params) {
  return requestService.get(app + "GetUbigeo", params);
}

function setExpectatica(params) {
  return requestService.post(app + "SetExpectativa", params);
}

function setSobreNombre(params) {
  return requestService.post(app + "SetSobreNombre", params);
}

function setTrabajo(params) {
  return requestService.post(app + "SetTrabajo", params);
}

function setEsPrivado(params) {
  return requestService.post(app + "SetEsPrivado", params);
}

function setEmail(params) {
  return requestService.post(app + "SetEmail", params);
}

function setCelular(params) {
  return requestService.post(app + "SetCelular", params);
}

function setDireccion(params) {
  return requestService.post(app + "SetDireccion", params);
}

function guardarFoto(params) {
  return requestService.post(app + "GuardarFoto", params);
}

function guardarDocumento(params) {
  return requestService.post(app + "GuardarDocumento", params);
}
