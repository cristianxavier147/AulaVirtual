import { requestService } from "@/mixins/request";

export const notificacionesService = {
  notificaciones
};

const app = "publicacion/";

function notificaciones() {
  let store = JSON.parse(localStorage.getItem('data'))
  return requestService.get(app + "GetPublicacion?IdUsuario=" + store.user_id_usuario);
  //return requestService.get(app + "GetPublicacion?IdUsuario=313009");
}
 

