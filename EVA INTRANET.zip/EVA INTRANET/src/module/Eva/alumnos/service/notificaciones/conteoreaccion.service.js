import { requestService } from "@/mixins/request";

export const conteoreaccionService = {
    conteoreaccion
};

const app = "publicacion/";

function conteoreaccion(IdPublicacions) {
  return requestService.get(app + "GetPublicacionReaccion", {IdPublicacion: IdPublicacions} );
}
 