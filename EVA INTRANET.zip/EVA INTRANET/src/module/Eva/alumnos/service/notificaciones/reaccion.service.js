import { requestService } from "@/mixins/request";

export const reaccionesService = {
  reacciones
};

const app = "publicacion/";

function reacciones(IdPub, IdUsu, IdRea, Estad) {
  return requestService.post(app + "PostPublicacionReaccion", { IdPublicacion: IdPub, IdUsuario: IdUsu, IdReaccion: IdRea, Estado : Estad});
  //return requestService.get(app + "GetPublicacion?IdUsuario=313009");
}