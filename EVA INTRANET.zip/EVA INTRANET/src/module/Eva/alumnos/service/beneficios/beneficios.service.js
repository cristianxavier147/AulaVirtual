import { requestService } from "@/mixins/request";

export const beneficiosService = {
    traerBeneficios,
    setBeneficios
};

const app = "beneficios/";

function traerBeneficios(payload) {
    return requestService.get(app + "TraeBeneficios", payload);
}

function setBeneficios(payload) {
    return requestService.post(app + "SetBeneficios", payload);
}
