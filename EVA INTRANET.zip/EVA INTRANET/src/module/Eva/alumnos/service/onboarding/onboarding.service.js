import { requestService } from "@/mixins/request";

export const onboardingService = {
  paso1,
  registropaso1,
  omitir,
  registro_Paso_4,
  setFechaDocumento,
  setTelefonoValidar,
  getTelefonoValidar,
  finalizarOnboarding
};

const app = "OnBoarding/";

function paso1(state) {
  return requestService.get(app + "Paso_1", state);
}

function registropaso1(params) {
  return requestService.post(app + "Registro_Paso_1", params);
}

function omitir(params) {
  return requestService.post(app + "Omitir_Paso_3", params);
}

function registro_Paso_4(params) {
  return requestService.post(app + "Registro_Paso_4", params);
}

function setFechaDocumento(params) {
  return requestService.post(app + "SetFechaDocumento", params);
}

function setTelefonoValidar(params) {
  return requestService.post(app + "SetTelefonoValidar", params);
}

function getTelefonoValidar(params) {
  return requestService.get(app + "GetTelefonoValidar", params);
}

function finalizarOnboarding(params) {
  return requestService.post(app + "FinalizarOnboarding", params);
}
