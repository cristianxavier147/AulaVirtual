import { cursoService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async asitenciacurso(commit, payload) {
        const response = await cursoService.asitenciacurso(payload.IdAlumno,payload.IdSeccion);
        return response;
    },

    async informacioncurso(commit, payload) {
        const response = await cursoService.informacioncurso(payload.IdTipoUsuario,payload.IdSeccion,payload.CodigoAlumno);
        return response;
    },

    async informacioncontacto(commit , payload) {
        const response = await cursoService.informacioncontacto(payload.IdSeccion);
        return response;
    },
    async notascurso(commit , payload) {
        const response = await cursoService.notascurso(payload.IdAlumno,payload.IdSeccion);
        return response;
    },
    async horarioFacilitador(commit , payload) {
        const response = await cursoService.horarioFacilitador(payload);
        return response;
    },
    async avanceCurricular(commit , payload) {
        const response = await cursoService.avanceCurricular(payload);
        return response;
    },
    async finalizados(commit , payload) {
        const response = await cursoService.finalizados(payload);
        return response;
    },
};


export const cursoStore = {
  namespaced: true,
  actions
};
