import { irclaseService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async irclase(commit, payload) {
        const response = await irclaseService.irclase(payload.IdActors,payload.IdTipoUsuarios);
        if (response.success) {
        }        
        return response;
    },
};


export const irclaseStore = {
  namespaced: true,
  actions
};
