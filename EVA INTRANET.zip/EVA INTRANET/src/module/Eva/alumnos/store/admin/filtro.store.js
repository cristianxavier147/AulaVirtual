import { filtroService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async filtro(commit, payload) {
        const response = await filtroService.filtro(payload.IdEmpresas, payload.IdSedes, payload.IdFacultads, payload.IdUnidadNegocios, payload.IdUnidadAcademicas, payload.IdProductos, payload.opciones);
        if (response.success) {
        }
        return response;
    },
};


export const filtroStore = {
  namespaced: true,
  actions
};
