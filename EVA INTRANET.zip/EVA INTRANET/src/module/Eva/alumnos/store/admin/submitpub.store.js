import { submitpubService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async submitPublicacion(commit, payload) {
        const response = await submitpubService.SubmitPublicacion(payload.IdPublicacions,payload.IdUsuarioPublicadors,payload.NombreUsuarioPublicadors,payload.IdAreaPublicadoras,payload.AreaPublicadoras,payload.Textos,payload.IdTipoPublicacions,payload.DescPublicacions,payload.LinkTextoTipoPublicacions,payload.CorreoInfoTipoPublicacions,payload.EsFijadas,payload.URLImagens,payload.RutaImagens,payload.URLArchivos,payload.RutaArchivos,payload.IdUsuarioAudiencias,payload.IdSedes,payload.IdFacultads,payload.IdUnidadNegocios,payload.IdUnidadAcademicas,payload.IdProductos,payload.IdModulos,payload.IdPromocions,payload.IdGrupos,payload.IdSeccions,payload.FechaInicials,payload.FechaFinals,payload.Estados,payload.UsuarioCreacions,payload.FechaCreacions,payload.UsuarioModificacions,payload.FechaModificacions,payload.MeInteresas,payload.MeEmocionas,payload.MeEnorgulleces,payload.IdActorImg,payload.BytesFotoImg, payload.LoginImg,payload.ExtImg,payload.IdActorArchivo, payload.BytesFotoArchivo, payload.LoginArchivo, payload.ExtArchivo);
        if (response.success) {
        }
        return response;
    },
};


export const submitpubStore = {
  namespaced: true,
  actions
};
