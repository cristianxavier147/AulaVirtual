import { onboardingService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
  async paso1({ commit }, attributes) {
    const response = await onboardingService.paso1(attributes);
    return response;
  },

  async registropaso1({commit} , attributes) {
    const response = await onboardingService.registropaso1(attributes);
    return response;
  },

  async omitir({commit} , attributes) {
    const response = await onboardingService.omitir(attributes);
    return response;
  },

  async registro_Paso_4({commit} , attributes) {
    const response = await onboardingService.registro_Paso_4(attributes);
    return response;
  },

  async setFechaDocumento({commit} , attributes) {
    const response = await onboardingService.setFechaDocumento(attributes);
    return response;
  },

  async setTelefonoValidar({commit} , attributes) {
    const response = await onboardingService.setTelefonoValidar(attributes);
    return response;
  },

  async getTelefonoValidar({commit} , attributes) {
    const response = await onboardingService.getTelefonoValidar(attributes);
    return response;
  },

  async finalizarOnboarding({commit} , attributes) {
    const response = await onboardingService.finalizarOnboarding(attributes);
    return response;
  },
};

export const onboardingStore = {
  namespaced: true,
  actions,
};
