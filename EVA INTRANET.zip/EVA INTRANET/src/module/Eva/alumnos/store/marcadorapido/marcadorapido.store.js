import { marcadorapidoService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async marcadorapido(commit, payload) {
        const response = await marcadorapidoService.marcadorapido(payload.IdSeccions, payload.IdHorarios, payload.IdSesions, payload.IdAlumnos, payload.Valors, payload.Observacions, payload.IdUsuarios);
            return response;
    },
    async verificarmarcado(commit, payload) {
        const response = await marcadorapidoService.verificarmarcado(payload.IdSeccions, payload.IdAlumnos);
            return response;
    },    
};


export const marcadorapidoStore = {
  namespaced: true,
  actions
};