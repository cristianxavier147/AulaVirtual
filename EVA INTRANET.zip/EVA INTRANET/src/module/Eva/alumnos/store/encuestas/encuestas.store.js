import { encuestasService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
  async getEncuesta(commit, payload) {
    const response = await encuestasService.getEncuesta(payload.IdActor, payload.IdTipoUsuario);
    return response;
  },
};

export const encuestasStore = {
  namespaced: true,
  actions,
};
