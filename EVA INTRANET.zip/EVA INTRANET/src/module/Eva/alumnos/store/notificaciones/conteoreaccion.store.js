import { conteoreaccionService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async conteoreaccion(commit, payload) {
        const response = await conteoreaccionService.conteoreaccion(payload.IdPublicacions);
        if (response.success) {
        }
        return response;
    },
};


export const conteoreaccionStore = {
  namespaced: true,
  actions
};
