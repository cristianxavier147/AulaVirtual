import { reaccionesService } from "@/module/Eva/alumnos/service";
import { sessionService } from "@/mixins/session";
import router from "@/router";

const actions = {
    async reaccion(commit, payload) {
        const response = await reaccionesService.reacciones(payload.IdPub, payload.IdUsu, payload.IdRea, payload.Estad);
        if (response.success) {
        }
        return response;
    },
};


export const reaccionStore = {
  namespaced: true,
  actions
};