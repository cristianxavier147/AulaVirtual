import { notificacionesService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async notificaciones(commit) {
        const response = await notificacionesService.notificaciones();
        if (response.success) {
        }
        return response;
    },
};


export const notificacionesStore = {
  namespaced: true,
  actions
};
