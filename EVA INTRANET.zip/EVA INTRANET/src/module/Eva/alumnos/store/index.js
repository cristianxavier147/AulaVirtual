import { sidebarStore } from "@/module/Eva/alumnos/store/sidebar/sidebar.store";
import { onboardingStore } from "@/module/Eva/alumnos/store/onboarding/onboarding.store";
import { cursoStore } from "@/module/Eva/alumnos/store/curso/curso.store";
import { perfilStore } from "@/module/Eva/alumnos/store/perfil/perfil.store";
import { beneficiosStore } from "@/module/Eva/alumnos/store/beneficios/beneficios.store";
import { notificacionesStore } from "@/module/Eva/alumnos/store/notificaciones/notificaciones.store";
import { directivasStore } from "@/module/Eva/alumnos/store/Directivas/directivas.store";
import { reaccionStore } from "@/module/Eva/alumnos/store/notificaciones/reaccion.store";
import { filtroStore } from "@/module/Eva/alumnos/store/admin/filtro.store";
import { submitpubStore } from "@/module/Eva/alumnos/store/admin/submitpub.store";
// import { irclaseStore } from "@/module/Eva/alumnos/store/curso/irclase.store";
import { conteoreaccionStore } from "@/module/Eva/alumnos/store/notificaciones/conteoreaccion.store";
import { marcadorapidoStore } from "@/module/Eva/alumnos/store/marcadorapido/marcadorapido.store";
import { encuestasStore } from "@/module/Eva/alumnos/store/encuestas/encuestas.store";

export default {
  sidebarStore,
  cursoStore,
  onboardingStore,
  perfilStore,
  beneficiosStore,
  notificacionesStore,
  directivasStore,
  reaccionStore,
  filtroStore,
  submitpubStore,
  // irclaseStore,
  conteoreaccionStore,
  marcadorapidoStore,
  encuestasStore,
};
