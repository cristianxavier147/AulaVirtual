import { directivasService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async directivas() {
        const response = await directivasService.Directivas();
        if (response.success) {
        }
        return response;
    },
    async directivasPOST(payload) {
      const response = await directivasService.Directivas(payload.DatosGrabars, payload.IdActors, payload.IdDirectiva3s, payload.IdDirectiva4s, payload.IdMatriculaDirectivas, payload.IdUsuarioDirectivas);
      if (response.success) {
        console.log(response); //eliminar
      }
      return response;
  },
};


export const directivasStore = {
  namespaced: true,
  actions
};
