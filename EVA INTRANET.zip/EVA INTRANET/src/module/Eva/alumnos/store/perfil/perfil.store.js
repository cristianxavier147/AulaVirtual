import { perfilService } from "@/module/Eva/alumnos/service";
import router from "@/router";
import Vue from "vue";

const state = {
  perfilState: []
}

const actions = {
  async perfil({ commit }) {
    let store = JSON.parse(localStorage.getItem('data'))
    let params = { IdActor: store.user_id_actor, IdTipoUsuario: store.user_type_usuario };
    const response = await perfilService.perfil(params);
    commit("perfilMutations", response.results);
    return response;
  },

  async getTrabajo({ commit }) {
    let store = JSON.parse(localStorage.getItem('data'))
    let params = { IdActor: store.user_id_actor, IdTrabajo: 0 , Login: store.user_codigo };
    const response = await perfilService.getTrabajo(params);
    return response;
  },

  async getExpectativa({ commit }) {
    let store = JSON.parse(localStorage.getItem('data'))
    let params = { IdActor: store.user_id_actor, IdUsuario: store.user_id_usuario , Login: store.user_codigo };
    const response = await perfilService.getExpectativa(params);
    return response;
  },

  async getSobrenombre({ commit }) {
    let store = JSON.parse(localStorage.getItem('data'))
    let params = { IdActor: store.user_id_actor, IdUsuario: store.user_id_usuario , Login: store.user_codigo };
    const response = await perfilService.getSobrenombre(params);
    return response;
  },

  async getDireccion({ commit }) {
    let store = JSON.parse(localStorage.getItem('data'))
    let params = { IdActor: store.user_id_actor, Login: store.user_codigo };
    const response = await perfilService.getDireccion(params);
    return response;
  },

  async getUbigeo({ commit } , atrributes) {
    const response = await perfilService.getUbigeo(atrributes);
    return response;
  },

  async setExpectatica({ commit } , atrributes) {
    const response = await perfilService.setExpectatica(atrributes);
    return response;
  },
  
  async setSobreNombre({ commit } , atrributes) {
    const response = await perfilService.setSobreNombre(atrributes);
    return response;
  },

  async setTrabajo({ commit } , atrributes) {
    const response = await perfilService.setTrabajo(atrributes);
    return response;
  },

  async setEsPrivado({ commit } , atrributes) {
    const response = await perfilService.setEsPrivado(atrributes);
    return response;
  },

  async setEmail({ commit } , atrributes) {
    const response = await perfilService.setEmail(atrributes);
    return response;
  },

  async setCelular({ commit } , atrributes) {
    const response = await perfilService.setCelular(atrributes);
    return response;
  },

  async setDireccion({ commit } , atrributes) {
    const response = await perfilService.setDireccion(atrributes);
    return response;
  },

  async guardarFoto({ commit } , atrributes) {
    const response = await perfilService.guardarFoto(atrributes);
    return response;
  },

  async guardarDocumento({ commit } , atrributes) {
    const response = await perfilService.guardarDocumento(atrributes);
    return response;
  },
};

const mutations = {
  perfilMutations(state, items) {
    Vue.set(state, "perfilState", items);
  },
}

export const perfilStore = {
  namespaced: true,
  actions,
  state,
  mutations
};
