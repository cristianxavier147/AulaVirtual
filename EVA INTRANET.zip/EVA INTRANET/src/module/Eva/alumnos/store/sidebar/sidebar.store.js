import { sidebarService } from "@/module/Eva/alumnos/service";
import Vue from "vue";

const state = {
  sidebarState: [],
  cursosState: [],
  horariosState: [],
  moodleState: '',
  preloaderState: true
}

const getters = {
    cursosGetters(state) {
      return state.cursosState;
    },
    horariosGetters(state) {
      return state.horariosState;
    },
    preloaderGetters(state) {
      return state.preloaderState;
    },
  };

const actions = {

  async EsAdmin(commit) {
    const response = await sidebarService.ValidarAdmin();

    return response;
  },
  async EsFijado(commit) {
    const response = await sidebarService.ValidarFijar();
    if (response.success) {
    }
    return response;
  },  
  async sidebar({ commit }, attributes) {
    const response = await sidebarService.sidebar(attributes)
    commit("sidebarMutations", response.results.Menu);
    localStorage.setItem('menu',JSON.stringify(response.results.Menu))
    return response;
  },

  async cursos({ commit }, attributes) {
    const response = await sidebarService.cursos(attributes)
    const data = JSON.parse(localStorage.getItem('data'))
    if(data.user_type_usuario == "1"){
      for (let i = 0; i < response.results.Matriculas.length; i++) {
        for (let z = 0; z < response.results.Matriculas[i].Cursos.length; z++) {
          var simbolos, color;
          simbolos = "0123456789ABCDEF";
          color = "#";

          for(var j = 0; j < 6; j++){
            color = color + simbolos[Math.floor(Math.random() * 16)];
          }
          
          response.results.Matriculas[i].Cursos[z].color = color;
        }
      }
      commit("cursosMutations", response.results.Matriculas);
      commit("horarioMutations", response.results.Horarios);
      localStorage.setItem('cursos',JSON.stringify(response.results.Matriculas))
      localStorage.setItem('horarios',JSON.stringify(response.results.Horarios))
    }else{
      commit("cursosMutations", response.results.Cursos);
      commit("horarioMutations", response.results.Horarios);
      localStorage.setItem('cursos',JSON.stringify(response.results.Cursos))
      localStorage.setItem('horarios',JSON.stringify(response.results.Horarios))
    }
    if(response.success){
      commit("preloaderMutations", false);
    }
    return response;
  },

  async moodle({commit} , payload) {
    commit("moodleMutations", payload)
  }

};

const mutations = {
  sidebarMutations(state, items) {
    Vue.set(state, "sidebarState", items);
  },
  cursosMutations(state, items) {
    Vue.set(state, "cursosState", items);
  },
  horarioMutations(state, items) {
    Vue.set(state, "horariosState", items);
  },
  preloaderMutations(state, items){
    Vue.set(state, "preloaderState", items);
  },
  moodleMutations(state, items){
    Vue.set(state, "moodleState", items);
  }
}


export const sidebarStore = {
  namespaced: true,
  actions,
  state,
  mutations,
  getters
};
