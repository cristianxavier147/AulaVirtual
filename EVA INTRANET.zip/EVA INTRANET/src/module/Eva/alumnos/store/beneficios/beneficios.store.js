import { beneficiosService } from "@/module/Eva/alumnos/service";
import router from "@/router";

const actions = {
    async traerBeneficios(commit, payload) {
        const response = await beneficiosService.traerBeneficios(payload);
        return response;
    },

    async setBeneficios(commit, payload) {
        const response = await beneficiosService.setBeneficios(payload);
        return response;
    },
};


export const beneficiosStore = {
  namespaced: true,
  actions
};
