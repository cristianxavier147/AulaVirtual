import { requestService } from "@/mixins/request";

export const loginService = {
  login,
  logout,
  changePassword,
  olvidePassword,
  validateToken,
  verificacontrasenia,
  rutas
};

const app = "login/";

function login(codigo, password) {
  return requestService.post(app + "login", { Username: codigo, Password: password });
}

function logout() {
  return requestService.get(app + "logout");
}

function changePassword(username ,  password) {
  return requestService.post(app + "cambiacontrasenia" , { Username: username, Password: password })
}

function olvidePassword(username , email) {
  return requestService.post(app + "olvidocontrasenia" , { Login: username, Correo: email } )
}

function validateToken(query){
  return requestService.post(app + "olvidocontrasenia2" , { Query : query } )
}

function rutas(query) {
  return requestService.get(app + "flujo", query);
}

function verificacontrasenia(query){
  return requestService.post(app + "verificacontrasenia" , query )
}
