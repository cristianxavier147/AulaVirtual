import { loginService } from "@/module/Eva/login/service";
import { sessionService } from "@/mixins/session";
import router from "@/router";
import Vue from "vue";

const actions = {
  async login(commit, payload) {
    const response = await loginService.login(payload.codigo, payload.password);
    if (response.success) {
      sessionService.setSession(response, "1d");
    }
    return response;
  },

  async logout() {
    const response = await loginService.logout();
    if (response.success) {
      sessionService.removeSession();
      await router.push({ name: "Home" }).catch(()=>{});
    }
  },

  async changePassword(commit , payload) {
    const response = await loginService.changePassword(payload.username , payload.password)
    if(response.success){
      await router.push({ name: "login" }).catch(()=>{});
    }
  },

  async changePasswordMethod(commit , payload) {
    const response = await loginService.changePassword(payload.username , payload.password)
    return response
  },

  async olvidePassword(commit , payload){
    const response = await loginService.olvidePassword(payload.username , payload.email)
    return response
  },

  async validateToken(commit, payload){
    const response = await loginService.validateToken(payload.query)
    if(response.success == true){
      localStorage.setItem('user_codigo',response.results.Login)
      setTimeout(() => {
          router.push({ name: 'newPassword' }).catch(()=>{})
      }, 1000);
  }
    return response
  },

  async rutas(commit) {
    let store = JSON.parse(localStorage.getItem('data'))
    let form = { 
      IdActor : store.user_id_actor ,
      Login : store.user_codigo ,
      IdTipoUsuario: store.user_type_usuario 
    }
    const response = await loginService.rutas(form);
    if (response.success) {
      if(response.results.Flujo === "Beneficios"){
        router.push({name: 'beneficios'}).catch(()=>{})
      }else if(response.results.Flujo === "Directiva"){
        router.push({name: 'directivas'}).catch(()=>{})
      }else if(response.results.Flujo === "OnBoarding"){
        if(store.user_type_usuario === "2"){
          router.push({name: 'alumnoBienvenido'}).catch(()=>{})
        }else{
          router.push({name: 'docenteBienvenido'}).catch(()=>{})
        }
      }else if(response.results.Flujo === "Index"){
        router.push({name: 'dashboard'}).catch(()=>{})
      }else{
        window.location = response.results.Flujo;
      }
    }
    return response;
},

  async verificacontrasenia(commit , payload){
    const response = await loginService.verificacontrasenia(payload)
    return response
  },

};

export const loginStore = {
  namespaced: true,
  actions
};
