import { loginStore } from "@/module/Eva/login/store/login/login.store";


export default {
  loginStore
};
