import { cryptService } from "@/mixins/crypto";

class session {
  constructor() {}

  setSession(response) {
    const uid = cryptService.encryptData(response.results.Sesion);
    // const roles = cryptService.encryptData(response.data.roles);
    const data = response.results;

    let valor = {
      token : data.Token,
      user_name : data.Sesion.Nombres,
      user_mat_name : data.Sesion.ApeMat,
      user_pat_name : data.Sesion.ApePat,
      user_codigo : data.Sesion.Login,
      user_codigo_encryp : data.Sesion.LoginEncryptado,
      user_id_actor : data.Sesion.IdActor, // idAlumno
      user_id_usuario : data.Sesion.IdUsuario,
      user_type_usuario : data.Sesion.IdTipoUsuario,
      user_matricula : data.Sesion.IdUltimaMatricula,
      rol : data.Sesion.IdUsuario,
      name_carrera : data.Sesion.ProductoNombre,
      user_dni : data.Sesion.NumeroIdentidad,
      user_unidad_negocio : data.Sesion.IdUnidadNegocio,
      user_ciclo : data.Sesion.Ciclo,
      user_unidad_academica: data.Sesion.IdUnidadAcademica,
      user_id_modulo: data.Sesion.IdModulo,
      user_id_sede: data.Sesion.IdSede
    }

    localStorage.setItem("data", JSON.stringify(valor))
    localStorage.setItem('token' , data.Token)
    window.$cookies.set("token", data.Token, "1d");
    // window.$cookies.set("avatar", data.avatar, "1d");
  }

  removeSession() {

    let finish = localStorage.getItem('classGeneral')
    window.$cookies.remove("token");
    localStorage.clear()
    localStorage.setItem("classGeneral", finish);
  }
}

export const sessionService = new session();
