class nameCurso {
  constructor() {}

  palabraFiltrada(value){
    var dev = ""
    let valor = value.split(" ");
    for (let i = 0; i < valor.length; i++) {
        var response = this.filterPalabras(valor[i])
        if(!response){
            var minicula = valor[i].toLowerCase()
            dev = dev + ' ' + minicula.charAt(0).toUpperCase() + minicula.slice(1);
        }else{
            dev = dev + ' ' + valor[i]
        }
    }
    return dev
  }

  filterPalabras(response) {
    let valor = response.split(" ");
    //numeros romanos

    if(valor.includes("I")) return true
    if(valor.includes("II")) return true
    if(valor.includes("III")) return true
    if(valor.includes("IV")) return true
    if(valor.includes("V")) return true
    if(valor.includes("VI")) return true
    if(valor.includes("VII")) return true
    if(valor.includes("VII")) return true
    if(valor.includes("VIII")) return true
    if(valor.includes("IX")) return true
    if(valor.includes("X")) return true

    //palabras genericas
    if(valor.includes("3D")) return true
  }

  simbolos(value){
    value = this.palabraFiltrada(value)
    return value.replace(/\//g , '')
  }
}

export const nameCursoService = new nameCurso();
