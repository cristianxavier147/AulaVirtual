class filtros {
    Conteo(valor) {
        var valorx = valor.toString().length;
        return valorx;
    }
    SepararUno(valor1) {
        var slicex1 = valor1.toString().slice(1);
        return slicex1;
    }
    SepararDos(valor2) {
        var slicex2 = valor2.toString().slice(2);
        return slicex2;
    }
    filter(valor3) {
        //var valor2 = valor.length;
        //return valor2;
        /*         for (var i = 0; i < valor.length; i++) {
            var numero = 0
            for (var variable in valor[i]) {
              numero++
            }
        var texto = valor[i]
           
        }
        return texto;  */  
        var A = Object.keys(valor3).filter(function(value, index) {return value == "Fecha";});
        return A;
    }

}

export const filtrosx = new filtros();