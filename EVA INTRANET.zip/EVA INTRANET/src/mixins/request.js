import queryString from "querystring";

class request {
  constructor() {}

  get(path, parameters, customHeaders = {}) {
    const params = queryString.stringify(parameters);
    const target = path + (params !== "" ? "?" + params : params);
    let requestOptions = {
      method: "GET",
      headers: this.authHeader(),
    };

    //Si manda custom header lo reemplazo
    if (Object.keys(customHeaders).length)
      requestOptions.headers = customHeaders;

    return this.request("get", target, requestOptions);
  }

  post(path, data, customHeaders = {}) {
    const target = path;
    let requestOptions = {
      method: "POST",
      headers: this.authHeader(),
      body: JSON.stringify(data),
    };

    //Si manda custom header se reemplaza
    if (Object.keys(customHeaders).length) {
      requestOptions.headers = customHeaders;
    }

    return this.request("post", target, requestOptions);
  }

  delete(path, data, customHeaders = {}) {
    const target = path;
    let requestOptions = {
      method: "DELETE",
      headers: this.authHeader(),
      body: JSON.stringify(data),
    };

    //Si manda custom header se reemplaza
    if (Object.keys(customHeaders).length) {
      requestOptions.headers = customHeaders;
    }

    return this.request("delete", target, requestOptions);
  }

  put(path, data, customHeaders = {}) {
    const target = path;
    let requestOptions = {
      method: "PUT",
      headers: this.authHeader(),
      body: JSON.stringify(data),
    };

    //Si manda custom header lo reemplazo
    if (Object.keys(customHeaders).length) {
      requestOptions.headers = customHeaders;
    }

    return this.request("put", target, requestOptions);
  }

  authHeader() {
    if (window.$cookies.isKey("token")) {
      return {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + window.$cookies.get("token"),
      };
    } else {
      return {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "",
      };
    }
  }

  request(method, path, options) {
    let route = window.location.host
    var target ;

    switch(route){
      case process.env.VUE_APP_RUTA_ZEGEL:
        target = process.env.VUE_APP_BASE_URL_ZEGEL + path;
        break;
      case process.env.VUE_APP_RUTA_IDAT:
        target = process.env.VUE_APP_BASE_URL_IDA + path;
        break;
      case process.env.VUE_APP_RUTA_CORRIENTE:
        target = process.env.VUE_APP_BASE_URL_CORRIENTE + path;
        break;
      case process.env.VUE_APP_RUTA_DEVELOPMENT:
        target = process.env.VUE_APP_BASE_URL_IDA + path;
    };
    
    
    return fetch(target, options)
      .then((response) => response.json())
      .then((response) => {
        return response;
      })
      .catch((error) => {
        return error;
      });
  }
}

export const requestService = new request();
