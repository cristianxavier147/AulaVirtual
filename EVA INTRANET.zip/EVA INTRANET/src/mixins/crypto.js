import CryptoJS from "crypto-js";

class crypto {
  constructor() {}

  key() {
    return (
      "MIIJKwIBAAKCAgEAyif5xObaZPMjNWBpj2MxCgoh10mYjMDSjvm0hCp9cxaAnzVX" +
      "OG0APnonjZ3zXDpyc7z3Ljo9TpXN/4q/aYR2xQ6otRKQQGu3BgL7279wfgjg2Axu"
    );
  }

  encryptData(message) {
    let response;
    switch (typeof message) {
      case "number":
        // eslint-disable-next-line
        response = CryptoJS.AES.encrypt(message.toString(), this.key()).toString();
        break;
      case "string":
        response = CryptoJS.AES.encrypt(message, this.key()).toString();
        break;
      case "object":
        // eslint-disable-next-line
        response = CryptoJS.AES.encrypt(JSON.stringify(message), this.key()).toString();
        break;
      default:
        response = message;
        break;
    }

    return response;
  }

  decryptData(message) {
    let response;
    let bytes;
    switch (typeof message) {
      case "number":
        bytes = CryptoJS.AES.decrypt(message.toString(), this.key());
        response = bytes.toString(CryptoJS.enc.Utf8);
        break;
      case "string":
        bytes = CryptoJS.AES.decrypt(message, this.key());
        response = bytes.toString(CryptoJS.enc.Utf8);
        break;
      case "object":
        bytes = CryptoJS.AES.decrypt(message, this.key());
        response = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        break;
      default:
        response = message;
        break;
    }

    return response;
  }
}

export const cryptService = new crypto();
