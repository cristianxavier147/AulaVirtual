import intersection from "lodash.intersection";
import { cryptService } from "@/mixins/crypto";

class protectedView {
  constructor() {}

  isAllowed(allowedRoles, router = true) {
    let rolesData;
    let i = 0;

    let rolesUsers = window.$cookies.get("roles");
    if (rolesUsers === null) {
      rolesUsers = [{ name: "*" }];
    } else {
      rolesUsers = cryptService.decryptData(rolesUsers);
      rolesUsers = JSON.parse(rolesUsers);
      if (router) {
        rolesUsers.push({ name: "*" });
      }
    }

    rolesData = rolesUsers.reduce((roles, rolesData) => {
      roles[i++] = rolesData.name;
      return roles;
    }, []);

    return !!intersection(allowedRoles, rolesData).length;
  }
}

export const protectedViewService = new protectedView();
