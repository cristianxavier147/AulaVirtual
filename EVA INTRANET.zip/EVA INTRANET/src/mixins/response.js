import router from "@/router";

class response {
  constructor() {}

  handleError(code, error = {}) {
    let status;
    const hasToken = window.$cookies.isKey("token");
    switch (code) {
      case 401:
        status = router.push({ name: "Home" }).catch(()=>{});
        break;
      case 403:
        if (hasToken) {
          status = router.push({ name: "page-authorized" }).catch(()=>{});
        } else {
          console.log('error')
        }
        break;
      case 422:
        console.log('error')
        break;
      case 429:
        console.log('error')
        break;
      default:
        if (hasToken) {
          console.log('error')
        }
        break;
    }

    return status;
  }
}

export const responseService = new response();
