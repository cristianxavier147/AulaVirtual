const Bienvenido = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Onboarding/Bienvenida");
const Continuar = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Onboarding/Continuar");
const FotoUsuario = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Onboarding/EscogerFoto");
const Password = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Onboarding/Finalizar");

//cursos
const cursosDocentes = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Cursos");
const cursosDocentesDetalle = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Cursos/Detalle");
const cursosDocentesSeccion = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Docentes/Cursos/Detalle/Secciones");

// Perfil

const DocentesPerfil = () => import("@/views/Docentes/Perfil");

const docentes = [
  //onboarding
  {
    path: "/docentes/onboarding/bienvenido",
    name: "docenteBienvenido",
    component: Bienvenido,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/docentes/onboarding/continuar",
    name: "docenteContinuar",
    component: Continuar,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/docentes/onboarding/photo",
    name: "docenteFotoUsuario",
    component: FotoUsuario,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/docentes/onboarding/password",
    name: "docentePassword",
    component: Password,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  //cursos
  {
    path: "/docentes/cursos",
    name: "cursosDocentes",
    component: cursosDocentes,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },

  {
    path: "/docentes/cursos/:slug",
    name: "cursosDocentesDetalle",
    component: cursosDocentesDetalle,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },

  {
    path: "/docentes/cursos/:slug/seccion",
    name: "cursosDocentesSeccion",
    component: cursosDocentesSeccion,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },

  // Perfil
  {
    path: "/docentes/perfil",
    name: "docentesPerfil",
    component: DocentesPerfil,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },
];

export default docentes;
