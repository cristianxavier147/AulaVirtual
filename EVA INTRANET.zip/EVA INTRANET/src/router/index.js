import Vue from "vue";
import VueRouter from "vue-router";
import AlumnosConfig from "@/router/alumnos";
import DocentesConfig from "@/router/docentes";
import GeneralesConfig from "@/router/generales";
import { sessionService } from "@/mixins/session";

Vue.use(VueRouter);

const routes = [
  ...AlumnosConfig,
  ...DocentesConfig,
  ...GeneralesConfig
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

router.beforeEach((to, from, next) => {
  const publicPages = [
    "login",
    "restablecerPass",
    "newPassword",
    // "register",
    // "recovery-password",
  ];
  const authRequired = !publicPages.includes(to.name);
  const loggedIn = localStorage.getItem("token");
  // document.title = to.meta.title;

  if (authRequired) {
    if (loggedIn === null && to.meta.auth === true) {
      return next("/login");
    } else {
      return next();
    }
  } else {
    if (to.name === "preloader" || to.name === 'login') {
      sessionService.removeSession();
    }

    next();
  }
});

export default router;
