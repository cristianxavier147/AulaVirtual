const login = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Login");
const RestablecerPass = () => import(/* webpackChunkName: "login.chunk" */ "@/views/RestablecerPassword/ResetPassword");
const NewPassword = () => import(/* webpackChunkName: "login.chunk" */ "@/views/RestablecerPassword/NuevoPassword");
const preloader = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Preloader");
const olvidecontrasena = () => import(/* webpackChunkName: "login.chunk" */ "@/views/OlvideContrasena");

const dashboard = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Dashboard");

const Beneficios = () => import(/* webpackChunkName: "beneficios.chunk" */ "@/views/Beneficios");

const EncuestaDocente = () => import("@/views/Encuesta/EncuestaDocente");

const Encuesta = () => import("@/views/Encuesta");

const EncuestaDay = () => import("@/views/Encuesta/EncuestaDay");

const EncuestaNps = () => import("@/views/Encuesta/EncuestaNps");

const generales = [
  {
    path: "/login",
    name: "login",
    component: login,
    meta: {
      auth: false,
      showSidebar: false,
      showContent: false,

      showNavbar: false,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/",
    name: "preloader",
    component: preloader,
    meta: {
      auth: false,
      showSidebar: false,
      showContent: false,
      showNavbar: false,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/restablecerPassword",
    name: "restablecerPass",
    component: RestablecerPass,
    meta: {
      auth: false,
      showSidebar: false,
      showContent: false,
      showNavbar: false,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/nuevoPassword",
    name: "newPassword",
    component: NewPassword,
    meta: {
      auth: false,
      showSidebar: false,
      showContent: false,
      showNavbar: false,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/olvidecontrasena",
    name: "olvidecontrasena",
    component: olvidecontrasena,
    meta: {
      auth: false,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/dashboard",
    name: "dashboard",
    component: dashboard,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: true,
      showNavbar: true,
      showMenu: true,
      showHoraios: true,
      showHome: true,
    },
  },

  {
    path: "/beneficios",
    name: "beneficios",
    component: Beneficios,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  // encuestas

  //encuesta docente
  {
    path: "/encuesta/docente",
    name: "encuestaDocente",
    component: EncuestaDocente,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  //encuesta primera semana
  {
    path: "/encuesta",
    name: "encuesta",
    component: Encuesta,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  // encuesta primer día

  {
    path: "/encuesta/dia",
    name: "encuestaDay",
    component: EncuestaDay,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  // Encuesta NPS

  {
    path: "/encuesta/nps",
    name: "encuestaNps",
    component: EncuestaNps,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
];

export default generales;
