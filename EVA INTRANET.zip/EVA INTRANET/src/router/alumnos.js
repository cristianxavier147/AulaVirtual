const Directivas = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Directivas");
const PagoTarde = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/PagoTarde");
const Olvide = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/PagoTarde/OlvidoPago");
const OlvideFinish = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/PagoTarde/OlvidoPago/ReagendarPago/OlvideFinish");
const ReagendarPago = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/PagoTarde/OlvidoPago/ReagendarPago");
const Problema = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/PagoTarde/Problema");

const cursos = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos");
const horario = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Horario");
const cursosFinalizados = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos/Finalizados");
const cursosAnvanceCurricular = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos/AvanceCurricular");
const cursosAnvanceCurricularHistorial = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos/AvanceCurricular/Historial");
const cursosAnvanceCurricularSituacionAcademica = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos/AvanceCurricular/SituacionAcademica.vue");
const cursosAnvanceCurricularDetalle = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Cursos/AvanceCurricular/Detalle");
const Biblioteca = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Biblioteca");
const Error404 = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Error404");

//onboarding

const Bienvenido = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Onboarding/Bienvenida");
const ValidarDatos = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Onboarding/ValidarDatos");
const Continuar = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Onboarding/Continuar");
const FotoUsuario = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Onboarding/EscogerFoto");
const Password = () => import(/* webpackChunkName: "login.chunk" */ "@/views/Alumnos/Onboarding/Finalizar");

const alumnos = [
  // PAGO TARDE
  {
    path: "/alumnos/pagoTarde",
    name: "pagoTarde",
    component: PagoTarde,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/pagoTarde/olvide",
    name: "olvide",
    component: Olvide,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/pagoTarde/olvideFinish",
    name: "olvideFinish",
    component: OlvideFinish,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/pagoTarde/reagendarPago",
    name: "reagendarPago",
    component: ReagendarPago,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/pagoTarde/problema",
    name: "problema",
    component: Problema,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/directivas",
    name: "directivas",
    component: Directivas,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/onboarding/bienvenido",
    name: "alumnoBienvenido",
    component: Bienvenido,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/onboarding/validarDatos",
    name: "alumnoValidarDatos",
    component: ValidarDatos,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/alumnos/onboarding/continuar",
    name: "alumnoContinuar",
    component: Continuar,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/alumnos/onboarding/photo",
    name: "alumnoFotoUsuario",
    component: FotoUsuario,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
  {
    path: "/alumnos/onboarding/password",
    name: "alumnoPassword",
    component: Password,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },

  {
    path: "/alumnos/cursos/curso/:slug",
    name: "alumnoCursos",
    component: cursos,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },
  {
    path: "/alumnos/horario/:slug",
    name: "horario",
    component: horario,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },
  {
    path: "/alumnos/cursos/finalizados",
    name: "cursosFinalizados",
    component: cursosFinalizados,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },
  {
    path: "/alumnos/cursos/avance-curricular",
    name: "cursosAnvanceCurricular",
    component: cursosAnvanceCurricular,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
    children: [
      {
        path: "",
        component: cursosAnvanceCurricularSituacionAcademica,
        meta: {
          auth: true,
          showSidebar: true,
          showContent: false,
          showNavbar: true,
          showMenu: true,
          showHoraios: false,
          showHome: true,
        },
      },
      {
        path: "historial",
        component: cursosAnvanceCurricularHistorial,
        meta: {
          auth: true,
          showSidebar: true,
          showContent: false,
          showNavbar: true,
          showMenu: true,
          showHoraios: false,
          showHome: true,
        },
      },
    ],
  },
  {
    path: "/alumnos/cursos/avance-curricular/:slug",
    name: "cursosAnvanceCurricularDetalle",
    component: cursosAnvanceCurricularDetalle,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },

  // Biblioteca

  {
    path: "/alumnos/dashboard/biblioteca",
    name: "biblioteca",
    component: Biblioteca,
    meta: {
      auth: true,
      showSidebar: true,
      showContent: false,
      showNavbar: true,
      showMenu: true,
      showHoraios: false,
      showHome: true,
    },
  },

  {
    path: "/alumnos/dashboard/error404",
    name: "error404",
    component: Error404,
    meta: {
      auth: true,
      showSidebar: false,
      showContent: false,
      showNavbar: true,
      showMenu: false,
      showHoraios: false,
      showHome: false,
    },
  },
];

export default alumnos;
