class Seeder {
  constructor() {}

  typeApartmentSeeder() {
    return [
      { key: "Flat", value: "Flat" },
      { key: "Duplex", value: "Duplex" },
      { key: "Triplex", value: "Triplex" },
      { key: "PentHouse", value: "PentHouse" },
    ];
  }

  viewTypeApartmentSeeder() {
    return [
      { key: "Interior", value: "Interior" },
      { key: "Exterior", value: "Exterior" },
    ];
  }

  porterDataApartmentSeeder() {
    return [
      { key: "Sólo de día", value: "Sólo de día" },
      { key: "Sólo de noche", value: "Sólo de noche" },
      { key: "Sin portería", value: "Sin portería" },
      { key: "24/7", value: "24/7" },
    ];
  }

  optionsSeeder() {
    return [
      { key: 1, value: "Sí" },
      { key: 0, value: "No" },
    ];
  }

  optionsStringSeeder() {
    return [
      { text: "Sí", value: "1" },
      { text: "No", value: "0" },
    ];
  }

  depositLocationDataSeeder() {
    return [
      { key: "Piso 1", value: "Piso 1" },
      { key: "Piso 2", value: "Piso 2" },
      { key: "Sótano 1", value: "Sótano 1" },
      { key: "Sótano 2", value: "Sótano 2" },
      { key: "Sótano 3", value: "Sótano 3" },
      { key: "Sótano 4", value: "Sótano 4" },
      { key: "Sótano 5", value: "Sótano 5" },
      { key: "Sótano 6", value: "Sótano 6" },
    ];
  }

  parkingLocationDataSeeder() {
    return [
      { key: "Piso 1", value: "Piso 1" },
      { key: "Sótano 1", value: "Sótano 1" },
      { key: "Sótano 2", value: "Sótano 2" },
      { key: "Sótano 3", value: "Sótano 3" },
      { key: "Sótano 4", value: "Sótano 4" },
      { key: "Sótano 5", value: "Sótano 5" },
      { key: "Sótano 6", value: "Sótano 6" },
      { key: "Sótano 7", value: "Sótano 7" },
      { key: "Sótano 8", value: "Sótano 8" },
    ];
  }

  weHostPaymentSeeder() {
    return [
      { key: 1, value: "We Host paga" },
      { key: 0, value: "We Host recibe" },
    ];
  }

  statusApartmentSeeder() {
    return [
      { id: 1, value: "Propiedad en alquiler" },
      { id: 2, value: "Propiedad alquilada" },
      { id: 3, value: "Offboarding" },
      { id: 4, value: "Propiedad suspendida" },
      { id: 5, value: "Corto Plazo" },
    ];
  }

  monthsSeeder() {
    return [
      { id: "01", value: "Ene." },
      { id: "02", value: "Feb." },
      { id: "03", value: "Mar." },
      { id: "04", value: "Abr." },
      { id: "05", value: "May." },
      { id: "06", value: "Jun." },
      { id: "07", value: "Jul." },
      { id: "08", value: "Ago." },
      { id: "09", value: "Sep." },
      { id: "10", value: "Oct." },
      { id: "11", value: "Nov." },
      { id: "12", value: "Dic." },
    ];
  }

  genderSeeder() {
    return ["Masculino", "Femenino", "Otros"];
  }

  typeDocumentSeeder() {
    return ["DNI", "Pasaporte"];
  }

  typeDocumentInformationBankSeeder() {
    return ["DNI", "Carné de Extranjería", "Pasaporte"];
  }

  typeCoinSeeder() {
    return [
      { key: "S/.", value: "Soles" },
      { key: "$", value: "Dólares" },
    ];
  }

  infoAccountBankSeeder() {
    return [
      { key: 1, value: "Cuenta soles" },
      { key: 2, value: "Cuenta dólares" },
      { key: 3, value: "Agregar otra cuenta" },
    ];
  }

  numberPropertySeeder() {
    let response = [];
    let index = 1;
    for (index; index < 10; index++) {
      response.push({ value: String(index), text: index });
    }

    return response;
  }

  channelSeeder() {
    return [
      "Urbania",
      "Adondevivir",
      "Facebook",
      "Instagram",
      "Directo",
      "Otro",
    ];
  }

  typeCommissionSeeder() {
    return [
      { key: "unique_payment", value: "Pago único de comisión" },
      { key: "quarterly_payment", value: "Pago trimestral de comisión" },
    ];
  }

  bedsRoomsSeeder() {
    return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  }

  typeRoomsSeeder() {
    return ["Normal", "Camarote"];
  }

  sizeRoomsSeeder() {
    return ["King", "Queen", "2 plazas", "1.5 plazas", "1 plaza"];
  }

  antiquitySeeder() {
    let response = [];
    let index = 1;
    for (index; index <= 50; index++) {
      response.push(index);
    }

    return response;
  }

  typeDocumentProxySeeder() {
    return [
      { key: "DNI", value: "DNI" },
      { key: "Carnet", value: "Carnet" },
      { key: "Pasaporte", value: "Pasaporte" },
    ];
  }

  occupationSeeder() {
    return [
      { key: "Portero", value: "Portero" },
      { key: "Limpieza", value: "Limpieza" },
      { key: "Seguridad", value: "Seguridad" },
    ];
  }
}

export const seederConfig = new Seeder();
