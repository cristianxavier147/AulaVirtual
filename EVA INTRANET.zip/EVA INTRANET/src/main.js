import Vue from "vue";
import App from "@/views/Layout";
import router from "@/router";
import store from "@/store";
import i18n from "@/lang/i18n";
import VueCookies from "vue-cookies";
import VueOnlinePlugin from "vue-navigator-online";
import "@/assets/styles/tailwind.css";
import * as Sentry from "@sentry/vue";
import { Integrations } from "@sentry/tracing";
import Home from "@/views/Preloader";

Vue.config.productionTip = false;
Vue.use(VueCookies);
Vue.use(VueOnlinePlugin);

new Vue({
  router,
  store,
  i18n,
  render: (h) => h(App),
  data() {
    return {
      dsn: "",
    };
  },
  ready: function() {
    this.dsn = this.Inclusivo();
  },
  methods: {
    Inclusivo() {
      const route = window.location.host;
      switch (route) {
        case process.env.VUE_APP_RUTA_IDAT:
          window.$cookies.set("dsn", process.env.VUE_APP_DSN_IDAT);
          break;
        case process.env.VUE_APP_RUTA_ZEGEL:
          window.$cookies.set("dsn", process.env.VUE_APP_DSN_ZEGEL);
          break;
        case process.env.VUE_APP_RUTA_CORRIENTE:
          window.$cookies.set("dsn", process.env.VUE_APP_DSN_CORRIENTE);
          break;
        case process.env.VUE_APP_RUTA_DEVELOPMENT:
          window.$cookies.set("dsn", process.env.VUE_APP_DSN_DEVELOPMENT);
      }
    },
    consola() {},
    redireccion() {
      if (process.env.NODE_ENV == "production") {
        if (location.protocol !== "https:") {
          location.replace(`https:${location.href.substring(location.protocol.length)}`);
        }
      } else {
      }
    },
  },
  created() {
    this.Inclusivo();
    this.redireccion();
  },
}).$mount("#app");

// Sentry.init({
//   Vue: Vue,
//   dsn: $cookies.get("dsn"),
//   integrations: [new Integrations.BrowserTracing()],// Set tracesSampleRate to 1.0 to capture 100%// of transactions for performance monitoring.// We recommend adjusting this value in production
//   tracesSampleRate: 1.0,
//   environment: process.env.NODE_ENV,
// });
