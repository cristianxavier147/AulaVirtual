module.exports = {
  apps : [{
    name: 'Idat',
    script: './node_modules/@vue/cli-service/bin/vue-cli-service.js',
    args: 'serve --port 8085',
    watch: 'true'
  }
]
};
