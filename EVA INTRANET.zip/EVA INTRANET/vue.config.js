const path = require("path");

module.exports = {

  chainWebpack: config => {
    config.plugins.delete('prefetch')

    config.plugin('preload').tap((options) => {
      options[0].include = 'allChunks'
      return options
    })

  },  

  pluginOptions: {
    i18n: {
      locale: "es",
      fallbackLocale: "es",
      localeDir: "locales",
      enableInSFC: true,
    },
/*  devServer: {
    disableHostCheck: true,
    port:8080,
    host: 'xxxxxx',
    https: true,
    //key: fs.readFileSync('./certs/xxxxxx.pem'),
    //cert: fs.readFileSync('./certs/xxxxxx.pem'),
    pfx: fs.readFileSync('./certs/xxxxxx.pfx'),
    pfxPassphrase: "xxxxxx",
    public: 'https://xxxxxx:9000/',
    https: true,
    hotOnly: false,
   }    */
  },

  
  configureWebpack: {
    devtool: process.env.NODE_ENV === "production" ? "" : "inline-source-map",
    node:
      process.env.NODE_ENV === "production"
        ? { crypto: true, stream: true }
        : {},
    module:
      process.env.NODE_ENV === "production"
        ? {
            rules: [
              {
                test: /\.js$/,
                loader: "babel-loader",
                exclude: /node_modules/,
              },
            ],
          }
        : {},
    resolve: {
      extensions: [".js", ".vue", ".json"],
      alias: {
        vue$: "vue/dist/vue.esm.js",
        "@": path.resolve(__dirname, "src"),
      },
    },
    performance:
      process.env.NODE_ENV === "production"
        ? {
            hints: false,
            maxEntrypointSize: 400000,
            maxAssetSize: 100000,
          }
        : {},
    optimization:
      process.env.NODE_ENV === "production"
        ? {
            splitChunks: {
              //chunks: "all",
              chunks: "async",
              maxInitialRequests: Infinity,
              minSize: 10000,
              maxSize: 40000,
              cacheGroups: {
                vendors: {
                  test: /[\\/]node_modules[\\/]/,
                  priority: -10,
                },
                default: {
                  minChunks: 5,
                  priority: -20,
                  reuseExistingChunk: true,
                },
                commons: {
                  test: /[\\/]node_modules[\\/]/,
                  name: "vendors",
                  chunks: "all",
                },
              },
            }, 
      
            //
            runtimeChunk: {
              name: (entrypoint) => `runtime~${entrypoint.name}`,
            },
            mangleWasmImports: true,
            removeAvailableModules: true,
            removeEmptyChunks: true,
            mergeDuplicateChunks: true,
            minimize: true,
            concatenateModules: true,
          }
        : {},

        
  },

  pwa: {
    name: "idat-zoom",
    msTileColor: "#F3F4F6",
    manifestCrossorigin: "anonymous",
    workboxOptions: {
      skipWaiting: true,
    },
  },
};