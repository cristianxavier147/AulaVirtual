const path = require("path");

module.exports = (env, argv) => ({
  mode: (argv && argv.mode) || "development",
  devtool:
    ((argv && argv.mode) || "development") === "production"
      ? "source-map"
      : "eval",

  entry: "./src/main.js",

  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "[name].js",
  },

  node: { crypto: true, stream: true },

  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: "vue-loader",
      },
      {
        test: /\.js$/,
        loader: "babel-loader",
        exclude: [/node_modules/],
      },
      {
        test: /\.less$/,
        use: [
          {
            loader: "css-loader", // translates CSS into CommonJS
          },
          {
            loader: "less-loader", // compiles Less to CSS
          }
        ],
      },
      {
        test: /\.css$/,
        use: [
          {
            loader: "vue-style-loader",
          },
          {
            loader: "css-loader",
          },
          {
            loader: "postcss-loader",
            options: {config: {path: 'config/postcss.config.js'}}
          },
        ],
        exclude: /\.module\.css$/,
      },
    ],
  },

  resolve: {
    extensions: [".js", ".vue", ".json"],
    alias: {
      vue$: "vue/dist/vue.esm.js",
      "@": path.resolve(__dirname, "src"),
    },
  },

  performance: {
    hints: false,
    maxEntrypointSize: 400000,
    maxAssetSize: 100000,
  },

  optimization: {
    splitChunks: {
      chunks: "all",
      minSize: 10000,
      maxSize: 40000,
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          priority: -10,
        },
        default: {
          minChunks: 5,
          priority: -20,
          reuseExistingChunk: true,
        },
      },
    },
    runtimeChunk: {
      name: (entrypoint) => `runtime~${entrypoint.name}`,
    },
    mangleWasmImports: true,
    removeAvailableModules: true,
    removeEmptyChunks: true,
    mergeDuplicateChunks: true,
  },
});
